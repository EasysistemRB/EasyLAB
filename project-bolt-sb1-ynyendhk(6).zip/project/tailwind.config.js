/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          50: 'var(--theme-primary-50, #eef2ff)',
          100: 'var(--theme-primary-100, #e0e7ff)',
          200: 'var(--theme-primary-200, #c7d2fe)',
          300: 'var(--theme-primary-300, #a5b4fc)',
          400: 'var(--theme-primary-400, #818cf8)',
          500: 'var(--theme-primary-500, #6366f1)',
          600: 'var(--theme-primary-600, #4f46e5)',
          700: 'var(--theme-primary-700, #4338ca)',
          800: 'var(--theme-primary-800, #3730a3)',
          900: 'var(--theme-primary-900, #312e81)',
          950: 'var(--theme-primary-950, #1e1b4b)',
        },
        secondary: {
          50: 'var(--theme-secondary-50, #f0fdfa)',
          100: 'var(--theme-secondary-100, #ccfbf1)',
          200: 'var(--theme-secondary-200, #99f6e4)',
          300: 'var(--theme-secondary-300, #5eead4)',
          400: 'var(--theme-secondary-400, #2dd4bf)',
          500: 'var(--theme-secondary-500, #14b8a6)',
          600: 'var(--theme-secondary-600, #0d9488)',
          700: 'var(--theme-secondary-700, #0f766e)',
          800: 'var(--theme-secondary-800, #115e59)',
          900: 'var(--theme-secondary-900, #134e4a)',
          950: 'var(--theme-secondary-950, #042f2e)',
        },
        accent: {
          50: 'var(--theme-accent-50, #fff1f2)',
          100: 'var(--theme-accent-100, #ffe4e6)',
          200: 'var(--theme-accent-200, #fecdd3)',
          300: 'var(--theme-accent-300, #fda4af)',
          400: 'var(--theme-accent-400, #fb7185)',
          500: 'var(--theme-accent-500, #f43f5e)',
          600: 'var(--theme-accent-600, #e11d48)',
          700: 'var(--theme-accent-700, #be123c)',
          800: 'var(--theme-accent-800, #9f1239)',
          900: 'var(--theme-accent-900, #881337)',
          950: 'var(--theme-accent-950, #4c0519)',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      boxShadow: {
        'glass': '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
        'neon': '0 0 5px var(--neon-color), 0 0 20px var(--neon-color)',
        'inner-glow': 'inset 0 2px 4px 0 rgba(255, 255, 255, 0.06)',
        'primary': '0 4px 6px -1px rgb(99 102 241 / 0.1), 0 2px 4px -2px rgb(99 102 241 / 0.1)',
        'primary-md': '0 4px 6px -1px rgb(99 102 241 / 0.2), 0 2px 4px -2px rgb(99 102 241 / 0.2)',
        'primary-lg': '0 10px 15px -3px rgb(99 102 241 / 0.2), 0 4px 6px -4px rgb(99 102 241 / 0.2)',
        'primary-xl': '0 20px 25px -5px rgb(99 102 241 / 0.2), 0 8px 10px -6px rgb(99 102 241 / 0.2)',
        'primary-2xl': '0 25px 50px -12px rgb(99 102 241 / 0.25)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'gradient-shine': 'linear-gradient(45deg, transparent 25%, rgba(255,255,255,0.1) 25%, rgba(255,255,255,0.1) 50%, transparent 50%, transparent 75%, rgba(255,255,255,0.1) 75%)',
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-slow': 'pulse 3s infinite',
        'spin-slow': 'spin 3s linear infinite',
        'ping-slow': 'ping 3s cubic-bezier(0, 0, 0.2, 1) infinite',
        'gradient': 'gradient 15s ease infinite',
        'shine': 'shine 1.5s ease-in-out infinite',
        'ripple': 'ripple 0.7s ease-out',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        gradient: {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
        },
        shine: {
          '0%': { backgroundPosition: '200% 0' },
          '100%': { backgroundPosition: '-200% 0' },
        },
        ripple: {
          '0%': { transform: 'scale(0)', opacity: '1' },
          '100%': { transform: 'scale(4)', opacity: '0' },
        },
      },
      backdropFilter: {
        'none': 'none',
        'blur': 'blur(4px)',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
    require('@tailwindcss/aspect-ratio'),
  ],
}