import { cleanupCache, getCacheStats, formatCacheSize } from '../src/utils/cacheUtils';

const cleanCache = async () => {
  try {
    // Get stats before cleanup
    console.log('Getting cache statistics...');
    const beforeStats = await getCacheStats();
    console.log('\nBefore cleanup:');
    console.log(`Total items: ${beforeStats.totalItems}`);
    console.log(`Total size: ${formatCacheSize(beforeStats.totalSize)}`);
    
    // Perform cleanup
    console.log('\nCleaning cache...');
    await cleanupCache();
    
    // Get stats after cleanup
    const afterStats = await getCacheStats();
    console.log('\nAfter cleanup:');
    console.log(`Total items: ${afterStats.totalItems}`);
    console.log(`Total size: ${formatCacheSize(afterStats.totalSize)}`);
    
    // Calculate difference
    const itemsDiff = beforeStats.totalItems - afterStats.totalItems;
    const sizeDiff = beforeStats.totalSize - afterStats.totalSize;
    
    console.log('\nCleanup results:');
    console.log(`Items removed: ${itemsDiff}`);
    console.log(`Space freed: ${formatCacheSize(sizeDiff)}`);
    
    process.exit(0);
  } catch (error) {
    console.error('Error cleaning cache:', error);
    process.exit(1);
  }
};

cleanCache();