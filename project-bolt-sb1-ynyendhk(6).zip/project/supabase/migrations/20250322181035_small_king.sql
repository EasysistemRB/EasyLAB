/*
  # Enhanced Ticket Management System Schema

  1. New Tables
    - `ticket_categories`
      - `id` (uuid, primary key)
      - `name` (text)
      - `icon` (text)
      - `description` (text)
      - `created_at` (timestamp)
      
    - `ticket_status_history`
      - `id` (uuid, primary key) 
      - `ticket_id` (uuid, foreign key)
      - `old_status` (text)
      - `new_status` (text)
      - `changed_by` (uuid, foreign key)
      - `changed_at` (timestamp)
      - `notes` (text)

    - `ticket_solutions`
      - `id` (uuid, primary key)
      - `category_id` (uuid, foreign key)
      - `title` (text)
      - `description` (text)
      - `success_rate` (float)
      - `resolution_time_avg` (interval)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `ticket_checklists`
      - `id` (uuid, primary key)
      - `category_id` (uuid, foreign key)
      - `title` (text)
      - `items` (jsonb)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for admin and client access

  3. Changes
    - Add new columns to tickets table
    - Add status tracking
    - Add ML-based suggestion system
*/

-- Create ticket categories table
CREATE TABLE IF NOT EXISTS ticket_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  icon text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create ticket status history table
CREATE TABLE IF NOT EXISTS ticket_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid REFERENCES tickets(id) ON DELETE CASCADE,
  old_status text NOT NULL,
  new_status text NOT NULL,
  changed_by uuid REFERENCES auth.users(id),
  changed_at timestamptz DEFAULT now(),
  notes text,
  metrics jsonb DEFAULT '{}'::jsonb
);

-- Create ticket solutions table
CREATE TABLE IF NOT EXISTS ticket_solutions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES ticket_categories(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  success_rate float DEFAULT 0,
  resolution_time_avg interval,
  usage_count integer DEFAULT 0,
  keywords text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create ticket checklists table
CREATE TABLE IF NOT EXISTS ticket_checklists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES ticket_categories(id) ON DELETE CASCADE,
  title text NOT NULL,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_required boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add new columns to tickets table
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS category_id uuid REFERENCES ticket_categories(id);
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS solution_id uuid REFERENCES ticket_solutions(id);
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS checklist_status jsonb DEFAULT '{}'::jsonb;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS ml_suggestions jsonb DEFAULT '[]'::jsonb;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS resolution_time interval;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS complexity_score float DEFAULT 0;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS satisfaction_score integer;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS automated_category text;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS is_automated boolean DEFAULT false;

-- Create automatic payment system category
INSERT INTO ticket_categories (name, icon, description) VALUES 
('Cassetto Automatico', 'cash-register', 'Gestione sistemi di pagamento automatico e rendiresto');

-- Create checklist for automatic payment systems
INSERT INTO ticket_checklists (category_id, title, items, is_required) 
SELECT 
  id,
  'Checklist Controllo Cassetto Automatico',
  '[
    {
      "id": "1",
      "text": "Verifica connessione di rete",
      "required": true
    },
    {
      "id": "2",
      "text": "Controllo alimentazione",
      "required": true
    },
    {
      "id": "3",
      "text": "Test lettura banconote",
      "required": true
    },
    {
      "id": "4",
      "text": "Verifica rendiresto",
      "required": true
    },
    {
      "id": "5",
      "text": "Controllo livelli contante",
      "required": true
    },
    {
      "id": "6",
      "text": "Test comunicazione con registratore",
      "required": true
    },
    {
      "id": "7",
      "text": "Verifica software gestionale",
      "required": true
    },
    {
      "id": "8",
      "text": "Controllo sensori",
      "required": true
    }
  ]'::jsonb,
  true
FROM ticket_categories 
WHERE name = 'Cassetto Automatico'
LIMIT 1;

-- Enable Row Level Security
ALTER TABLE ticket_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_solutions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_checklists ENABLE ROW LEVEL SECURITY;

-- Create policies for admin access
CREATE POLICY "Admins can do everything on ticket_categories"
  ON ticket_categories
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'))
  WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'));

CREATE POLICY "Admins can do everything on ticket_status_history"
  ON ticket_status_history
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'))
  WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'));

CREATE POLICY "Admins can do everything on ticket_solutions"
  ON ticket_solutions
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'))
  WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'));

CREATE POLICY "Admins can do everything on ticket_checklists"
  ON ticket_checklists
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'))
  WITH CHECK (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'));

-- Create policies for client access
CREATE POLICY "Clients can view their own ticket categories"
  ON ticket_categories
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Clients can view their own ticket history"
  ON ticket_status_history
  FOR SELECT
  TO authenticated
  USING (ticket_id IN (
    SELECT id FROM tickets WHERE client_id = auth.uid()
  ));

CREATE POLICY "Clients can view solutions for their tickets"
  ON ticket_solutions
  FOR SELECT
  TO authenticated
  USING (id IN (
    SELECT solution_id FROM tickets WHERE client_id = auth.uid()
  ));

CREATE POLICY "Clients can view checklists for their tickets"
  ON ticket_checklists
  FOR SELECT
  TO authenticated
  USING (category_id IN (
    SELECT category_id FROM tickets WHERE client_id = auth.uid()
  ));

-- Create functions for ML suggestions
CREATE OR REPLACE FUNCTION get_ticket_suggestions(
  p_category_id uuid,
  p_description text
) RETURNS TABLE (
  solution_id uuid,
  title text,
  confidence float
) LANGUAGE plpgsql AS $$
BEGIN
  RETURN QUERY
  SELECT 
    s.id,
    s.title,
    similarity(p_description, s.description) as confidence
  FROM ticket_solutions s
  WHERE s.category_id = p_category_id
  AND similarity(p_description, s.description) > 0.3
  ORDER BY confidence DESC
  LIMIT 5;
END;
$$;

-- Create function to update solution success rates
CREATE OR REPLACE FUNCTION update_solution_stats() 
RETURNS trigger AS $$
BEGIN
  IF NEW.status = 'resolved' AND NEW.solution_id IS NOT NULL THEN
    UPDATE ticket_solutions
    SET 
      success_rate = (
        (success_rate * usage_count + 100) / (usage_count + 1)
      ),
      usage_count = usage_count + 1,
      resolution_time_avg = (
        COALESCE(resolution_time_avg, '0'::interval) * usage_count + NEW.resolution_time
      ) / (usage_count + 1),
      updated_at = now()
    WHERE id = NEW.solution_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_solution_stats_trigger
AFTER UPDATE ON tickets
FOR EACH ROW
WHEN (OLD.status != 'resolved' AND NEW.status = 'resolved')
EXECUTE FUNCTION update_solution_stats();