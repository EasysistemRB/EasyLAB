import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Phone, Building, AlertCircle, CheckCircle2, UserPlus, Smartphone } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Logo from '../components/Logo';
import LoadingSpinner from '../components/LoadingSpinner';

const Register: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    mobile: '', // Added mobile field
    company: '',
    address: '',
    vat: '',
    accept: false,
    acceptPrivacy: false,
  });
  
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState(1);
  const [registrationComplete, setRegistrationComplete] = useState(false);
  
  const { register, state } = useAuth();
  const navigate = useNavigate();
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };
  
  const validateStep1 = () => {
    if (!formData.name.trim()) {
      setError('Il nome è obbligatorio');
      return false;
    }
    if (!formData.email.trim()) {
      setError('L\'email è obbligatoria');
      return false;
    }
    if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      setError('Email non valida');
      return false;
    }
    if (!formData.mobile.trim()) { // Added mobile validation
      setError('Il cellulare è obbligatorio');
      return false;
    }
    
    setError(null);
    return true;
  };
  
  const validateStep2 = () => {
    if (!formData.accept) {
      setError('Devi accettare i termini e le condizioni');
      return false;
    }
    if (!formData.acceptPrivacy) {
      setError('Devi accettare la privacy policy');
      return false;
    }
    
    setError(null);
    return true;
  };
  
  const nextStep = () => {
    if (step === 1 && validateStep1()) {
      setStep(2);
    }
  };
  
  const prevStep = () => {
    setStep(1);
    setError(null);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step === 2 && validateStep2()) {
      try {
        await register({
          name: formData.name,
          email: formData.email,
        });
        
        setRegistrationComplete(true);
        
        setTimeout(() => {
          navigate('/login');
        }, 3000);
      } catch (err) {
        setError('Errore durante la registrazione');
      }
    }
  };
  
  if (registrationComplete) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center">
            <Logo size="md" withText={true} />
          </div>
        </div>
        
        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 text-center">
            <div className="rounded-full h-12 w-12 bg-green-100 flex items-center justify-center mx-auto">
              <CheckCircle2 className="h-6 w-6 text-green-600" />
            </div>
            <h2 className="mt-4 text-lg font-medium text-gray-900">Registrazione completata</h2>
            <p className="mt-2 text-sm text-gray-500">
              La tua richiesta è stata inviata con successo. <br />
              Riceverai presto un'email con le credenziali di accesso.
            </p>
            <div className="mt-6">
              <button
                onClick={() => navigate('/login')}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Torna al login
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <Logo size="md" withText={true} />
        </div>
        <div className="flex items-center justify-center mt-6">
          <UserPlus className="h-12 w-12 text-primary-600 mr-3" />
          <h2 className="text-3xl font-extrabold text-gray-900">
            Registra nuovo cliente
          </h2>
        </div>
        <p className="mt-2 text-center text-sm text-gray-600">
          Compila il modulo per richiedere l'accesso al sistema
        </p>
      </div>
      
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <div className="mb-5 border-b pb-5">
            <div className="flex items-center justify-between">
              <div className="w-full flex items-center">
                <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                  step >= 1 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  1
                </div>
                <div className="ml-3 w-full">
                  <p className={`text-sm font-medium ${
                    step === 1 ? 'text-primary-600' : 'text-gray-500'
                  }`}>
                    Dati personali
                  </p>
                  <div className="mt-1 h-1 w-full bg-gray-200 rounded-full">
                    <div 
                      className="h-1 bg-primary-600 rounded-full" 
                      style={{ width: step >= 1 ? '100%' : '0%' }}
                    ></div>
                  </div>
                </div>
              </div>
              
              <div className="w-10 flex justify-center">
                <div className="w-px h-10 bg-gray-300"></div>
              </div>
              
              <div className="w-full flex items-center">
                <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                  step >= 2 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  2
                </div>
                <div className="ml-3 w-full">
                  <p className={`text-sm font-medium ${
                    step === 2 ? 'text-primary-600' : 'text-gray-500'
                  }`}>
                    Termini e condizioni
                  </p>
                  <div className="mt-1 h-1 w-full bg-gray-200 rounded-full">
                    <div 
                      className="h-1 bg-primary-600 rounded-full" 
                      style={{ width: step >= 2 ? '100%' : '0%' }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <form className="space-y-6" onSubmit={handleSubmit}>
            {step === 1 && (
              <>
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Nome e Cognome <span className="text-red-500">*</span>
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      className="input pl-10"
                      placeholder="Mario Rossi"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email <span className="text-red-500">*</span>
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="input pl-10"
                      placeholder="mario.rossi@esempio.it"
                    />
                  </div>
                </div>

                {/* New Mobile Field with Green Styling */}
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <label htmlFor="mobile" className="block text-sm font-medium text-green-700">
                    Cellulare <span className="text-red-500">*</span>
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Smartphone className="h-5 w-5 text-green-500" />
                    </div>
                    <input
                      id="mobile"
                      name="mobile"
                      type="tel"
                      required
                      value={formData.mobile}
                      onChange={handleInputChange}
                      className="input pl-10 bg-white border-green-300 focus:border-green-500 focus:ring-green-500 text-green-700 placeholder-green-400"
                      placeholder="+39 123 456 7890"
                    />
                  </div>
                  <p className="mt-1 text-sm text-green-600">
                    Inserisci il numero in formato internazionale (+39)
                  </p>
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    Telefono Fisso
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Phone className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="input pl-10"
                      placeholder="+39 081 123 4567"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-gray-700">
                    Azienda
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Building className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="company"
                      name="company"
                      type="text"
                      value={formData.company}
                      onChange={handleInputChange}
                      className="input pl-10"
                      placeholder="Nome Azienda"
                    />
                  </div>
                </div>
              </>
            )}
            
            {step === 2 && (
              <>
                <div className="space-y-4">
                  <div className="bg-gray-50 p-4 rounded-md text-sm">
                    <h3 className="font-medium text-gray-900 mb-2">Termini e Condizioni di Utilizzo</h3>
                    <div className="h-48 overflow-y-auto text-gray-600 bg-white p-3 rounded border border-gray-200 mb-2">
                      <p className="mb-2">
                        L'accesso e l'utilizzo di EasyLAB-25 sono soggetti ai seguenti termini e condizioni. 
                        Accettando, l'utente si impegna a rispettare le regole di utilizzo del software.
                      </p>
                      <p className="mb-2">
                        Il software EasyLAB-25 è di proprietà esclusiva di EasySystem di Raffaele Bianchetti ed è concesso in licenza d'uso 
                        temporanea e non esclusiva all'utente.
                      </p>
                      <p className="mb-2">
                        L'utente è responsabile della conservazione delle proprie credenziali di accesso e si impegna a non divulgarle a terzi.
                      </p>
                      <p className="mb-2">
                        Il software viene fornito "così com'è" senza garanzie di alcun tipo, esplicite o implicite.
                      </p>
                      <p className="mb-2">
                        EasySystem di Raffaele Bianchetti non sarà responsabile per danni diretti, indiretti, incidentali, 
                        consequenziali o speciali derivanti dall'uso o dall'impossibilità di utilizzare il software.
                      </p>
                      <p className="mb-2">
                        EasySystem di Raffaele Bianchetti si riserva il diritto di modificare, sospendere o interrompere, 
                        temporaneamente o permanentemente, il servizio o una parte di esso, con o senza preavviso.
                      </p>
                    </div>
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="accept"
                          name="accept"
                          type="checkbox"
                          checked={formData.accept}
                          onChange={handleInputChange}
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="accept" className="font-medium text-gray-700">
                          Accetto i Termini e le Condizioni
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-md text-sm">
                    <h3 className="font-medium text-gray-900 mb-2">Informativa sulla Privacy</h3>
                    <div className="h-48 overflow-y-auto text-gray-600 bg-white p-3 rounded border border-gray-200 mb-2">
                      <p className="mb-2">
                        Ai sensi del Regolamento UE 2016/679 (GDPR), informiamo che i dati personali forniti saranno 
                        trattati da EasySystem di Raffaele Bianchetti in qualità di Titolare del trattamento.
                      </p>
                      <p className="mb-2">
                        I dati saranno trattati per le seguenti finalità:
                      </p>
                      <ul className="list-disc pl-5 mb-2">
                        <li>Gestione dell'account e fornitura del servizio</li>
                        <li>Comunicazioni relative al servizio</li>
                        <li>Adempimento di obblighi legali</li>
                        <li>Miglioramento del servizio</li>
                      </ul>
                      <p className="mb-2">
                        I dati saranno conservati per il tempo necessario a fornire il servizio e adempiere agli obblighi legali.
                      </p>
                      <p className="mb-2">
                        L'utente ha diritto di accedere ai propri dati, chiederne la rettifica, la cancellazione, la limitazione 
                        del trattamento, opporsi al trattamento, revocare il consenso e proporre reclamo all'autorità di controllo.
                      </p>
                    </div>
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="acceptPrivacy"
                          name="acceptPrivacy"
                          type="checkbox"
                          checked={formData.acceptPrivacy}
                          onChange={handleInputChange}
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="acceptPrivacy" className="font-medium text-gray-700">
                          Accetto l'Informativa sulla Privacy
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
            
            {error && (
              <div className="rounded-md bg-red-50 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-red-400" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-red-800">{error}</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="flex justify-between space-x-3">
              {step > 1 && (
                <button
                  type="button"
                  onClick={prevStep}
                  className="flex-1 py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Indietro
                </button>
              )}
              
              {step < 2 ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="flex-1 flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Continua
                </button>
              ) : (
                <button
                  type="submit"
                  className="flex-1 flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                  disabled={state.isLoading}
                >
                  {state.isLoading ? (
                    <LoadingSpinner size="sm" color="white" />
                  ) : (
                    'Registrati'
                  )}
                </button>
              )}
            </div>
            
            <div className="text-center mt-4">
              <button
                type="button"
                onClick={() => navigate('/login')}
                className="text-sm font-medium text-primary-600 hover:text-primary-500"
              >
                Hai già un account? Accedi
              </button>
            </div>
          </form>
        </div>
      </div>
      
      <div className="mt-8 text-center text-xs text-gray-500">
        <p>© 2025 EasySystem di Raffaele Bianchetti - Tutti i diritti riservati</p>
        <p className="mt-1">P.IVA: 04118710617</p>
      </div>
    </div>
  );
};

export default Register;