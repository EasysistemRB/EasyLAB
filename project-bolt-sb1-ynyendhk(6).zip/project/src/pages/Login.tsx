import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Eye, EyeOff, User, Lock, AlertCircle, Shield, 
  FileText, Key, Mail, CheckCircle2, Info, Book,
  UserPlus, ChevronRight, Globe, Phone, Building
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Logo from '../components/Logo';
import LoadingSpinner from '../components/LoadingSpinner';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [forgotPasswordMode, setForgotPasswordMode] = useState(false);
  const [email, setEmail] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState(false);
  
  const { login, state, forgotPassword } = useAuth();
  const navigate = useNavigate();

  // Redirect if already logged in
  useEffect(() => {
    if (state.isAuthenticated) {
      navigate(state.user?.role === 'admin' ? '/admin' : '/client');
    }
  }, [state.isAuthenticated, state.user?.role, navigate]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!username.trim() || !password.trim()) {
      setError('Inserire username e password');
      return;
    }
    
    try {
      await login(username, password);
    } catch (err) {
      setError('Credenziali non valide');
    }
  };
  
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!email.trim()) {
      setError('Inserire un indirizzo email');
      return;
    }
    
    try {
      await forgotPassword(email);
      setForgotSuccess(true);
    } catch (err) {
      setError('Errore durante la richiesta di recupero password');
    }
  };
  
  const toggleUserType = () => {
    setIsAdmin(!isAdmin);
    setError(null);
    
    // Prefill demo credentials
    if (!isAdmin) {
      setUsername('admin');
      setPassword('123456');
    } else {
      setUsername('ESL-001');
      setPassword('123456');
    }
  };

  if (state.isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 flex items-center justify-center">
        <LoadingSpinner size="lg" color="white" text="Caricamento..." />
      </div>
    );
  }
  
  if (forgotPasswordMode) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center">
            <Logo size="md" withText={true} />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
            Recupera la tua password
          </h2>
        </div>
        
        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white/10 backdrop-blur-lg py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-white/20">
            {forgotSuccess ? (
              <div className="text-center">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="mt-3 text-lg font-medium text-white">Richiesta inviata</h3>
                <p className="mt-2 text-sm text-gray-300">
                  Abbiamo inviato le istruzioni per il recupero della password all'indirizzo email fornito.
                </p>
                <div className="mt-6">
                  <button
                    onClick={() => {
                      setForgotPasswordMode(false);
                      setForgotSuccess(false);
                    }}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Torna al login
                  </button>
                </div>
              </div>
            ) : (
              <form className="space-y-6" onSubmit={handleForgotPassword}>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-white">
                    Indirizzo email
                  </label>
                  <div className="mt-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                      <Mail className="h-5 w-5 text-blue-400" />
                    </div>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="block w-full pl-10 pr-3 py-2 border border-blue-500/30 text-white bg-white/5 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm placeholder-gray-400"
                      placeholder="Inserisci la tua email"
                    />
                  </div>
                </div>
                
                {error && (
                  <div className="rounded-md bg-red-900/50 border border-red-500/50 p-4">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <AlertCircle className="h-5 w-5 text-red-400" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm text-red-300">{error}</p>
                      </div>
                    </div>
                  </div>
                )}
                
                <div>
                  <button
                    type="submit"
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    disabled={state.isLoading}
                  >
                    {state.isLoading ? (
                      <LoadingSpinner size="sm" color="white" />
                    ) : (
                      'Invia istruzioni'
                    )}
                  </button>
                </div>
                
                <div className="flex items-center justify-center">
                  <div className="text-sm">
                    <button
                      type="button"
                      onClick={() => setForgotPasswordMode(false)}
                      className="font-medium text-blue-400 hover:text-blue-300"
                    >
                      Torna al login
                    </button>
                  </div>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMtOS45NDEgMC0xOCA4LjA1OS0xOCAxOHM4LjA1OSAxOCAxOCAxOGM5Ljk0MSAwIDE4LTguMDU5IDE4LTE4cy04LjA1OS0xOC0xOC0xOHptMCAzMmMtNy43MzIgMC0xNC02LjI2OC0xNC0xNHM2LjI2OC0xNCAxNC0xNHMxNCA2LjI2OCAxNCAxNHMtNi4yNjggMTQtMTQgMTR6IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9Ii4wNSIvPjwvZz48L3N2Zz4=')] opacity-10"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-blue-900/50 to-transparent"></div>
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        <Logo size="md" withText={true} animated={true} centered={true} />
        <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
          Accedi al tuo account
        </h2>
        <p className="mt-2 text-center text-sm text-gray-300">
          {isAdmin ? 'Area Amministrazione' : 'Area Cliente'}
          <button
            onClick={toggleUserType}
            className="ml-2 font-medium text-blue-400 hover:text-blue-300"
          >
            {isAdmin ? 'Vai all\'area cliente' : 'Vai all\'area admin'}
          </button>
        </p>
      </div>
      
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        <div className="bg-white/10 backdrop-blur-lg py-8 px-4 shadow-2xl sm:rounded-lg sm:px-10 border border-white/20">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-white">
                {isAdmin ? 'Username' : 'Codice Cliente'}
              </label>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <User className="h-5 w-5 text-blue-400" />
                </div>
                <input
                  id="username"
                  name="username"
                  type="text"
                  autoComplete="username"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-blue-500/30 text-white bg-white/5 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm placeholder-gray-400"
                  placeholder={isAdmin ? "admin" : "ESL-0000"}
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-white">
                Password
              </label>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <Lock className="h-5 w-5 text-blue-400" />
                </div>
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-10 pr-10 py-2 border border-blue-500/30 text-white bg-white/5 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm placeholder-gray-400"
                  placeholder="••••••"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-blue-400 hover:text-blue-300 focus:outline-none"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>
            </div>
            
            {error && (
              <div className="rounded-md bg-red-900/50 border border-red-500/50 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-red-400" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-red-300">{error}</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember_me"
                  name="remember_me"
                  type="checkbox"
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="remember_me" className="ml-2 block text-sm text-gray-300">
                  Ricordami
                </label>
              </div>
              
              <div className="text-sm">
                <button
                  type="button"
                  onClick={() => setForgotPasswordMode(true)}
                  className="font-medium text-blue-400 hover:text-blue-300"
                >
                  Password dimenticata?
                </button>
              </div>
            </div>
            
            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 relative overflow-hidden group"
                disabled={state.isLoading}
              >
                <span className="absolute inset-0 w-full h-full transition-all duration-1000 ease-out transform translate-x-full bg-gradient-to-r from-blue-400 via-blue-500 to-blue-600 group-hover:translate-x-0 group-hover:scale-102"></span>
                <span className="relative flex items-center justify-center">
                  {state.isLoading ? (
                    <LoadingSpinner size="sm" color="white" />
                  ) : (
                    <>
                      <Key className="h-5 w-5 mr-2" />
                      Accedi
                    </>
                  )}
                </span>
              </button>
            </div>
          </form>
          
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-600"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-transparent text-gray-400">
                  oppure
                </span>
              </div>
            </div>
            
            <div className="mt-6">
              <p className="text-center text-sm text-gray-400">
                Credenziali demo: {isAdmin ? 'admin' : 'ESL-001'} / 123456
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-8 text-center text-xs text-gray-500">
        <p>© 2025 EasySystem di Raffaele Bianchetti - Tutti i diritti riservati</p>
        <p className="mt-1">P.IVA: 04118710617</p>
      </div>
    </div>
  );
};

export default Login;