import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { 
  Save, X, AlertTriangle, CheckCircle, Calendar, Clock, 
  MessageSquare, User, FileText, Video, Globe, Users, 
  CreditCard, Info, Smartphone, Mail, Building, MapPin, 
  Car, PenTool as Tool, Coffee, FileCheck, AlertCircle, Send,
  CalendarPlus, CalendarCheck, CalendarDays, CalendarClock
} from 'lucide-react';
import { format, parseISO, isValid } from 'date-fns';
import { it } from 'date-fns/locale';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { BasicInfoSection, DateTimeSection, ContactSection, NotesSection } from '../../../components/AppointmentFormSections';

const AppointmentForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const isEditMode = !!id;
  
  const { state, addAppointment, updateAppointment } = useData();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Form States
  const [formData, setFormData] = useState({
    clientId: '',
    deviceId: '',
    title: '',
    description: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    startTime: '09:00',
    endTime: '10:00',
    status: 'scheduled',
    notes: '',
    referent: '',
    referentPhone: '',
    referentEmail: '',
    rescheduleCount: 0,
    rescheduleReason: '',
    rescheduleNote: ''
  });
  
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  // Load appointment data if editing
  useEffect(() => {
    if (isEditMode && id) {
      const appointment = state.appointments.find(a => a.id === id);
      if (appointment) {
        setFormData({
          ...appointment,
          date: format(new Date(appointment.date), 'yyyy-MM-dd')
        });
      }
    }
  }, [isEditMode, id, state.appointments]);

  // Initialize form with data from location state (if navigating from calendar)
  useEffect(() => {
    if (location.state) {
      const { date, hour } = location.state as { date?: Date; hour?: number };
      
      if (date) {
        setFormData(prev => ({
          ...prev,
          date: format(date, 'yyyy-MM-dd')
        }));
      }
      
      if (hour !== undefined) {
        const start = `${hour.toString().padStart(2, '0')}:00`;
        const end = `${(hour + 1).toString().padStart(2, '0')}:00`;
        
        setFormData(prev => ({
          ...prev,
          startTime: start,
          endTime: end
        }));
      }
    }
  }, [location.state]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is updated
    if (formErrors[name]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      errors.title = "Il titolo è obbligatorio";
    }
    
    if (!formData.date) {
      errors.date = "Seleziona una data";
    }
    
    if (!formData.startTime) {
      errors.startTime = "Seleziona un orario di inizio";
    }
    
    if (!formData.endTime) {
      errors.endTime = "Seleziona un orario di fine";
    }
    
    if (formData.startTime >= formData.endTime) {
      errors.endTime = "L'orario di fine deve essere successivo all'orario di inizio";
    }
    
    if (formData.referentEmail && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.referentEmail)) {
      errors.referentEmail = "Formato email non valido";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      if (isEditMode && id) {
        const appointment = state.appointments.find(a => a.id === id);
        
        if (appointment) {
          await updateAppointment({
            ...appointment,
            ...formData,
            updatedAt: new Date().toISOString()
          });
          
          setSuccessMessage('Appuntamento aggiornato con successo');
        }
      } else {
        await addAppointment({
          ...formData,
          status: 'scheduled',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        
        setSuccessMessage('Appuntamento creato con successo');
      }
      
      setTimeout(() => {
        navigate('/admin/appointments/calendar');
      }, 1500);
    } catch (error) {
      console.error('Error saving appointment:', error);
      setFormErrors({ submit: 'Errore durante il salvataggio. Riprova.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (state.isLoading) {
    return (
      <div className="page-container flex items-center justify-center h-full">
        <LoadingSpinner size="lg" text="Caricamento..." />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center">
          <div className="flex-shrink-0 bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg p-4 mr-4">
            <CalendarPlus className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {isEditMode ? 'Modifica Appuntamento' : 'Nuovo Appuntamento'}
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              {isEditMode 
                ? 'Modifica i dettagli dell\'appuntamento esistente' 
                : 'Pianifica un nuovo appuntamento'
              }
            </p>
          </div>
        </div>
      </div>

      {successMessage && (
        <div className="mb-6 bg-green-50 border-l-4 border-green-400 p-4">
          <div className="flex">
            <CheckCircle className="h-5 w-5 text-green-400" />
            <p className="ml-3 text-sm text-green-700">{successMessage}</p>
          </div>
        </div>
      )}

      {formErrors.submit && (
        <div className="mb-6 bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <AlertTriangle className="h-5 w-5 text-red-400" />
            <p className="ml-3 text-sm text-red-700">{formErrors.submit}</p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <BasicInfoSection 
          formData={formData}
          onChange={handleInputChange}
          errors={formErrors}
          clients={state.clients}
          devices={formData.clientId ? 
            state.clients.find(c => c.id === formData.clientId)?.devices || [] : 
            []
          }
        />
        
        <DateTimeSection 
          formData={formData}
          onChange={handleInputChange}
          errors={formErrors}
        />
        
        <ContactSection 
          formData={formData}
          onChange={handleInputChange}
          errors={formErrors}
        />
        
        <NotesSection 
          formData={formData}
          onChange={handleInputChange}
        />
        
        {/* Form Actions */}
        <div className="flex justify-between pt-6">
          <button
            type="button"
            onClick={() => navigate('/admin/appointments/calendar')}
            className="macos-button flex items-center"
          >
            <X className="h-5 w-5 mr-1" />
            Annulla
          </button>
          
          <button
            type="submit"
            className="macos-button-primary flex items-center"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <LoadingSpinner size="sm" color="white" />
            ) : (
              <>
                <Save className="h-5 w-5 mr-1" />
                {isEditMode ? 'Aggiorna Appuntamento' : 'Crea Appuntamento'}
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AppointmentForm;