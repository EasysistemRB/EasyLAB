import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, Search, Filter, AlertTriangle, CheckCircle, 
  Clock, MessageSquare, User, Calendar, ChevronDown,
  ChevronUp, Edit, Eye, Trash2, RefreshCw, BarChart2,
  CalendarPlus, CalendarCheck, CalendarDays, CalendarClock
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

const AppointmentList: React.FC = () => {
  const { state } = useData();
  const navigate = useNavigate();
  
  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [clientFilter, setClientFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  
  // Table state
  const [sortField, setSortField] = useState<string>('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [filteredAppointments, setFilteredAppointments] = useState(state.appointments);
  const [refreshing, setRefreshing] = useState(false);

  // Apply filters and sorting
  useEffect(() => {
    if (state.isLoading) return;
    
    let filtered = [...state.appointments];
    
    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(appointment => 
        appointment.title.toLowerCase().includes(searchLower) || 
        appointment.description?.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(appointment => appointment.status === statusFilter);
    }
    
    // Apply client filter
    if (clientFilter !== 'all') {
      filtered = filtered.filter(appointment => appointment.clientId === clientFilter);
    }
    
    // Apply date filter
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    switch (dateFilter) {
      case 'today':
        filtered = filtered.filter(appointment => {
          const appointmentDate = new Date(appointment.date);
          appointmentDate.setHours(0, 0, 0, 0);
          return appointmentDate.getTime() === today.getTime();
        });
        break;
      case 'week':
        const weekFromNow = new Date(today);
        weekFromNow.setDate(weekFromNow.getDate() + 7);
        filtered = filtered.filter(appointment => {
          const appointmentDate = new Date(appointment.date);
          return appointmentDate >= today && appointmentDate <= weekFromNow;
        });
        break;
      case 'month':
        const monthFromNow = new Date(today);
        monthFromNow.setMonth(monthFromNow.getMonth() + 1);
        filtered = filtered.filter(appointment => {
          const appointmentDate = new Date(appointment.date);
          return appointmentDate >= today && appointmentDate <= monthFromNow;
        });
        break;
    }
    
    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortField) {
        case 'date':
          comparison = new Date(a.date).getTime() - new Date(b.date).getTime();
          break;
        case 'title':
          comparison = a.title.localeCompare(b.title);
          break;
        case 'client':
          const clientA = state.clients.find(c => c.id === a.clientId)?.name || '';
          const clientB = state.clients.find(c => c.id === b.clientId)?.name || '';
          comparison = clientA.localeCompare(clientB);
          break;
        case 'status':
          comparison = a.status.localeCompare(b.status);
          break;
        case 'createdAt':
          comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          break;
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });
    
    setFilteredAppointments(filtered);
  }, [
    state.isLoading,
    state.appointments,
    state.clients,
    search,
    statusFilter,
    clientFilter,
    dateFilter,
    sortField,
    sortDirection
  ]);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const renderSortIcon = (field: string) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? 
      <ChevronUp className="h-4 w-4 ml-1" /> : 
      <ChevronDown className="h-4 w-4 ml-1" />;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'rescheduled':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'scheduled':
        return 'Programmato';
      case 'completed':
        return 'Completato';
      case 'cancelled':
        return 'Annullato';
      case 'rescheduled':
        return 'Riprogrammato';
      default:
        return status;
    }
  };

  const getClientName = (clientId: string) => {
    const client = state.clients.find(c => c.id === clientId);
    return client ? client.name : 'Cliente sconosciuto';
  };

  if (state.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg p-4 mr-4">
              <CalendarDays className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Elenco Appuntamenti</h1>
              <p className="mt-1 text-sm text-gray-500">
                Gestisci e monitora tutti gli appuntamenti programmati
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={() => navigate('/admin/appointments/calendar')}
              className="macos-button flex items-center"
            >
              <Calendar className="h-4 w-4 mr-1" />
              Calendario
            </button>
            
            <button
              onClick={() => navigate('/admin/appointments/new')}
              className="macos-button-primary flex items-center space-x-2 px-4 py-2 transform hover:scale-105 transition-all duration-200"
            >
              <CalendarPlus className="h-5 w-5" />
              <span>Nuovo Appuntamento</span>
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-8">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-blue-100">
                <CalendarClock className="h-6 w-6 text-blue-600" />
              </div>
              <span className="text-2xl font-semibold text-blue-600">
                {filteredAppointments.filter(a => a.status === 'scheduled').length}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Programmati</p>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-green-100">
                <CalendarCheck className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-2xl font-semibold text-green-600">
                {filteredAppointments.filter(a => a.status === 'completed').length}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Completati</p>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-yellow-100">
                <Clock className="h-6 w-6 text-yellow-600" />
              </div>
              <span className="text-2xl font-semibold text-yellow-600">
                {filteredAppointments.filter(a => a.status === 'rescheduled').length}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Riprogrammati</p>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-red-100">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <span className="text-2xl font-semibold text-red-600">
                {filteredAppointments.filter(a => a.status === 'cancelled').length}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Annullati</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white shadow-lg rounded-lg mb-6">
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="flex-1">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Cerca appuntamenti..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="form-input pl-10 w-full rounded-lg border-gray-300 focus:border-primary-500 focus:ring focus:ring-primary-200"
                />
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="form-select rounded-lg border-gray-300 focus:border-primary-500 focus:ring focus:ring-primary-200"
              >
                <option value="all">Tutti gli stati</option>
                <option value="scheduled">Programmati</option>
                <option value="completed">Completati</option>
                <option value="cancelled">Annullati</option>
                <option value="rescheduled">Riprogrammati</option>
              </select>
              
              <select
                value={clientFilter}
                onChange={(e) => setClientFilter(e.target.value)}
                className="form-select rounded-lg border-gray-300 focus:border-primary-500 focus:ring focus:ring-primary-200"
              >
                <option value="all">Tutti i clienti</option>
                {state.clients.map((client) => (
                  <option key={client.id} value={client.id}>
                    {client.name}
                  </option>
                ))}
              </select>
              
              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value as any)}
                className="form-select rounded-lg border-gray-300 focus:border-primary-500 focus:ring focus:ring-primary-200"
              >
                <option value="all">Tutte le date</option>
                <option value="today">Oggi</option>
                <option value="week">Prossimi 7 giorni</option>
                <option value="month">Prossimo mese</option>
              </select>
            </div>
          </div>
          
          <div className="mt-2 text-sm text-gray-500 flex items-center">
            <Filter className="h-4 w-4 mr-1" />
            {filteredAppointments.length} appuntamenti trovati
          </div>
        </div>
      </div>
      
      {/* Appointments Table */}
      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        {filteredAppointments.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('date')}
                  >
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Data e Ora
                      {renderSortIcon('date')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('title')}
                  >
                    <div className="flex items-center">
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Titolo
                      {renderSortIcon('title')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('client')}
                  >
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-1" />
                      Cliente
                      {renderSortIcon('client')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('status')}
                  >
                    <div className="flex items-center">
                      <BarChart2 className="h-4 w-4 mr-1" />
                      Stato
                      {renderSortIcon('status')}
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Azioni
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredAppointments.map((appointment) => (
                  <tr key={appointment.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {format(new Date(appointment.date), 'EEEE d MMMM yyyy', { locale: it })}
                      </div>
                      <div className="text-sm text-gray-500 flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {appointment.startTime} - {appointment.endTime}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">{appointment.title}</div>
                      <div className="text-sm text-gray-500 truncate max-w-xs">
                        {appointment.description || "Nessuna descrizione"}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {getClientName(appointment.clientId)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(appointment.status)}`}>
                        {getStatusLabel(appointment.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={() => navigate(`/admin/appointments/${appointment.id}`)}
                          className="text-primary-600 hover:text-primary-900"
                          title="Visualizza dettagli"
                        >
                          <Eye className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => navigate(`/admin/appointments/${appointment.id}/edit`)}
                          className="text-blue-600 hover:text-blue-900"
                          title="Modifica appuntamento"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => {/* Handle delete */}}
                          className="text-red-600 hover:text-red-900"
                          title="Elimina appuntamento"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-6 text-center">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 mb-4">Nessun appuntamento trovato con i filtri attuali.</p>
            <button
              onClick={() => {
                setSearch('');
                setStatusFilter('all');
                setClientFilter('all');
                setDateFilter('all');
              }}
              className="text-primary-600 hover:text-primary-800 font-medium"
            >
              Cancella tutti i filtri
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AppointmentList;