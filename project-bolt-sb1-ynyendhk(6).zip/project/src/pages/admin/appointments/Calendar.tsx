import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, ChevronRight, Plus, Clock,
  Calendar as CalendarIcon, Users, AlertTriangle,
  RefreshCcw, AlertCircle, CheckCircle, Zap,
  Info, Ban, CalendarPlus, CalendarCheck, CalendarDays
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { format, addDays, subDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO, addWeeks, subWeeks, isValid, isWeekend, startOfMonth, endOfMonth, addMonths, subMonths } from 'date-fns';
import { it } from 'date-fns/locale';
import { isBusinessDay, isItalianHoliday, getBusinessHours, formatTime } from '../../../utils/dateUtils';

const Calendar: React.FC = () => {
  const { state } = useData();
  const navigate = useNavigate();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'day' | 'week' | 'month'>('week');
  const [days, setDays] = useState<Date[]>([]);
  
  useEffect(() => {
    let daysToShow: Date[] = [];
    
    if (view === 'day') {
      daysToShow = [currentDate];
    } else if (view === 'week') {
      const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
      const weekEnd = endOfWeek(currentDate, { weekStartsOn: 1 });
      daysToShow = eachDayOfInterval({ start: weekStart, end: weekEnd });
    } else if (view === 'month') {
      const monthStart = startOfMonth(currentDate);
      const monthEnd = endOfMonth(currentDate);
      
      // Get the first Monday before or on the start of the month
      let viewStart = startOfWeek(monthStart, { weekStartsOn: 1 });
      
      // Get the last Sunday after or on the end of the month
      let viewEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
      
      daysToShow = eachDayOfInterval({ start: viewStart, end: viewEnd });
    }
    
    setDays(daysToShow);
  }, [currentDate, view]);
  
  const navigateToday = () => {
    setCurrentDate(new Date());
  };
  
  const navigatePrevious = () => {
    if (view === 'day') {
      setCurrentDate(subDays(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(subWeeks(currentDate, 1));
    } else if (view === 'month') {
      setCurrentDate(subMonths(currentDate, 1));
    }
  };
  
  const navigateNext = () => {
    if (view === 'day') {
      setCurrentDate(addDays(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(addWeeks(currentDate, 1));
    } else if (view === 'month') {
      setCurrentDate(addMonths(currentDate, 1));
    }
  };
  
  const getAppointmentsForDay = (date: Date) => {
    if (state.isLoading) return [];
    
    return state.appointments.filter(appointment => {
      try {
        // Safely parse the date and check if it's valid
        const appointmentDate = parseISO(appointment.date);
        return isValid(appointmentDate) && isSameDay(appointmentDate, date);
      } catch (error) {
        console.error('Invalid date format:', appointment.date);
        return false;
      }
    }).sort((a, b) => {
      // Sort by time
      return a.startTime.localeCompare(b.startTime);
    });
  };
  
  const getClientName = (clientId: string) => {
    if (!clientId || clientId === '0') return 'Nessun cliente';
    const client = state.clients.find(c => c.id === clientId);
    return client ? client.name : 'Cliente sconosciuto';
  };
  
  const getAppointmentStatusColor = (status: string, rescheduleCount: number = 0) => {
    // If the appointment is rescheduled, return specific styles based on reschedule count
    if (status === 'rescheduled' || rescheduleCount > 0) {
      if (rescheduleCount === 1) {
        return 'bg-yellow-100 text-yellow-800 border-yellow-200 appointment-pulse-mild';
      } else if (rescheduleCount === 2) {
        return 'bg-orange-100 text-orange-800 border-orange-200 appointment-pulse-medium';
      } else if (rescheduleCount >= 3) {
        return 'bg-red-100 text-red-800 border-red-200 appointment-pulse-strong';
      }
      return 'bg-yellow-100 text-yellow-800 border-yellow-200 appointment-pulse-mild';
    }
    
    // Otherwise, return styles based on status
    switch (status) {
      case 'scheduled':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };
  
  const getRescheduleStatusIcon = (rescheduleCount: number) => {
    if (rescheduleCount === 1) {
      return <AlertCircle className="h-3 w-3 text-yellow-600 mr-1" title="Riprogrammato una volta" />;
    } else if (rescheduleCount === 2) {
      return <AlertTriangle className="h-3 w-3 text-orange-600 mr-1" title="Riprogrammato due volte" />;
    } else if (rescheduleCount >= 3) {
      return <Zap className="h-3 w-3 text-red-600 mr-1" title="Riprogrammato tre o più volte" />;
    }
    return null;
  };
  
  // Safely format a date with error handling
  const safeFormatDate = (dateString: string, formatStr: string) => {
    try {
      const date = parseISO(dateString);
      if (!isValid(date)) {
        throw new Error('Invalid date');
      }
      return format(date, formatStr, { locale: it });
    } catch (error) {
      console.error('Error formatting date:', error);
      return 'Data non valida';
    }
  };
  
  // Business hours: 9:00 - 18:00
  const timeSlots = getBusinessHours();
  
  if (state.isLoading) {
    return (
      <div className="page-container flex items-center justify-center h-full">
        <LoadingSpinner size="lg" text="Caricamento calendario..." />
      </div>
    );
  }
  
  return (
    <div className="page-container">
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="page-title mb-1">Agenda Appuntamenti</h1>
          <p className="text-gray-600">Gestisci tutti gli appuntamenti in un unico posto</p>
        </div>
        
        <div className="mt-4 sm:mt-0 flex space-x-2">
          <button
            onClick={() => navigate('/admin/appointments/new')}
            className="macos-button-primary flex items-center space-x-2 px-4 py-2 transform hover:scale-105 transition-all duration-200"
          >
            <CalendarPlus className="h-5 w-5" />
            <span>Nuovo Appuntamento</span>
          </button>
        </div>
      </div>
      
      {/* Calendar Controls */}
      <div className="bg-white p-4 shadow rounded-lg mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={navigatePrevious}
              className="p-2 rounded-full hover:bg-gray-100"
            >
              <ChevronLeft className="h-5 w-5 text-gray-600" />
            </button>
            
            <h2 className="text-xl font-semibold">
              {view === 'day' ? (
                format(currentDate, 'EEEE d MMMM yyyy', { locale: it })
              ) : view === 'week' ? (
                <>
                  {format(days[0] || new Date(), 'd MMMM', { locale: it })} - {format(days[days.length - 1] || new Date(), 'd MMMM yyyy', { locale: it })}
                </>
              ) : (
                format(currentDate, 'MMMM yyyy', { locale: it })
              )}
            </h2>
            
            <button
              onClick={navigateNext}
              className="p-2 rounded-full hover:bg-gray-100"
            >
              <ChevronRight className="h-5 w-5 text-gray-600" />
            </button>
          </div>
          
          <div className="mt-4 sm:mt-0 flex items-center space-x-2">
            <button
              onClick={navigateToday}
              className="px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50"
            >
              Oggi
            </button>
            
            <div className="border border-gray-300 rounded overflow-hidden flex">
              <button
                onClick={() => setView('day')}
                className={`px-3 py-1 text-sm ${view === 'day' ? 'bg-primary-600 text-white' : 'hover:bg-gray-50'}`}
              >
                Giorno
              </button>
              <button
                onClick={() => setView('week')}
                className={`px-3 py-1 text-sm ${view === 'week' ? 'bg-primary-600 text-white' : 'hover:bg-gray-50'}`}
              >
                Settimana
              </button>
              <button
                onClick={() => setView('month')}
                className={`px-3 py-1 text-sm ${view === 'month' ? 'bg-primary-600 text-white' : 'hover:bg-gray-50'}`}
              >
                Mese
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Calendar Grid */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        {/* Days Header */}
        <div className="grid grid-cols-1 divide-y divide-gray-200 sm:divide-y-0 sm:divide-x sm:grid-cols-7">
          {days.slice(0, Math.min(days.length, 7)).map((day, index) => {
            const isWeekendDay = isWeekend(day);
            const { isHoliday, description } = isItalianHoliday(day);
            const isToday = isSameDay(day, new Date());
            
            return (
              <div 
                key={index} 
                className={`p-2 ${isToday ? 'bg-blue-50' : ''} ${isWeekendDay || isHoliday ? 'bg-gray-100' : ''}`}
              >
                <p className={`text-center font-medium ${isWeekendDay ? 'text-gray-500' : ''} ${isHoliday ? 'text-red-600' : ''}`}>
                  {format(day, 'EEEE', { locale: it })}
                </p>
                <p className={`text-center text-lg ${isWeekendDay ? 'text-gray-500' : ''} ${isHoliday ? 'text-red-600' : ''}`}>
                  {format(day, 'd', { locale: it })}
                </p>
                {isHoliday && (
                  <p className="text-center text-xs text-red-600 mt-1">
                    {description}
                  </p>
                )}
                {isWeekendDay && !isHoliday && (
                  <div className="flex items-center justify-center mt-1">
                    <Ban className="h-3 w-3 text-gray-500 mr-1" />
                    <span className="text-xs text-gray-500">Non lavorativo</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        
        {/* Time Slots and Appointments */}
        {view !== 'month' ? (
          <div className="grid grid-cols-1 sm:grid-cols-7 divide-x divide-gray-200">
            {days.map((day, dayIndex) => {
              const isBusinessDayToday = isBusinessDay(day);
              const dayAppointments = getAppointmentsForDay(day);
              
              return (
                <div key={dayIndex} className={`col-span-1 ${!isBusinessDayToday ? 'bg-gray-50' : ''}`}>
                  {timeSlots.map((hour, hourIndex) => {
                    const hourAppointments = dayAppointments.filter(app => {
                      const appHour = parseInt(app.startTime.split(':')[0]);
                      return appHour === hour;
                    });
                    
                    // Is this lunch time (13:00)?
                    const isLunchHour = hour === 13;
                    
                    return (
                      <div 
                        key={hourIndex}
                        className={`p-2 min-h-[60px] border-t border-gray-200 ${
                          isLunchHour ? 'bg-yellow-50' : ''
                        }`}
                      >
                        <div className="text-xs text-gray-500 mb-1">{hour}:00</div>
                        
                        {!isBusinessDayToday ? (
                          <div className="h-8 rounded border border-dashed border-gray-300 bg-gray-100 flex items-center justify-center text-xs text-gray-400">
                            <Ban className="h-3 w-3 mr-1" /> Non disponibile
                          </div>
                        ) : hourAppointments.length > 0 ? (
                          hourAppointments.map(appointment => {
                            // Determine if appointment is rescheduled and the count
                            const rescheduleCount = appointment.status === 'rescheduled' ? 
                              (appointment.rescheduleCount || 1) : 0;
                              
                            return (
                              <div 
                                key={appointment.id}
                                className={`rounded p-1 mb-1 text-xs cursor-pointer border ${getAppointmentStatusColor(appointment.status, rescheduleCount)}`}
                                onClick={() => navigate(`/admin/appointments/${appointment.id}/edit`)}
                              >
                                <div className="font-medium truncate flex items-center">
                                  {rescheduleCount > 0 && getRescheduleStatusIcon(rescheduleCount)}
                                  {appointment.title}
                                </div>
                                <div className="flex items-center mt-1">
                                  <Clock className="h-3 w-3 mr-1" />
                                  <span>{formatTime(appointment.startTime)} - {formatTime(appointment.endTime)}</span>
                                </div>
                                <div className="flex items-center mt-1">
                                  <Users className="h-3 w-3 mr-1" />
                                  <span className="truncate">{getClientName(appointment.clientId)}</span>
                                </div>
                                {appointment.referent && (
                                  <div className="flex items-center mt-1 text-xs text-gray-500">
                                    <span className="truncate">Ref: {appointment.referent}</span>
                                  </div>
                                )}
                              </div>
                            );
                          })
                        ) : (
                          isBusinessDayToday && !isLunchHour && (
                            <div 
                              className="h-8 rounded border border-dashed border-gray-300 bg-gray-50 flex items-center justify-center text-xs text-gray-400 cursor-pointer hover:bg-gray-100"
                              onClick={() => navigate('/admin/appointments/new', { state: { date: day, hour } })}
                            >
                              <Plus className="h-3 w-3 mr-1" /> Nuovo
                            </div>
                          )
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        ) : (
          // Month view - calendar grid
          <div className="grid grid-cols-7 gap-1 p-2">
            {days.map((day, index) => {
              const isWeekendDay = isWeekend(day);
              const { isHoliday } = isItalianHoliday(day);
              const isToday = isSameDay(day, new Date());
              const isCurrentMonth = day.getMonth() === currentDate.getMonth();
              const dayAppointments = getAppointmentsForDay(day);
              
              return (
                <div 
                  key={index}
                  className={`p-1 min-h-[100px] rounded border ${
                    isToday ? 'bg-blue-50 border-blue-300' : 
                    isWeekendDay || isHoliday ? 'bg-gray-100 border-gray-200' : 
                    !isCurrentMonth ? 'bg-gray-50 border-gray-200 opacity-50' : 
                    'bg-white border-gray-200'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className={`text-sm font-medium ${
                      isToday ? 'text-blue-700' : 
                      isWeekendDay ? 'text-gray-500' : 
                      isHoliday ? 'text-red-600' : 
                      !isCurrentMonth ? 'text-gray-400' : 
                      'text-gray-700'
                    }`}>
                      {format(day, 'd', { locale: it })}
                    </span>
                    {isBusinessDay(day) && isCurrentMonth && (
                      <button 
                        className="text-xs text-primary-600 hover:text-primary-800"
                        onClick={() => navigate('/admin/appointments/new', { state: { date: day, hour: 9 } })}
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                  
                  <div className="space-y-1 overflow-auto max-h-[80px]">
                    {dayAppointments.slice(0, 3).map((appointment) => {
                      const rescheduleCount = appointment.status === 'rescheduled' ? 
                        (appointment.rescheduleCount || 1) : 0;
                        
                      return (
                        <div 
                          key={appointment.id}
                          className={`rounded px-1 py-0.5 text-xs cursor-pointer border ${getAppointmentStatusColor(appointment.status, rescheduleCount)}`}
                          onClick={() => navigate(`/admin/appointments/${appointment.id}/edit`)}
                        >
                          <div className="font-medium truncate text-[10px] flex items-center">
                            {rescheduleCount > 0 && getRescheduleStatusIcon(rescheduleCount)}
                            <span className="truncate">{appointment.title}</span>
                          </div>
                          <div className="flex items-center text-[10px]">
                            <Clock className="h-2 w-2 mr-0.5" />
                            <span>{formatTime(appointment.startTime)}</span>
                          </div>
                        </div>
                      );
                    })}
                    {dayAppointments.length > 3 && (
                      <div className="text-[10px] text-center text-primary-600">
                        +{dayAppointments.length - 3} altri
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      
      {/* Legend */}
      <div className="mt-4 bg-white p-4 rounded-lg shadow">
        <h3 className="text-sm font-medium mb-2">Legenda</h3>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-blue-100 border border-blue-200 mr-2"></div>
            <span className="text-sm">Programmato</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-green-100 border border-green-200 mr-2"></div>
            <span className="text-sm">Completato</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-red-100 border border-red-200 mr-2"></div>
            <span className="text-sm">Annullato</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-yellow-100 border border-yellow-200 mr-2 appointment-pulse-mild"></div>
            <span className="text-sm">Riprogrammato (1)</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-orange-100 border border-orange-200 mr-2 appointment-pulse-medium"></div>
            <span className="text-sm">Riprogrammato (2)</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-red-100 border border-red-200 mr-2 appointment-pulse-strong"></div>
            <span className="text-sm">Riprogrammato (3+)</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-yellow-50 mr-2"></div>
            <span className="text-sm">Pausa pranzo</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 rounded bg-gray-100 mr-2"></div>
            <span className="text-sm">Weekend/Festivo</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Calendar;