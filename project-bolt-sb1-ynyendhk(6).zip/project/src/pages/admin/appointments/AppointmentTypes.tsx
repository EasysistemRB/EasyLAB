import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, Search, Filter, AlertTriangle, CheckCircle, 
  Clock, MessageSquare, User, Calendar, ChevronDown,
  ChevronUp, Edit, Eye, Trash2, RefreshCw, BarChart2,
  AlertCircle, Archive, TicketCheck, FileCheck, Store,
  Briefcase, UserCircle, Home, CreditCard, Globe, Database,
  MessageCircle, Shield, Info, Building, Mail, Phone,
  FileText, Download, Upload, Smartphone, Network, Wifi,
  Cpu, Wrench, PenTool as Tool, Settings, Activity, Zap,
  Bell, X, Save, Users
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { format, subDays } from 'date-fns';
import { it } from 'date-fns/locale';

const appointmentTypes = [
  { 
    id: 'consulenza', 
    name: 'Consulenza', 
    icon: MessageSquare, 
    color: 'bg-blue-100 text-blue-700 border-blue-300',
    description: 'Consulenza tecnica e supporto',
    duration: 60,
    price: 80
  },
  { 
    id: 'commerciale', 
    name: 'Commerciale', 
    icon: Users, 
    color: 'bg-purple-100 text-purple-800 border-purple-300',
    description: 'Incontri commerciali e preventivi',
    duration: 45,
    price: 0
  },
  { 
    id: 'assistenza-software', 
    name: 'Assistenza Software', 
    icon: Tool, 
    color: 'bg-green-100 text-green-800 border-green-300',
    description: 'Supporto e manutenzione software',
    duration: 30,
    price: 50
  },
  { 
    id: 'hardware', 
    name: 'Hardware', 
    icon: Tool, 
    color: 'bg-red-100 text-red-800 border-red-300',
    description: 'Interventi su hardware',
    duration: 90,
    price: 100
  },
  { 
    id: 'manutenzione', 
    name: 'Manutenzione', 
    icon: Tool, 
    color: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    description: 'Manutenzione programmata',
    duration: 120,
    price: 150
  }
];

const AppointmentTypes: React.FC = () => {
  const { state } = useData();
  const navigate = useNavigate();
  
  const [isLoading, setIsLoading] = useState(false);
  const [showNewTypeModal, setShowNewTypeModal] = useState(false);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');
  
  // New type form state
  const [newType, setNewType] = useState({
    name: '',
    icon: 'MessageSquare',
    color: 'blue',
    description: '',
    duration: 60,
    price: 0,
    isEnabled: true
  });

  // Statistics state
  const [statistics, setStatistics] = useState({
    total: 0,
    statusCounts: {
      resolved: 0,
      pending: 0,
      cancelled: 0
    },
    averageResponseTime: 0,
    averageResolutionTime: 0,
    typeDistribution: {} as Record<string, number>,
    trends: {
      weekly: 0,
      monthly: 0
    }
  });

  // Calculate statistics
  useEffect(() => {
    if (!state.isLoading) {
      const total = state.appointments.length;
      const resolved = state.appointments.filter(a => a.status === 'completed').length;
      const pending = state.appointments.filter(a => a.status === 'scheduled').length;
      const cancelled = state.appointments.filter(a => a.status === 'cancelled').length;
      
      // Calculate type distribution
      const typeDistribution = state.appointments.reduce((acc, appointment) => {
        const type = appointment.appointmentType || 'other';
        acc[type] = (acc[type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      // Calculate trends
      const now = new Date();
      const lastWeek = subDays(now, 7);
      const lastMonth = subDays(now, 30);
      
      const weeklyAppointments = state.appointments.filter(a => 
        new Date(a.date) >= lastWeek
      ).length;
      
      const monthlyAppointments = state.appointments.filter(a => 
        new Date(a.date) >= lastMonth
      ).length;
      
      // Calculate average response time (in minutes)
      const responseTimesSum = state.appointments.reduce((sum, appointment) => {
        if (appointment.firstResponseAt) {
          const created = new Date(appointment.createdAt).getTime();
          const responded = new Date(appointment.firstResponseAt).getTime();
          return sum + ((responded - created) / (1000 * 60));
        }
        return sum;
      }, 0);
      
      const averageResponseTime = total > 0 ? responseTimesSum / total : 0;
      
      setStatistics({
        total,
        statusCounts: {
          resolved,
          pending,
          cancelled
        },
        averageResponseTime,
        averageResolutionTime: 0,
        typeDistribution,
        trends: {
          weekly: weeklyAppointments,
          monthly: monthlyAppointments
        }
      });
    }
  }, [state.isLoading, state.appointments]);

  // Filter appointment types based on search
  const filteredTypes = appointmentTypes.filter(type =>
    type.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    type.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (state.isLoading) {
    return (
      <div className="page-container flex items-center justify-center h-full">
        <LoadingSpinner size="lg" text="Caricamento..." />
      </div>
    );
  }

  return (
    <div className="page-container">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg p-4 mr-4">
              <Calendar className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Tipologie di Appuntamento</h1>
              <p className="mt-1 text-sm text-gray-500">
                Gestisci e configura le diverse tipologie di appuntamento disponibili
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowNewTypeModal(true)}
              className="macos-button-primary flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Nuova Tipologia
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-8">
          <div className="macos-card">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-blue-100">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
              <span className="text-2xl font-semibold text-blue-600">
                {appointmentTypes.length}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Tipologie Totali</p>
          </div>

          <div className="macos-card">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-green-100">
                <Activity className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-2xl font-semibold text-green-600">
                {statistics.trends.weekly}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Ultimi 7 giorni</p>
          </div>

          <div className="macos-card">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-purple-100">
                <BarChart2 className="h-6 w-6 text-purple-600" />
              </div>
              <span className="text-2xl font-semibold text-purple-600">
                {statistics.trends.monthly}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Ultimo mese</p>
          </div>

          <div className="macos-card">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-yellow-100">
                <Clock className="h-6 w-6 text-yellow-600" />
              </div>
              <span className="text-2xl font-semibold text-yellow-600">
                {Math.round(statistics.averageResponseTime)} min
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Tempo Medio</p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="macos-window mb-6">
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="flex-1">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Cerca tipologie..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="macos-input pl-10"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value as 'week' | 'month' | 'year')}
                className="macos-input"
              >
                <option value="week">Ultima settimana</option>
                <option value="month">Ultimo mese</option>
                <option value="year">Ultimo anno</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Appointment Types Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {filteredTypes.map((type) => {
          const TypeIcon = type.icon;
          const appointmentsCount = state.appointments.filter(a => 
            a.appointmentType === type.id
          ).length;
          
          return (
            <div 
              key={type.id}
              className="macos-card"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-lg ${type.color}`}>
                    <TypeIcon className="h-6 w-6" />
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-500">
                      {appointmentsCount} appuntamenti
                    </span>
                    {type.price > 0 && (
                      <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                        €{type.price}/h
                      </span>
                    )}
                  </div>
                </div>
                
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {type.name}
                </h3>
                
                <p className="text-gray-500 text-sm mb-4">
                  {type.description}
                </p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {type.duration} min
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {appointmentsCount} totali
                  </div>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setSelectedType(type.id)}
                    className="macos-button flex items-center"
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    Dettagli
                  </button>
                  
                  <button
                    onClick={() => navigate(`/admin/appointments/types/${type.id}/edit`)}
                    className="macos-button-primary flex items-center"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Modifica
                  </button>
                </div>
              </div>

              {/* Progress bar showing utilization */}
              <div className="h-1 bg-gray-100">
                <div 
                  className="h-full bg-primary-500 transition-all duration-300"
                  style={{ 
                    width: `${Math.min((appointmentsCount / (statistics.total || 1)) * 100, 100)}%` 
                  }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Type Details Modal */}
      {selectedType && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="macos-window max-w-2xl w-full mx-4">
            <div className="macos-window-header">
              <h3 className="text-lg font-medium">Dettagli Tipologia</h3>
              <button
                onClick={() => setSelectedType(null)}
                className="macos-button"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="macos-window-content">
              {/* Type details content */}
              <div className="space-y-4">
                {/* Add detailed statistics and information here */}
              </div>
              
              <div className="mt-6 flex justify-end">
                <button
                  onClick={() => setSelectedType(null)}
                  className="macos-button"
                >
                  Chiudi
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Type Modal */}
      {showNewTypeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="macos-window max-w-2xl w-full mx-4">
            <div className="macos-window-header">
              <h3 className="text-lg font-medium">Nuova Tipologia</h3>
              <button
                onClick={() => setShowNewTypeModal(false)}
                className="macos-button"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="macos-window-content">
              <form className="space-y-4">
                <div>
                  <label className="form-label">
                    Nome
                  </label>
                  <input
                    type="text"
                    value={newType.name}
                    onChange={(e) => setNewType({ ...newType, name: e.target.value })}
                    className="macos-input"
                  />
                </div>

                <div>
                  <label className="form-label">
                    Descrizione
                  </label>
                  <textarea
                    value={newType.description}
                    onChange={(e) => setNewType({ ...newType, description: e.target.value })}
                    rows={3}
                    className="macos-input"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="form-label">
                      Durata (minuti)
                    </label>
                    <input
                      type="number"
                      value={newType.duration}
                      onChange={(e) => setNewType({ ...newType, duration: parseInt(e.target.value) })}
                      className="macos-input"
                    />
                  </div>

                  <div>
                    <label className="form-label">
                      Prezzo (€/h)
                    </label>
                    <input
                      type="number"
                      value={newType.price}
                      onChange={(e) => setNewType({ ...newType, price: parseInt(e.target.value) })}
                      className="macos-input"
                    />
                  </div>
                </div>

                <div>
                  <label className="form-label">
                    Colore
                  </label>
                  <select
                    value={newType.color}
                    onChange={(e) => setNewType({ ...newType, color: e.target.value })}
                    className="macos-input"
                  >
                    <option value="blue">Blu</option>
                    <option value="green">Verde</option>
                    <option value="red">Rosso</option>
                    <option value="yellow">Giallo</option>
                    <option value="purple">Viola</option>
                  </select>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={newType.isEnabled}
                    onChange={(e) => setNewType({ ...newType, isEnabled: e.target.checked })}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label className="ml-2 block text-sm text-gray-900">
                    Tipologia attiva
                  </label>
                </div>
              </form>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => setShowNewTypeModal(false)}
                  className="macos-button"
                >
                  Annulla
                </button>
                <button
                  onClick={() => {
                    // Handle save
                    setShowNewTypeModal(false);
                  }}
                  className="macos-button-primary flex items-center"
                >
                  <Save className="h-4 w-4 mr-1" />
                  Salva
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AppointmentTypes;