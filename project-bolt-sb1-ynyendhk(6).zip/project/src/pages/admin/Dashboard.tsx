import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Calendar, TicketCheck, Building, TrendingUp, ArrowUpRight, Clock, CheckCircle, Laptop, FileText, RefreshCw, Asterisk as CashRegister, Printer, Activity, ChevronRight, Zap, MessageSquare, Phone, Mail, Plus, Search } from 'lucide-react';
import { useData } from '../../context/DataContext';
import LoadingSpinner from '../../components/LoadingSpinner';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

const Dashboard: React.FC = () => {
  const { state } = useData();
  const navigate = useNavigate();
  const [refreshing, setRefreshing] = useState(false);
  
  // Calculate statistics
  const stats = {
    clients: {
      total: state.clients.length,
      active: state.clients.filter(c => !c.isInactive).length,
      withDevices: state.clients.filter(c => c.devices && c.devices.length > 0).length
    },
    appointments: {
      total: state.appointments.length,
      today: state.appointments.filter(a => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const appDate = new Date(a.date);
        appDate.setHours(0, 0, 0, 0);
        return appDate.getTime() === today.getTime();
      }).length,
      upcoming: state.appointments.filter(a => new Date(a.date) > new Date()).length
    },
    tickets: {
      total: state.tickets.length,
      open: state.tickets.filter(t => t.status === 'open').length,
      critical: state.tickets.filter(t => t.priority === 'critical').length
    }
  };

  if (state.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-medium text-gray-900">Dashboard</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Cerca..."
                  className="macos-input pl-9 pr-4 py-1.5 w-64"
                />
              </div>
              
              <button 
                onClick={() => setRefreshing(true)}
                className="macos-icon-button"
              >
                <RefreshCw className={`h-5 w-5 text-gray-500 ${refreshing ? 'animate-spin' : ''}`} />
              </button>
              
              <button className="macos-button-primary flex items-center">
                <Plus className="h-4 w-4 mr-1" />
                Nuovo
              </button>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="macos-card">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-blue-50">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <span className="text-2xl font-semibold text-gray-900">{stats.clients.total}</span>
            </div>
            <h3 className="mt-4 text-base font-medium text-gray-900">Clienti</h3>
            <div className="mt-2 flex items-center text-sm">
              <ArrowUpRight className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-green-700 font-medium">
                {Math.round((stats.clients.active / stats.clients.total) * 100)}%
              </span>
              <span className="text-gray-500 ml-1">attivi</span>
            </div>
          </div>

          <div className="macos-card">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-green-50">
                <Calendar className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-2xl font-semibold text-gray-900">{stats.appointments.today}</span>
            </div>
            <h3 className="mt-4 text-base font-medium text-gray-900">Appuntamenti Oggi</h3>
            <div className="mt-2 flex items-center text-sm">
              <Clock className="h-4 w-4 text-gray-400 mr-1" />
              <span className="text-gray-500">{stats.appointments.upcoming} in programma</span>
            </div>
          </div>

          <div className="macos-card">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-amber-50">
                <TicketCheck className="h-6 w-6 text-amber-600" />
              </div>
              <span className="text-2xl font-semibold text-gray-900">{stats.tickets.open}</span>
            </div>
            <h3 className="mt-4 text-base font-medium text-gray-900">Ticket Aperti</h3>
            <div className="mt-2 flex items-center text-sm">
              {stats.tickets.critical > 0 ? (
                <span className="macos-badge bg-red-100 text-red-800">
                  {stats.tickets.critical} critici
                </span>
              ) : (
                <span className="macos-badge bg-green-100 text-green-800">
                  Nessun ticket critico
                </span>
              )}
            </div>
          </div>

          <div className="macos-card">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-purple-50">
                <CashRegister className="h-6 w-6 text-purple-600" />
              </div>
              <span className="text-2xl font-semibold text-gray-900">
                {state.clients.reduce((acc, client) => 
                  acc + (client.devices?.filter(d => d.type === 'cash_register').length || 0), 0
                )}
              </span>
            </div>
            <h3 className="mt-4 text-base font-medium text-gray-900">Registratori Telematici</h3>
            <div className="mt-2 flex items-center text-sm">
              <Activity className="h-4 w-4 text-gray-400 mr-1" />
              <span className="text-gray-500">Tutti operativi</span>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Activity */}
          <div className="macos-window">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-medium text-gray-900">Attività Recenti</h2>
                <button className="macos-button">
                  Vedi tutto
                  <ChevronRight className="h-4 w-4 ml-1 inline" />
                </button>
              </div>
              
              <div className="space-y-6">
                {state.appointments.slice(0, 5).map((appointment) => (
                  <div key={appointment.id} className="flex items-start">
                    <div className="flex-shrink-0">
                      <div className="h-8 w-8 rounded-full bg-blue-50 flex items-center justify-center">
                        <Calendar className="h-4 w-4 text-blue-600" />
                      </div>
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-gray-900">{appointment.title}</p>
                        <span className="text-xs text-gray-500">
                          {format(new Date(appointment.date), 'HH:mm')}
                        </span>
                      </div>
                      <p className="mt-1 text-sm text-gray-500">
                        {format(new Date(appointment.date), 'dd MMMM yyyy', { locale: it })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-8">
            <div className="macos-window">
              <div className="p-6">
                <h2 className="text-lg font-medium text-gray-900 mb-6">Azioni Rapide</h2>
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => navigate('/admin/appointments/new')}
                    className="group p-4 rounded-lg border border-gray-200/50 hover:border-primary-500/50 hover:bg-primary-50/50 transition-all duration-200"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <Calendar className="h-5 w-5 text-primary-600" />
                      <ChevronRight className="h-4 w-4 text-gray-400 group-hover:text-primary-600 transition-colors" />
                    </div>
                    <h3 className="text-sm font-medium text-gray-900">Nuovo Appuntamento</h3>
                    <p className="mt-1 text-xs text-gray-500">Pianifica intervento</p>
                  </button>

                  <button 
                    onClick={() => navigate('/admin/tickets/new')}
                    className="group p-4 rounded-lg border border-gray-200/50 hover:border-primary-500/50 hover:bg-primary-50/50 transition-all duration-200"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <TicketCheck className="h-5 w-5 text-primary-600" />
                      <ChevronRight className="h-4 w-4 text-gray-400 group-hover:text-primary-600 transition-colors" />
                    </div>
                    <h3 className="text-sm font-medium text-gray-900">Nuovo Ticket</h3>
                    <p className="mt-1 text-xs text-gray-500">Apri assistenza</p>
                  </button>
                </div>
              </div>
            </div>

            {/* Keyboard Shortcuts */}
            <div className="macos-window">
              <div className="p-6">
                <h2 className="text-lg font-medium text-gray-900 mb-6">Scorciatoie Tastiera</h2>
                <div className="grid grid-cols-2 gap-y-4">
                  <div className="flex items-center justify-between pr-4">
                    <span className="text-sm text-gray-600">Nuovo Ticket</span>
                    <div className="flex items-center space-x-1">
                      <kbd className="px-2 py-1 text-xs font-mono bg-gray-100 rounded">⌘</kbd>
                      <kbd className="px-2 py-1 text-xs font-mono bg-gray-100 rounded">T</kbd>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pr-4">
                    <span className="text-sm text-gray-600">Nuovo Cliente</span>
                    <div className="flex items-center space-x-1">
                      <kbd className="px-2 py-1 text-xs font-mono bg-gray-100 rounded">⌘</kbd>
                      <kbd className="px-2 py-1 text-xs font-mono bg-gray-100 rounded">N</kbd>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pr-4">
                    <span className="text-sm text-gray-600">Calendario</span>
                    <div className="flex items-center space-x-1">
                      <kbd className="px-2 py-1 text-xs font-mono bg-gray-100 rounded">⌘</kbd>
                      <kbd className="px-2 py-1 text-xs font-mono bg-gray-100 rounded">C</kbd>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pr-4">
                    <span className="text-sm text-gray-600">Ricerca</span>
                    <div className="flex items-center space-x-1">
                      <kbd className="px-2 py-1 text-xs font-mono bg-gray-100 rounded">⌘</kbd>
                      <kbd className="px-2 py-1 text-xs font-mono bg-gray-100 rounded">K</kbd>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;