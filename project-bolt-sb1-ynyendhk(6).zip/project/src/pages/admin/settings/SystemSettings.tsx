import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Save, AlertTriangle, Check, LogOut, Key, HelpCircle, 
  Smartphone, QrCode, Globe, Lock, RefreshCw, Share2, 
  Download, Upload, Settings as SettingsIcon, Building, 
  Bell, Wifi, Database, Clock, MapPin, Camera, Copy, 
  User, UserPlus, ShieldCheck, AlertCircle, Mail, Phone, 
  Info, X, Eye, EyeOff, Shield, FileText, Calendar, 
  MessageSquare, Cloud, Server, Network, PenTool as Tool, 
  Activity, Zap, ChevronRight 
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import { useAuth } from '../../../context/AuthContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { QRCodeSVG } from 'qrcode.react';

const SystemSettings: React.FC = () => {
  const { state, updateSettings } = useData();
  const { state: authState } = useAuth();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({ ...state.settings });
  const [isLoading, setIsLoading] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [successMessage, setSuccessMessage] = useState('');
  const [showMobileQR, setShowMobileQR] = useState(false);
  const [mobileAppKey, setMobileAppKey] = useState('');
  const [copySuccess, setCopySuccess] = useState<string | null>(null);
  
  // Admin credentials management
  const [adminCredentials, setAdminCredentials] = useState({
    currentUsername: '',
    currentPassword: '',
    newUsername: '',
    newPassword: '',
    confirmPassword: '',
    emergencyPassword: ''
  });
  const [showCredentialsForm, setShowCredentialsForm] = useState(false);
  const [showEmergencyReset, setShowEmergencyReset] = useState(false);

  const handleCopyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopySuccess(field);
      setTimeout(() => setCopySuccess(null), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };
  
  useEffect(() => {
    setFormData({ ...state.settings });
    if (!state.settings.mobileAppApiKey) {
      const newKey = Array.from(crypto.getRandomValues(new Uint8Array(32)))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
      setMobileAppKey(newKey);
    } else {
      setMobileAppKey(state.settings.mobileAppApiKey);
    }
  }, [state.settings]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      setFormData({
        ...formData,
        [name]: checkbox.checked
      });
    } else if (type === 'number') {
      setFormData({
        ...formData,
        [name]: value !== '' ? Number(value) : ''
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
    
    if (formErrors[name]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleCredentialsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setAdminCredentials(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    if (!formData.companyName.trim()) {
      errors.companyName = 'Ragione sociale obbligatoria';
    }
    
    if (!formData.companyPhone.trim()) {
      errors.companyPhone = 'Telefono obbligatorio';
    }
    
    if (!formData.companyEmail.trim()) {
      errors.companyEmail = 'Email obbligatoria';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.companyEmail)) {
      errors.companyEmail = 'Formato email non valido';
    }
    
    if (formData.mobileAppEnabled) {
      if (!mobileAppKey) {
        errors.mobileAppApiKey = 'API Key obbligatoria per app mobile';
      }
      if (!formData.mobileAppUrl) {
        errors.mobileAppUrl = 'URL app mobile obbligatorio';
      }
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const validateCredentials = (): boolean => {
    const errors: Record<string, string> = {};

    if (showEmergencyReset) {
      if (adminCredentials.emergencyPassword !== 'Gilmore&Grace21') {
        errors.emergencyPassword = 'Password di emergenza non valida';
      }
    } else {
      if (!adminCredentials.currentUsername || !adminCredentials.currentPassword) {
        errors.current = 'Inserire le credenziali attuali';
      }
      if (!adminCredentials.newUsername || !adminCredentials.newPassword) {
        errors.new = 'Inserire le nuove credenziali';
      }
      if (adminCredentials.newPassword !== adminCredentials.confirmPassword) {
        errors.confirm = 'Le password non coincidono';
      }
      if (adminCredentials.newPassword.length < 8) {
        errors.password = 'La password deve essere di almeno 8 caratteri';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      const updatedSettings = {
        ...formData,
        mobileAppApiKey: mobileAppKey
      };
      
      await updateSettings(updatedSettings);
      setSuccessMessage('Impostazioni salvate con successo');
      
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } catch (error) {
      setFormErrors({ submit: 'Errore durante il salvataggio delle impostazioni' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateCredentials()) {
      return;
    }

    setIsLoading(true);

    try {
      if (showEmergencyReset) {
        // Reset to default credentials
        // In a real app, this would call an API endpoint
        setSuccessMessage('Credenziali ripristinate con successo');
        setShowEmergencyReset(false);
      } else {
        // Update credentials
        // In a real app, this would call an API endpoint
        setSuccessMessage('Credenziali aggiornate con successo');
      }
      
      setShowCredentialsForm(false);
      setAdminCredentials({
        currentUsername: '',
        currentPassword: '',
        newUsername: '',
        newPassword: '',
        confirmPassword: '',
        emergencyPassword: ''
      });
      
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } catch (error) {
      setFormErrors({ submit: 'Errore durante l\'aggiornamento delle credenziali' });
    } finally {
      setIsLoading(false);
    }
  };

  const generateMobileQR = () => {
    const qrData = {
      apiKey: mobileAppKey,
      serverUrl: formData.mobileAppUrl,
      appVersion: formData.mobileAppVersion
    };
    return JSON.stringify(qrData);
  };

  if (state.isLoading) {
    return (
      <div className="page-container flex items-center justify-center">
        <LoadingSpinner size="lg" text="Caricamento impostazioni..." />
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="mb-6">
        <h1 className="page-title">Impostazioni di Sistema</h1>
        <p className="text-gray-600">Configura le impostazioni generali del sistema</p>
      </div>
      
      {successMessage && (
        <div className="mb-6 bg-green-50 border-l-4 border-green-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <Check className="h-5 w-5 text-green-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-700">{successMessage}</p>
            </div>
          </div>
        </div>
      )}
      
      {formErrors.submit && (
        <div className="mb-6 bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{formErrors.submit}</p>
            </div>
          </div>
        </div>
      )}
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <form onSubmit={handleSubmit}>
          {/* Admin Credentials Section */}
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <User className="h-5 w-5 mr-2 text-primary-600" />
              Gestione Accesso Amministratore
            </h2>

            {!showCredentialsForm ? (
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-gray-600">Modifica le credenziali di accesso amministratore</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Username attuale: <span className="font-medium">{authState.user?.username || 'admin'}</span>
                  </p>
                </div>
                <div className="space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowEmergencyReset(true)}
                    className="macos-button bg-yellow-100 text-yellow-700 hover:bg-yellow-200"
                  >
                    <Key className="h-4 w-4 mr-2" />
                    Reset Emergenza
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowCredentialsForm(true)}
                    className="macos-button-primary"
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Modifica Credenziali
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-gray-50 p-4 rounded-lg">
                <form onSubmit={handleCredentialsSubmit} className="space-y-4">
                  {showEmergencyReset ? (
                    <>
                      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                        <div className="flex">
                          <AlertCircle className="h-5 w-5 text-yellow-400" />
                          <div className="ml-3">
                            <p className="text-sm text-yellow-700">
                              Questa operazione ripristinerà le credenziali predefinite:
                            </p>
                            <ul className="mt-1 text-sm text-yellow-700 list-disc list-inside">
                              <li>Username: admin</li>
                              <li>Password: 123456</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div>
                        <label htmlFor="emergencyPassword" className="form-label">
                          Password di Emergenza
                        </label>
                        <input
                          type="password"
                          id="emergencyPassword"
                          name="emergencyPassword"
                          value={adminCredentials.emergencyPassword}
                          onChange={handleCredentialsChange}
                          className={`macos-input ${formErrors.emergencyPassword ? 'border-red-300' : ''}`}
                          placeholder="Inserisci la password di emergenza"
                        />
                        {formErrors.emergencyPassword && (
                          <p className="mt-1 text-sm text-red-600">{formErrors.emergencyPassword}</p>
                        )}
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="currentUsername" className="form-label">
                            Username Attuale
                          </label>
                          <input
                            type="text"
                            id="currentUsername"
                            name="currentUsername"
                            value={adminCredentials.currentUsername}
                            onChange={handleCredentialsChange}
                            className="macos-input"
                            required
                          />
                        </div>
                        <div>
                          <label htmlFor="currentPassword" className="form-label">
                            Password Attuale
                          </label>
                          <input
                            type="password"
                            id="currentPassword"
                            name="currentPassword"
                            value={adminCredentials.currentPassword}
                            onChange={handleCredentialsChange}
                            className="macos-input"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="newUsername" className="form-label">
                            Nuovo Username
                          </label>
                          <input
                            type="text"
                            id="newUsername"
                            name="newUsername"
                            value={adminCredentials.newUsername}
                            onChange={handleCredentialsChange}
                            className="macos-input"
                            required
                          />
                        </div>
                        <div>
                          <label htmlFor="newPassword" className="form-label">
                            Nuova Password
                          </label>
                          <input
                            type="password"
                            id="newPassword"
                            name="newPassword"
                            value={adminCredentials.newPassword}
                            onChange={handleCredentialsChange}
                            className="macos-input"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="confirmPassword" className="form-label">
                          Conferma Password
                        </label>
                        <input
                          type="password"
                          id="confirmPassword"
                          name="confirmPassword"
                          value={adminCredentials.confirmPassword}
                          onChange={handleCredentialsChange}
                          className={`macos-input ${formErrors.confirm ? 'border-red-300' : ''}`}
                          required
                        />
                        {formErrors.confirm && (
                          <p className="mt-1 text-sm text-red-600">{formErrors.confirm}</p>
                        )}
                      </div>
                    </>
                  )}

                  <div className="flex justify-end space-x-3 mt-6">
                    <button
                      type="button"
                      onClick={() => {
                        setShowCredentialsForm(false);
                        setShowEmergencyReset(false);
                        setAdminCredentials({
                          currentUsername: '',
                          currentPassword: '',
                          newUsername: '',
                          newPassword: '',
                          confirmPassword: '',
                          emergencyPassword: ''
                        });
                      }}
                      className="macos-button"
                    >
                      Annulla
                    </button>
                    <button
                      type="submit"
                      className="macos-button-primary"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <LoadingSpinner size="sm" color="white" />
                      ) : showEmergencyReset ? (
                        'Ripristina Credenziali'
                      ) : (
                        'Salva Credenziali'
                      )}
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>

          {/* Company Info Section */}
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Informazioni Aziendali</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="companyName" className="form-label">
                  Ragione Sociale <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="companyName"
                  name="companyName"
                  className={`macos-input ${formErrors.companyName ? 'border-red-300' : ''}`}
                  value={formData.companyName}
                  onChange={handleInputChange}
                  required
                />
                {formErrors.companyName && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.companyName}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="companyAddress" className="form-label">
                  Indirizzo
                </label>
                <input
                  type="text"
                  id="companyAddress"
                  name="companyAddress"
                  className="macos-input"
                  value={formData.companyAddress}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="companyCity" className="form-label">
                  Città
                </label>
                <input
                  type="text"
                  id="companyCity"
                  name="companyCity"
                  className="macos-input"
                  value={formData.companyCity}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="companyPostalCode" className="form-label">
                  CAP
                </label>
                <input
                  type="text"
                  id="companyPostalCode"
                  name="companyPostalCode"
                  className="macos-input"
                  value={formData.companyPostalCode}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="companyPhone" className="form-label">
                  Telefono <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="companyPhone"
                  name="companyPhone"
                  className={`macos-input ${formErrors.companyPhone ? 'border-red-300' : ''}`}
                  value={formData.companyPhone}
                  onChange={handleInputChange}
                  required
                />
                {formErrors.companyPhone && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.companyPhone}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="companyEmail" className="form-label">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  id="companyEmail"
                  name="companyEmail"
                  className={`macos-input ${formErrors.companyEmail ? 'border-red-300' : ''}`}
                  value={formData.companyEmail}
                  onChange={handleInputChange}
                  required
                />
                {formErrors.companyEmail && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.companyEmail}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="companyWebsite" className="form-label">
                  Sito Web
                </label>
                <input
                  type="text"
                  id="companyWebsite"
                  name="companyWebsite"
                  className="macos-input"
                  value={formData.companyWebsite}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="vatNumber" className="form-label">
                  Partita IVA
                </label>
                <input
                  type="text"
                  id="vatNumber"
                  name="vatNumber"
                  className="macos-input"
                  value={formData.vatNumber}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="fiscalCode" className="form-label">
                  Codice Fiscale
                </label>
                <input
                  type="text"
                  id="fiscalCode"
                  name="fiscalCode"
                  className="macos-input"
                  value={formData.fiscalCode}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </div>
          
          {/* Mobile App Section */}
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Smartphone className="h-5 w-5 mr-2 text-primary-600" />
              App Mobile
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="flex items-center mb-4">
                  <input
                    type="checkbox"
                    id="mobileAppEnabled"
                    name="mobileAppEnabled"
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                    checked={formData.mobileAppEnabled}
                    onChange={handleInputChange}
                  />
                  <label htmlFor="mobileAppEnabled" className="ml-2 block text-sm text-gray-900">
                    Abilita App Mobile
                  </label>
                </div>
                
                {formData.mobileAppEnabled && (
                  <>
                    <div className="mb-4">
                      <label htmlFor="mobileAppUrl" className="form-label">
                        URL App Mobile <span className="text-red-500">*</span>
                      </label>
                      <div className="mt-1 relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Globe className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          type="url"
                          id="mobileAppUrl"
                          name="mobileAppUrl"
                          className={`macos-input pl-10 ${formErrors.mobileAppUrl ? 'border-red-300' : ''}`}
                          value={formData.mobileAppUrl || ''}
                          onChange={handleInputChange}
                          placeholder="https://mobile.easysistem.it"
                        />
                      </div>
                      {formErrors.mobileAppUrl && (
                        <p className="mt-1 text-sm text-red-600">{formErrors.mobileAppUrl}</p>
                      )}
                    </div>

                    <div className="mb-4">
                      <label htmlFor="mobileAppVersion" className="form-label">
                        Versione App
                      </label>
                      <input
                        type="text"
                        id="mobileAppVersion"
                        name="mobileAppVersion"
                        className="macos-input"
                        value={formData.mobileAppVersion || ''}
                        onChange={handleInputChange}
                        placeholder="1.0.0"
                      />
                    </div>

                    <div className="mb-4">
                      <label htmlFor="mobileAppMinVersion" className="form-label">
                        Versione Minima Richiesta
                      </label>
                      <input
                        type="text"
                        id="mobileAppMinVersion"
                        name="mobileAppMinVersion"
                        className="macos-input"
                        value={formData.mobileAppMinVersion || ''}
                        onChange={handleInputChange}
                        placeholder="1.0.0"
                      />
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="mobileAppForceUpdate"
                          name="mobileAppForceUpdate"
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                          checked={formData.mobileAppForceUpdate}
                          onChange={handleInputChange}
                        />
                        <label htmlFor="mobileAppForceUpdate" className="ml-2 block text-sm text-gray-900">
                          Forza aggiornamento app
                        </label>
                      </div>

                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="mobileAppGpsTracking"
                          name="mobileAppGpsTracking"
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                          checked={formData.mobileAppGpsTracking}
                          onChange={handleInputChange}
                        />
                        <label htmlFor="mobileAppGpsTracking" className="ml-2 block text-sm text-gray-900">
                          Tracciamento GPS
                        </label>
                      </div>

                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="mobileAppOfflineMode"
                          name="mobileAppOfflineMode"
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                          checked={formData.mobileAppOfflineMode}
                          onChange={handleInputChange}
                        />
                        <label htmlFor="mobileAppOfflineMode" className="ml-2 block text-sm text-gray-900">
                          Modalità offline
                        </label>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {formData.mobileAppEnabled && (
                <div>
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <h3 className="text-sm font-medium text-gray-700 mb-4">Configurazione App Mobile</h3>
                    
                    <div className="mb-4">
                      <label className="form-label flex items-center">
                        API Key
                        <HelpCircle className="h-4 w-4 ml-1 text-gray-400 cursor-help" />
                      </label>
                      <div className="mt-1 relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Key className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          type="text"
                          value={mobileAppKey}
                          className="macos-input pl-10 font-mono text-sm"
                          readOnly
                        />
                        <button
                          type="button"
                          onClick={() => handleCopyToClipboard(mobileAppKey, 'apiKey')}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center"
                        >
                          {copySuccess === 'apiKey' ? (
                            <Check className="h-5 w-5 text-green-500" />
                          ) : (
                            <Copy className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="mb-4">
                      <label className="form-label">QR Code Configurazione</label>
                      <div className="mt-2 flex justify-center">
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                          <QRCodeSVG
                            value={generateMobileQR()}
                            size={200}
                            level="H"
                            includeMargin={true}
                          />
                        </div>
                      </div>
                      <p className="mt-2 text-xs text-gray-500 text-center">
                        Scansiona questo codice dall'app mobile per configurarla automaticamente
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="form-label">Intervallo Sincronizzazione</label>
                        <select
                          name="mobileAppSyncInterval"
                          className="macos-input"
                          value={formData.mobileAppSyncInterval || 15}
                          onChange={handleInputChange}
                        >
                          <option value={5}>5 minuti</option>
                          <option value={15}>15 minuti</option>
                          <option value={30}>30 minuti</option>
                          <option value={60}>1 ora</option>
                        </select>
                      </div>

                      <div>
                        <label className="form-label">Qualità Foto</label>
                        <select
                          name="mobileAppPhotoQuality"
                          className="macos-input"
                          value={formData.mobileAppPhotoQuality || 'medium'}
                          onChange={handleInputChange}
                        >
                          <option value="low">Bassa (risparmio dati)</option>
                          <option value="medium">Media</option>
                          <option value="high">Alta</option>
                        </select>
                      </div>

                      <div>
                        <label className="form-label">
                          Dimensione Massima Foto (MB)
                        </label>
                        <input
                          type="number"
                          name="mobileAppMaxPhotoSize"
                          className="macos-input"
                          value={formData.mobileAppMaxPhotoSize || 5}
                          onChange={handleInputChange}
                          min={1}
                          max={20}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between">
            <button
              type="button"
              onClick={() => navigate('/admin')}
              className="macos-button"
            >
              <LogOut className="h-5 w-5 mr-1" />
              Indietro
            </button>
            
            <button
              type="submit"
              className="macos-button-primary"
              disabled={isLoading}
            >
              {isLoading ? (
                <LoadingSpinner size="sm" color="white" />
              ) : (
                <>
                  <Save className="h-5 w-5 mr-1" />
                  Salva Impostazioni
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SystemSettings;