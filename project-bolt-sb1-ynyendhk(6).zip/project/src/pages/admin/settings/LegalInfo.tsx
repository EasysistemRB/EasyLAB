import React from 'react';
import { 
  Shield, Book, Lock, Copyright, Building, Mail, Phone, 
  Globe, FileText, AlertTriangle, Info, Scale
} from 'lucide-react';
import { useData } from '../../../context/DataContext';

const LegalInfo: React.FC = () => {
  const { state } = useData();
  
  return (
    <div className="page-container">
      <div className="mb-6">
        <h1 className="page-title">Informazioni Legali</h1>
        <p className="text-gray-600">Diritti di utilizzo, licenze e informazioni sulla privacy</p>
      </div>
      
      {/* Software License */}
      <div className="bg-white shadow-md rounded-lg overflow-hidden mb-6">
        <div className="px-6 py-4 bg-primary-700 text-white">
          <h2 className="text-lg font-medium flex items-center">
            <Book className="mr-2 h-5 w-5" />
            Licenza Software
          </h2>
        </div>
        
        <div className="p-6 space-y-4">
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <Info className="h-5 w-5 text-blue-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-blue-700">
                  EasyLAB 25 - Gestionale per laboratori tecnici
                </p>
                <p className="text-xs text-blue-600 mt-1">
                  Versione 1.0.0 - © 2025 EasySystem di Raffaele Bianchetti
                </p>
              </div>
            </div>
          </div>
          
          <div className="prose max-w-none">
            <h3 className="text-lg font-medium text-gray-900 mb-2">Concessione di Licenza</h3>
            <p className="text-gray-600">
              EasySystem di Raffaele Bianchetti (di seguito "EasySystem") concede all'utente una licenza 
              personale, non esclusiva, non trasferibile e limitata per l'utilizzo del software EasyLAB 25 
              (di seguito "Software") secondo i termini e le condizioni specificate di seguito.
            </p>
            
            <h4 className="text-md font-medium text-gray-900 mt-4 mb-2">Termini di Utilizzo</h4>
            <ul className="list-disc pl-5 text-gray-600 space-y-2">
              <li>
                La licenza concede il diritto di utilizzare il Software esclusivamente per le finalità 
                aziendali interne del licenziatario.
              </li>
              <li>
                È vietata la sublicenza, il noleggio, la vendita, la distribuzione o il trasferimento 
                del Software a terzi.
              </li>
              <li>
                È vietata qualsiasi modifica, decompilazione, reverse engineering o creazione di 
                opere derivate basate sul Software.
              </li>
              <li>
                La licenza è valida per il periodo specificato nel contratto di abbonamento.
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Privacy and Data Protection */}
      <div className="bg-white shadow-md rounded-lg overflow-hidden mb-6">
        <div className="px-6 py-4 bg-green-700 text-white">
          <h2 className="text-lg font-medium flex items-center">
            <Lock className="mr-2 h-5 w-5" />
            Trattamento dei Dati Personali
          </h2>
        </div>
        
        <div className="p-6 space-y-4">
          <div className="prose max-w-none">
            <p className="text-gray-600">
              Ai sensi del Regolamento UE 2016/679 (GDPR) e del D.Lgs. 196/2003 (Codice Privacy), 
              come modificato dal D.Lgs. 101/2018, informiamo che:
            </p>
            
            <h4 className="text-md font-medium text-gray-900 mt-4 mb-2">Titolare del Trattamento</h4>
            <p className="text-gray-600">
              Il Titolare del trattamento è EasySystem di Raffaele Bianchetti, con sede legale in 
              Via Bari 80, 80026 Casoria (NA).
            </p>
            
            <h4 className="text-md font-medium text-gray-900 mt-4 mb-2">Finalità del Trattamento</h4>
            <ul className="list-disc pl-5 text-gray-600 space-y-2">
              <li>Gestione e manutenzione del software</li>
              <li>Assistenza tecnica e supporto clienti</li>
              <li>Fatturazione e adempimenti contabili</li>
              <li>Comunicazioni di servizio</li>
              <li>Backup e sicurezza dei dati</li>
            </ul>
            
            <h4 className="text-md font-medium text-gray-900 mt-4 mb-2">Base Giuridica</h4>
            <ul className="list-disc pl-5 text-gray-600 space-y-2">
              <li>Esecuzione di un contratto di cui l'interessato è parte</li>
              <li>Adempimento di obblighi legali</li>
              <li>Legittimo interesse del titolare</li>
              <li>Consenso dell'interessato (ove richiesto)</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Intellectual Property */}
      <div className="bg-white shadow-md rounded-lg overflow-hidden mb-6">
        <div className="px-6 py-4 bg-purple-700 text-white">
          <h2 className="text-lg font-medium flex items-center">
            <Copyright className="mr-2 h-5 w-5" />
            Proprietà Intellettuale
          </h2>
        </div>
        
        <div className="p-6 space-y-4">
          <div className="prose max-w-none">
            <p className="text-gray-600">
              Il Software, inclusi ma non limitati a codice sorgente, documentazione, design e loghi, 
              è protetto dalle leggi sul copyright e sulla proprietà intellettuale. EasySystem mantiene 
              la piena ed esclusiva proprietà di tutti i diritti, titoli e interessi relativi al Software.
            </p>
            
            <h4 className="text-md font-medium text-gray-900 mt-4 mb-2">Diritti Riservati</h4>
            <ul className="list-disc pl-5 text-gray-600 space-y-2">
              <li>Tutti i diritti non espressamente concessi sono riservati a EasySystem</li>
              <li>Il Software è protetto da copyright © 2025 EasySystem di Raffaele Bianchetti</li>
              <li>Marchi, loghi e nomi commerciali sono di proprietà di EasySystem</li>
            </ul>
            
            <div className="mt-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-5 w-5 text-yellow-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-yellow-700">
                    Qualsiasi violazione dei diritti di proprietà intellettuale sarà perseguita 
                    a termini di legge.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Company Information */}
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="px-6 py-4 bg-gray-700 text-white">
          <h2 className="text-lg font-medium flex items-center">
            <Building className="mr-2 h-5 w-5" />
            Informazioni Aziendali
          </h2>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Sede Legale</h3>
              <div className="space-y-2">
                <p className="text-gray-600">
                  <strong>EasySystem di Raffaele Bianchetti</strong>
                </p>
                <p className="text-gray-600">Via Bari 80</p>
                <p className="text-gray-600">80026 Casoria (NA)</p>
                <p className="text-gray-600">Italia</p>
              </div>
              
              <div className="mt-4 space-y-2">
                <div className="flex items-center">
                  <Globe className="h-5 w-5 text-gray-400 mr-2" />
                  <div>
                    <a href="https://www.easysistem.it" target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:text-primary-700">
                      www.easysistem.it
                    </a>
                    <br />
                    <a href="https://www.easysistem.eu" target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:text-primary-700">
                      www.easysistem.eu
                    </a>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Contatti</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">Amministrazione</p>
                  <div className="flex items-center mt-1">
                    <Mail className="h-5 w-5 text-gray-400 mr-2" />
                    <a href="mailto:admin@easysistem.it" className="text-primary-600 hover:text-primary-700">
                      admin@easysistem.it
                    </a>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-500">Assistenza Clienti</p>
                  <div className="flex items-center mt-1">
                    <Mail className="h-5 w-5 text-gray-400 mr-2" />
                    <a href="mailto:assistenza@easysistem.it" className="text-primary-600 hover:text-primary-700">
                      assistenza@easysistem.it
                    </a>
                  </div>
                  <div className="flex items-center mt-2">
                    <Phone className="h-5 w-5 text-gray-400 mr-2" />
                    <a href="tel:+390118557973" className="text-primary-600 hover:text-primary-700">
                      081 18557973
                    </a>
                    <span className="text-xs text-gray-500 ml-2">(HelpVoice)</span>
                  </div>
                </div>
                
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm font-medium text-gray-900 mb-2">Supporto Web</p>
                  <p className="text-sm text-gray-600">
                    Accesso remoto disponibile sulla porta 7477
                  </p>
                  <a 
                    href="http://localhost:7477" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="mt-2 inline-flex items-center text-sm text-primary-600 hover:text-primary-700"
                  >
                    <Globe className="h-4 w-4 mr-1" />
                    Accedi al supporto web
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LegalInfo;