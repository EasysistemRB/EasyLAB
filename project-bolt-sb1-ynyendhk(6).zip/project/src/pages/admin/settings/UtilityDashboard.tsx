import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart2, Calendar, Clock, CheckCircle, XCircle, AlertTriangle, 
  ArrowUpRight, ArrowDownRight, TrendingUp, User, MessageSquare, 
  Activity, RefreshCw, AlertCircle, Server, Cpu, Network, Wifi, 
  Cloud, Monitor, Terminal, Package, Folder, FileSearch, Trash2, 
  Database, MemoryStick as Memory, Disc, Shield, Code, PenTool as Tool, 
  Info, Globe, X 
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { useCache } from '../../../hooks/useCache';
import { formatCacheSize } from '../../../utils/cacheUtils';

const UtilityDashboard: React.FC = () => {
  const { state } = useData();
  const { refreshStats, clearCache, cleanCache, stats } = useCache();
  const navigate = useNavigate();
  
  const [refreshing, setRefreshing] = useState(false);
  const [systemStats, setSystemStats] = useState({
    cpu: {
      usage: 0,
      temperature: 0,
      cores: navigator.hardwareConcurrency,
      frequency: 2.4 // GHz
    },
    memory: {
      total: 16 * 1024 * 1024 * 1024, // 16GB in bytes
      used: 0,
      free: 0,
      cached: 0
    },
    storage: {
      total: 512 * 1024 * 1024 * 1024, // 512GB in bytes
      used: 0,
      free: 0
    },
    network: {
      bytesIn: 0,
      bytesOut: 0,
      latency: 0,
      connections: 0
    },
    processes: {
      total: 0,
      running: 0,
      sleeping: 0,
      stopped: 0
    },
    uptime: 0
  });

  // Update system stats periodically
  useEffect(() => {
    const updateStats = () => {
      setSystemStats(prev => ({
        ...prev,
        cpu: {
          ...prev.cpu,
          usage: Math.min(100, Math.max(0, prev.cpu.usage + (Math.random() * 10 - 5))),
          temperature: Math.min(90, Math.max(40, prev.cpu.temperature + (Math.random() * 2 - 1)))
        },
        memory: {
          ...prev.memory,
          used: Math.floor(prev.memory.total * (0.3 + Math.random() * 0.4)),
          cached: Math.floor(prev.memory.total * 0.1)
        },
        storage: {
          ...prev.storage,
          used: Math.floor(prev.storage.total * (0.5 + Math.random() * 0.2))
        },
        network: {
          bytesIn: prev.network.bytesIn + Math.floor(Math.random() * 1024 * 1024),
          bytesOut: prev.network.bytesOut + Math.floor(Math.random() * 1024 * 1024),
          latency: Math.max(1, Math.min(100, prev.network.latency + (Math.random() * 10 - 5))),
          connections: Math.floor(50 + Math.random() * 20)
        },
        processes: {
          total: Math.floor(100 + Math.random() * 20),
          running: Math.floor(20 + Math.random() * 10),
          sleeping: Math.floor(70 + Math.random() * 10),
          stopped: Math.floor(Math.random() * 5)
        },
        uptime: prev.uptime + 1
      }));
    };

    // Initial update
    updateStats();

    // Update every second
    const interval = setInterval(updateStats, 1000);

    return () => clearInterval(interval);
  }, []);

  // Format bytes to human readable size
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  };

  // Format uptime
  const formatUptime = (seconds: number): string => {
    const days = Math.floor(seconds / (24 * 60 * 60));
    const hours = Math.floor((seconds % (24 * 60 * 60)) / (60 * 60));
    const minutes = Math.floor((seconds % (60 * 60)) / 60);
    return `${days}d ${hours}h ${minutes}m`;
  };

  // Handle refresh
  const handleRefresh = async () => {
    setRefreshing(true);
    await refreshStats();
    setTimeout(() => setRefreshing(false), 1000);
  };

  // Handle cache cleanup
  const handleCacheCleanup = async () => {
    try {
      await cleanCache();
      await refreshStats();
    } catch (error) {
      console.error('Error cleaning cache:', error);
    }
  };

  if (state.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="p-2 rounded-lg bg-gradient-to-r from-primary-600 to-primary-700 text-white">
            <Tool className="h-8 w-8" />
          </div>
          <div className="ml-4">
            <h1 className="text-2xl font-bold text-gray-900">Utility di Sistema</h1>
            <p className="text-gray-500">Monitoraggio e manutenzione del sistema</p>
          </div>
        </div>
        
        <button
          onClick={handleRefresh}
          className="p-2 bg-white rounded-full shadow-sm text-gray-500 hover:text-gray-700"
          disabled={refreshing}
        >
          <RefreshCw className={`h-5 w-5 ${refreshing ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* System Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* CPU Usage */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Cpu className="h-6 w-6 text-blue-600" />
              <span className="ml-2 font-medium text-gray-900">CPU</span>
            </div>
            <span className="text-2xl font-bold text-blue-600">
              {Math.round(systemStats.cpu.usage)}%
            </span>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Temperatura</span>
              <span className="font-medium">{systemStats.cpu.temperature}°C</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Cores</span>
              <span className="font-medium">{systemStats.cpu.cores}</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full">
              <div 
                className="h-full bg-blue-500 rounded-full transition-all duration-300"
                style={{ width: `${systemStats.cpu.usage}%` }}
              />
            </div>
          </div>
        </div>

        {/* Memory Usage */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Memory className="h-6 w-6 text-green-600" />
              <span className="ml-2 font-medium text-gray-900">Memoria</span>
            </div>
            <span className="text-2xl font-bold text-green-600">
              {Math.round((systemStats.memory.used / systemStats.memory.total) * 100)}%
            </span>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Usata</span>
              <span className="font-medium">{formatBytes(systemStats.memory.used)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Totale</span>
              <span className="font-medium">{formatBytes(systemStats.memory.total)}</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full">
              <div 
                className="h-full bg-green-500 rounded-full transition-all duration-300"
                style={{ width: `${(systemStats.memory.used / systemStats.memory.total) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Storage */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Database className="h-6 w-6 text-purple-600" />
              <span className="ml-2 font-medium text-gray-900">Storage</span>
            </div>
            <span className="text-2xl font-bold text-purple-600">
              {Math.round((systemStats.storage.used / systemStats.storage.total) * 100)}%
            </span>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Usato</span>
              <span className="font-medium">{formatBytes(systemStats.storage.used)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Totale</span>
              <span className="font-medium">{formatBytes(systemStats.storage.total)}</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full">
              <div 
                className="h-full bg-purple-500 rounded-full transition-all duration-300"
                style={{ width: `${(systemStats.storage.used / systemStats.storage.total) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Network */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Network className="h-6 w-6 text-yellow-600" />
              <span className="ml-2 font-medium text-gray-900">Network</span>
            </div>
            <span className="text-2xl font-bold text-yellow-600">
              {Math.round(systemStats.network.latency)} ms
            </span>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Download</span>
              <span className="font-medium">{formatBytes(systemStats.network.bytesIn)}/s</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Upload</span>
              <span className="font-medium">{formatBytes(systemStats.network.bytesOut)}/s</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full">
              <div 
                className="h-full bg-yellow-500 rounded-full transition-all duration-300"
                style={{ width: `${Math.min((systemStats.network.latency / 100) * 100, 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* System Information */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Process Monitor */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
            <h3 className="text-lg font-medium flex items-center">
              <Activity className="h-5 w-5 mr-2" />
              Processi
            </h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Totali</span>
                  <span className="text-lg font-semibold">{systemStats.processes.total}</span>
                </div>
              </div>
              <div className="bg-green-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-green-600">In Esecuzione</span>
                  <span className="text-lg font-semibold text-green-600">
                    {systemStats.processes.running}
                  </span>
                </div>
              </div>
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-600">In Attesa</span>
                  <span className="text-lg font-semibold text-blue-600">
                    {systemStats.processes.sleeping}
                  </span>
                </div>
              </div>
              <div className="bg-red-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-red-600">Interrotti</span>
                  <span className="text-lg font-semibold text-red-600">
                    {systemStats.processes.stopped}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Cache Management */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="px-6 py-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white">
            <h3 className="text-lg font-medium flex items-center">
              <Database className="h-5 w-5 mr-2" />
              Cache
            </h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Dimensione Totale</span>
                <span className="text-lg font-semibold">
                  {stats ? formatCacheSize(stats.totalSize) : '0 B'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Elementi</span>
                <span className="text-lg font-semibold">
                  {stats?.totalItems || 0}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Ultimo Aggiornamento</span>
                <span className="text-sm text-gray-700">
                  {stats?.newestItem || 'Mai'}
                </span>
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  onClick={handleCacheCleanup}
                  className="btn bg-purple-100 text-purple-700 hover:bg-purple-200"
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Pulisci Cache
                </button>
                <button
                  onClick={() => clearCache()}
                  className="btn bg-red-100 text-red-700 hover:bg-red-200"
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Svuota Cache
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* System Status */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="px-6 py-4 bg-gradient-to-r from-green-600 to-green-700 text-white">
            <h3 className="text-lg font-medium flex items-center">
              <Server className="h-5 w-5 mr-2" />
              Stato Sistema
            </h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Uptime</span>
                <span className="text-lg font-semibold">
                  {formatUptime(systemStats.uptime)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Connessioni Attive</span>
                <span className="text-lg font-semibold">
                  {systemStats.network.connections}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Stato Servizi</span>
                <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                  Tutti Attivi
                </span>
              </div>
              <div className="flex justify-end">
                <button className="btn bg-green-100 text-green-700 hover:bg-green-200">
                  <Activity className="h-4 w-4 mr-1" />
                  Diagnostica
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* System Services */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white">
          <h3 className="text-lg font-medium flex items-center">
            <Server className="h-5 w-5 mr-2" />
            Servizi di Sistema
          </h3>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <Database className="h-5 w-5 text-green-600" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Database</p>
                  <p className="text-xs text-gray-500">PostgreSQL 15.4</p>
                </div>
              </div>
              <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                Attivo
              </span>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <Cloud className="h-5 w-5 text-blue-600" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Cache</p>
                  <p className="text-xs text-gray-500">Redis 7.2</p>
                </div>
              </div>
              <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                Attivo
              </span>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <Globe className="h-5 w-5 text-purple-600" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Web Server</p>
                  <p className="text-xs text-gray-500">Nginx 1.24</p>
                </div>
              </div>
              <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                Attivo
              </span>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <MessageSquare className="h-5 w-5 text-yellow-600" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">WhatsApp Service</p>
                  <p className="text-xs text-gray-500">API v2.24.1</p>
                </div>
              </div>
              <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                Attivo
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UtilityDashboard;