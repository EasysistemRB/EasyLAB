import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft, Edit, Trash2, MessageSquare, User, Calendar,
  Clock, AlertTriangle, CheckCircle, Send, PaperclipIcon,
  Download, Eye, Laptop, RefreshCw, AlertCircle, Building,
  Mail, Phone, MapPin, Hash, Briefcase, FileText, Users,
  FileCheck, X, QrCode, Key, Shield, Info, CreditCard,
  Globe, FileSpreadsheet, Archive, Settings, Database,
  Smartphone, MessageCircle as WhatsApp
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { format, isValid, parseISO } from 'date-fns';
import { it } from 'date-fns/locale';
import { Client, Device } from '../../../types';
import ClientQRCodeGenerator from '../../../components/ClientQRCodeGenerator';
import ClientCredentialsGenerator from '../../../components/ClientCredentialsGenerator';
import SharedFilesManager from '../../../components/SharedFilesManager';

const ClientDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { state, deleteClient, updateClient, sendWhatsAppMessage } = useData();
  const navigate = useNavigate();
  
  const [client, setClient] = useState<Client | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'devices' | 'appointments' | 'tickets' | 'access' | 'files'>('info');
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [isDeviceDetailOpen, setIsDeviceDetailOpen] = useState(false);
  const [activeSectionView, setActiveSectionView] = useState<'qrcode' | 'credentials'>('qrcode');
  const [isLoading, setIsLoading] = useState(false);
  const [copySuccess, setCopySuccess] = useState<string | null>(null);
  const [isSendingWhatsApp, setIsSendingWhatsApp] = useState(false);

  // Format date helper
  const formatDate = (dateString: string | undefined): string => {
    if (!dateString) return 'N/D';
    try {
      const date = parseISO(dateString);
      if (!isValid(date)) return 'Data non valida';
      return format(date, 'dd/MM/yyyy', { locale: it });
    } catch (e) {
      console.error('Error formatting date:', e);
      return 'Data non valida';
    }
  };

  // Load client data
  useEffect(() => {
    if (!state.isLoading && id) {
      const foundClient = state.clients.find(c => c.id === id);
      if (foundClient) {
        setClient(foundClient);
      } else {
        navigate('/admin/clients');
      }
    }
  }, [id, state.isLoading, state.clients, navigate]);

  // Get client statistics
  const getClientStats = () => {
    if (!client) return null;

    const appointments = state.appointments.filter(a => a.clientId === client.id);
    const tickets = state.tickets.filter(t => t.clientId === client.id);
    const devices = client.devices?.length || 0;

    return {
      appointments: {
        total: appointments.length,
        upcoming: appointments.filter(a => new Date(a.date) > new Date()).length
      },
      tickets: {
        total: tickets.length,
        open: tickets.filter(t => t.status === 'open').length
      },
      devices
    };
  };

  const stats = getClientStats();

  // Handle delete operations
  const handleDeleteClick = () => setIsDeleteModalOpen(true);

  const handleDeleteConfirm = async () => {
    if (!client) return;
    setIsDeleting(true);
    try {
      await deleteClient(client.id);
      navigate('/admin/clients');
    } catch (error) {
      console.error('Error deleting client:', error);
    } finally {
      setIsDeleting(false);
      setIsDeleteModalOpen(false);
    }
  };

  // Handle device operations
  const handleDeviceClick = (device: Device) => {
    setSelectedDevice(device);
    setIsDeviceDetailOpen(true);
  };

  const handleCloseDeviceDetail = () => {
    setIsDeviceDetailOpen(false);
    setSelectedDevice(null);
  };

  // Handle WhatsApp message
  const handleSendWhatsApp = async (message: string) => {
    if (!client?.phone) return;
    
    setIsSendingWhatsApp(true);
    try {
      await sendWhatsAppMessage(client.phone, message);
      // Show success notification
    } catch (error) {
      console.error('Error sending WhatsApp message:', error);
      // Show error notification
    } finally {
      setIsSendingWhatsApp(false);
    }
  };

  // Copy to clipboard helper
  const handleCopyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopySuccess(field);
      setTimeout(() => setCopySuccess(null), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  if (state.isLoading || !client) {
    return (
      <div className="page-container flex items-center justify-center h-full">
        <LoadingSpinner size="lg" text="Caricamento..." />
      </div>
    );
  }

  return (
    <div className="page-container">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/admin/clients')}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center">
                {client.name}
                {client.isInactive && (
                  <span className="ml-2 px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">
                    Inattivo
                  </span>
                )}
              </h1>
              <p className="text-gray-600 flex items-center">
                <Hash className="w-4 h-4 mr-1" />
                Codice Cliente: {client.clientCode}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            {client.phone && (
              <button
                onClick={() => handleSendWhatsApp("Messaggio di prova")}
                disabled={isSendingWhatsApp}
                className="btn bg-green-600 text-white hover:bg-green-700 flex items-center px-3 py-2 rounded-md text-sm font-medium"
              >
                {isSendingWhatsApp ? (
                  <LoadingSpinner size="sm" color="white" />
                ) : (
                  <>
                    <WhatsApp className="w-4 h-4 mr-1" />
                    WhatsApp
                  </>
                )}
              </button>
            )}
            <button
              onClick={() => navigate(`/admin/clients/${id}/edit`)}
              className="btn bg-blue-600 text-white hover:bg-blue-700 flex items-center px-3 py-2 rounded-md text-sm font-medium"
            >
              <Edit className="w-4 h-4 mr-1" />
              Modifica
            </button>
            <button
              onClick={handleDeleteClick}
              className="btn bg-red-600 text-white hover:bg-red-700 flex items-center px-3 py-2 rounded-md text-sm font-medium"
              disabled={isDeleting}
            >
              {isDeleting ? (
                <LoadingSpinner size="sm" color="white" />
              ) : (
                <>
                  <Trash2 className="w-4 h-4 mr-1" />
                  Elimina
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-4 mt-6">
          <div className="bg-white rounded-lg shadow p-4 flex items-center">
            <div className="rounded-full p-2 bg-blue-100 text-blue-600">
              <Laptop className="w-6 h-6" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-gray-500">Dispositivi</p>
              <p className="text-xl font-semibold">{stats?.devices || 0}</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-4 flex items-center">
            <div className="rounded-full p-2 bg-green-100 text-green-600">
              <Calendar className="w-6 h-6" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-gray-500">Appuntamenti</p>
              <p className="text-xl font-semibold">{stats?.appointments.total || 0}</p>
              <p className="text-xs text-green-600">
                {stats?.appointments.upcoming || 0} in programma
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-4 flex items-center">
            <div className="rounded-full p-2 bg-yellow-100 text-yellow-600">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-gray-500">Ticket</p>
              <p className="text-xl font-semibold">{stats?.tickets.total || 0}</p>
              <p className="text-xs text-yellow-600">
                {stats?.tickets.open || 0} aperti
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-4 flex items-center">
            <div className="rounded-full p-2 bg-purple-100 text-purple-600">
              <Archive className="w-6 h-6" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-gray-500">File Condivisi</p>
              <p className="text-xl font-semibold">{client.sharedFiles?.length || 0}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-lg shadow mb-6">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            <button
              onClick={() => setActiveTab('info')}
              className={`py-4 px-6 inline-flex items-center border-b-2 font-medium text-sm ${
                activeTab === 'info'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <User className="w-5 h-5 mr-2" />
              Informazioni
            </button>
            
            <button
              onClick={() => setActiveTab('devices')}
              className={`py-4 px-6 inline-flex items-center border-b-2 font-medium text-sm ${
                activeTab === 'devices'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Laptop className="w-5 h-5 mr-2" />
              Dispositivi
              {client.devices && client.devices.length > 0 && (
                <span className="ml-2 bg-primary-100 text-primary-600 px-2 py-0.5 rounded-full text-xs">
                  {client.devices.length}
                </span>
              )}
            </button>
            
            <button
              onClick={() => setActiveTab('appointments')}
              className={`py-4 px-6 inline-flex items-center border-b-2 font-medium text-sm ${
                activeTab === 'appointments'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Calendar className="w-5 h-5 mr-2" />
              Appuntamenti
              {stats?.appointments.upcoming > 0 && (
                <span className="ml-2 bg-green-100 text-green-600 px-2 py-0.5 rounded-full text-xs">
                  {stats.appointments.upcoming}
                </span>
              )}
            </button>
            
            <button
              onClick={() => setActiveTab('tickets')}
              className={`py-4 px-6 inline-flex items-center border-b-2 font-medium text-sm ${
                activeTab === 'tickets'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <MessageSquare className="w-5 h-5 mr-2" />
              Ticket
              {stats?.tickets.open > 0 && (
                <span className="ml-2 bg-yellow-100 text-yellow-600 px-2 py-0.5 rounded-full text-xs">
                  {stats.tickets.open}
                </span>
              )}
            </button>
            
            <button
              onClick={() => setActiveTab('access')}
              className={`py-4 px-6 inline-flex items-center border-b-2 font-medium text-sm ${
                activeTab === 'access'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Key className="w-5 h-5 mr-2" />
              Accesso
            </button>
            
            <button
              onClick={() => setActiveTab('files')}
              className={`py-4 px-6 inline-flex items-center border-b-2 font-medium text-sm ${
                activeTab === 'files'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <FileText className="w-5 h-5 mr-2" />
              File
              {client.sharedFiles && client.sharedFiles.length > 0 && (
                <span className="ml-2 bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full text-xs">
                  {client.sharedFiles.length}
                </span>
              )}
            </button>
          </nav>
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'info' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Company Info */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="px-6 py-4 bg-gradient-to-r from-primary-600 to-primary-700 text-white">
              <h2 className="text-lg font-medium flex items-center">
                <Building className="mr-2 h-5 w-5" />
                Informazioni Aziendali
              </h2>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Building className="w-5 h-5 text-primary-500 mr-3" />
                <div>
                  <p className="text-sm text-gray-500">Ragione Sociale</p>
                  <p className="font-medium">{client.name}</p>
                </div>
              </div>
              
              {client.email && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <Mail className="w-5 h-5 text-primary-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <a href={`mailto:${client.email}`} className="text-primary-600 hover:underline">
                      {client.email}
                    </a>
                  </div>
                </div>
              )}
              
              {client.phone && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <Phone className="w-5 h-5 text-primary-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Telefono</p>
                    <a href={`tel:${client.phone}`} className="text-primary-600 hover:underline">
                      {client.phone}
                    </a>
                  </div>
                </div>
              )}
              
              {client.address && (
                <div className="flex items-start p-3 bg-gray-50 rounded-lg">
                  <MapPin className="w-5 h-5 text-primary-500 mr-3 mt-1" />
                  <div>
                    <p className="text-sm text-gray-500">Indirizzo</p>
                    <p>{client.address}</p>
                    {client.city && <p>{client.city}</p>}
                    {client.postalCode && <p>{client.postalCode}</p>}
                  </div>
                </div>
              )}
              
              {client.website && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <Globe className="w-5 h-5 text-primary-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Sito Web</p>
                    <a 
                      href={client.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary-600 hover:underline"
                    >
                      {client.website}
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Fiscal Info */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="px-6 py-4 bg-gradient-to-r from-secondary-600 to-secondary-700 text-white">
              <h2 className="text-lg font-medium flex items-center">
                <FileSpreadsheet className="mr-2 h-5 w-5" />
                Informazioni Fiscali
              </h2>
            </div>
            <div className="p-6 space-y-4">
              {client.vatNumber && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <CreditCard className="w-5 h-5 text-secondary-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Partita IVA</p>
                    <p className="font-medium">{client.vatNumber}</p>
                  </div>
                </div>
              )}
              
              {client.fiscalCode && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <Shield className="w-5 h-5 text-secondary-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Codice Fiscale</p>
                    <p className="font-medium">{client.fiscalCode}</p>
                  </div>
                </div>
              )}
              
              {client.bankName && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <Building className="w-5 h-5 text-secondary-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Banca</p>
                    <p className="font-medium">{client.bankName}</p>
                  </div>
                </div>
              )}
              
              {client.bankIBAN && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <Database className="w-5 h-5 text-secondary-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">IBAN</p>
                    <p className="font-medium">{client.bankIBAN}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Contract Info */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden lg:col-span-2">
            <div className="px-6 py-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white">
              <h2 className="text-lg font-medium flex items-center">
                <FileText className="mr-2 h-5 w-5" />
                Informazioni Contratto
              </h2>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <Calendar className="w-5 h-5 text-purple-500 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Data Inizio</p>
                      <p className="font-medium">{formatDate(client.contractStartDate)}</p>
                    </div>
                  </div>
                </div>
                
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 text-purple-500 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Durata</p>
                      <p className="font-medium">{client.contractDuration} mesi</p>
                    </div>
                  </div>
                </div>
                
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <Settings className="w-5 h-5 text-purple-500 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Stato</p>
                      <p className="font-medium">{client.status}</p>
                    </div>
                  </div>
                </div>
              </div>

              {client.activeServices && client.activeServices.length > 0 && (
                <div className="mt-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-3">Servizi Attivi</h3>
                  <div className="flex flex-wrap gap-2">
                    {client.activeServices.map((service, index) => (
                      <span 
                        key={index}
                        className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm"
                      >
                        {service}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'devices' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {client.devices?.map((device) => (
            <div 
              key={device.id} 
              className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium flex items-center">
                    <Laptop className="w-5 h-5 mr-2 text-primary-500" />
                    {device.name}
                  </h3>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    device.supportStatus === 'active' 
                      ? 'bg-green-100 text-green-800' 
                      : device.supportStatus === 'suspended'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {device.supportStatus}
                  </span>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <Building className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-gray-600">Marca:</span>
                    <span className="ml-2 font-medium">{device.brand}</span>
                  </div>
                  
                  <div className="flex items-center text-sm">
                    <Settings className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-gray-600">Modello:</span>
                    <span className="ml-2 font-medium">{device.model}</span>
                  </div>
                  
                  <div className="flex items-center text-sm">
                    <Hash className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-gray-600">S/N:</span>
                    <span className="ml-2 font-medium">{device.serialNumber}</span>
                  </div>
                  
                  {device.registrationNumber && (
                    <div className="flex items-center text-sm">
                      <Database className="w-4 h-4 text-gray-400 mr-2" />
                      <span className="text-gray-600">Reg:</span>
                      <span className="ml-2 font-medium">{device.registrationNumber}</span>
                    </div>
                  )}
                </div>
                
                <div className="mt-6 flex justify-end space-x-2">
                  <button
                    onClick={() => handleDeviceClick(device)}
                    className="btn btn-sm btn-outline flex items-center"
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    Dettagli
                  </button>
                  
                  <button
                    onClick={() => navigate(`/admin/clients/${id}/devices/${device.id}/edit`)}
                    className="btn btn-sm btn-primary flex items-center"
                  >
                    <Edit className="w-4 h-4 mr-1" />
                    Modifica
                  </button>
                </div>
              </div>
            </div>
          ))}
          
          <div className="flex items-center justify-center p-6 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 hover:border-primary-500 hover:bg-gray-100 transition-colors">
            <button
              onClick={() => navigate(`/admin/clients/${id}/devices/new`)}
              className="btn btn-primary flex items-center"
            >
              <Laptop className="w-5 h-5 mr-2" />
              Aggiungi Dispositivo
            </button>
          </div>
        </div>
      )}

      {activeTab === 'access' && (
        <div className="grid grid-cols-1 gap-6">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="px-6 py-4 bg-gradient-to-r from-primary-600 to-primary-700 text-white">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-medium">Gestione Accesso</h2>
                <div className="flex space-x-2">
                  <button
                    className={`btn btn-sm ${activeSectionView === 'qrcode' ? 'btn-secondary' : 'btn-ghost'}`}
                    onClick={() => setActiveSectionView('qrcode')}
                  >
                    <QrCode className="w-4 h-4 mr-1" />
                    QR Code
                  </button>
                  <button
                    className={`btn btn-sm ${activeSectionView === 'credentials' ? 'btn-secondary' : 'btn-ghost'}`}
                    onClick={() => setActiveSectionView('credentials')}
                  >
                    <Key className="w-4 h-4 mr-1" />
                    Credenziali
                  </button>
                </div>
              </div>
            </div>

            <div className="p-6">
              {activeSectionView === 'qrcode' && (
                <ClientQRCodeGenerator client={client} />
              )}

              {activeSectionView === 'credentials' && (
                <ClientCredentialsGenerator 
                  client={client}
                  onSave={updateClient}
                />
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'files' && (
        <SharedFilesManager 
          client={client}
          onAddFiles={async (files) => {
            try {
              await updateClient({
                ...client,
                sharedFiles: [...(client.sharedFiles || []), ...files]
              });
            } catch (error) {
              console.error('Error adding files:', error);
            }
          }}
          onDeleteFile={async (fileId) => {
            try {
              await updateClient({
                ...client,
                sharedFiles: client.sharedFiles?.filter(f => f.id !== fileId) || []
              });
            } catch (error) {
              console.error('Error deleting file:', error);
            }
          }}
          isAdmin={true}
        />
      )}

      {/* Device Detail Modal */}
      {isDeviceDetailOpen && selectedDevice && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full mx-4">
            <div className="px-6 py-4 bg-gradient-to-r from-primary-600 to-primary-700 text-white flex justify-between items-center">
              <h3 className="text-lg font-medium flex items-center">
                <Laptop className="w-5 h-5 mr-2" />
                Dettagli Dispositivo
              </h3>
              <button
                onClick={handleCloseDeviceDetail}
                className="text-white hover:text-gray-200 focus:outline-none"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Nome</label>
                  <p className="mt-1">{selectedDevice.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Tipo</label>
                  <p className="mt-1">{selectedDevice.type}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Marca</label>
                  <p className="mt-1">{selectedDevice.brand}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Modello</label>
                  <p className="mt-1">{selectedDevice.model}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Numero Serie</label>
                  <p className="mt-1">{selectedDevice.serialNumber}</p>
                </div>
                {selectedDevice.registrationNumber && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Numero Registrazione</label>
                    <p className="mt-1">{selectedDevice.registrationNumber}</p>
                  </div>
                )}
                <div>
                  <label className="text-sm font-medium text-gray-500">Stato Supporto</label>
                  <p className="mt-1">{selectedDevice.supportStatus}</p>
                </div>
                {selectedDevice.hasWarranty && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Scadenza Garanzia</label>
                    <p className="mt-1">{formatDate(selectedDevice.warrantyExpiry)}</p>
                  </div>
                )}
              </div>
              
              {selectedDevice.notes && (
                <div className="mt-6">
                  <label className="text-sm font-medium text-gray-500">Note</label>
                  <p className="mt-1 text-gray-600 whitespace-pre-wrap">{selectedDevice.notes}</p>
                </div>
              )}
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={handleCloseDeviceDetail}
                  className="btn btn-secondary"
                >
                  Chiudi
                </button>
                <button
                  onClick={() => {
                    handleCloseDeviceDetail();
                    navigate(`/admin/clients/${id}/devices/${selectedDevice.id}/edit`);
                  }}
                  className="btn btn-primary"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Modifica
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg max-w-md w-full mx-4">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">Conferma Eliminazione</h3>
            </div>
            
            <div className="p-6">
              <div className="bg-red-50 rounded-md p-4 mb-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <AlertTriangle className="h-5 w-5 text-red-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">
                      Attenzione: Questa azione è irreversibile
                    </h3>
                    <p className="mt-2 text-sm text-red-700">
                      L'eliminazione del cliente comporterà la perdita di tutti i dati associati, 
                      inclusi dispositivi, appuntamenti e ticket.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setIsDeleteModalOpen(false)}
                  className="btn btn-secondary"
                  disabled={isDeleting}
                >
                  Annulla
                </button>
                <button
                  onClick={handleDeleteConfirm}
                  className="btn btn-danger"
                  disabled={isDeleting}
                >
                  {isDeleting ? (
                    <LoadingSpinner size="sm" color="white" />
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4 mr-2" />
                      Elimina
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientDetail;