import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Save, X, AlertTriangle, CheckCircle, User, Building, Phone,
  Mail, MapPin, Hash, Briefcase, Plus, Trash2, Edit, QrCode,
  Key, Shield, FileText, Laptop, Monitor, HardDrive, Printer,
  PenTool, Info, Store, UserCircle, Smartphone, Network, Wifi,
  Usb, Globe, Share2, Cable, Clock, AlertCircle, Calendar
} from 'lucide-react';
import CashRegister from '../../../components/icons/CashRegister';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { Device } from '../../../types';
import { v4 as uuidv4 } from 'uuid';

interface DeviceFormProps {
  clientId?: string;
  deviceId?: string;
  onSave?: () => void;
  onCancel?: () => void;
  isModal?: boolean;
}

const deviceTypes = [
  { id: 'laptop', name: 'Laptop / Notebook', icon: Laptop },
  { id: 'desktop', name: 'PC Desktop', icon: Monitor },
  { id: 'cash_register', name: 'Registratore di Cassa', icon: CashRegister },
  { id: 'printer', name: 'Stampante', icon: Printer },
  { id: 'plotter', name: 'Plotter / Scanner', icon: PenTool },
  { id: 'other', name: 'Altro', icon: Info }
];

const cashRegisterTypes = [
  { id: 'telemetria_epson', name: 'Telemetria EPSON' },
  { id: 'custom', name: 'Custom HUB' }
];

const connectionTypes = [
  { 
    id: 'lan', 
    name: 'LAN', 
    primaryIcon: Network,
    secondaryIcon: Globe,
    description: 'Connessione di rete cablata'
  },
  { 
    id: 'wifi', 
    name: 'Wi-Fi', 
    primaryIcon: Wifi,
    secondaryIcon: Share2,
    description: 'Connessione di rete wireless'
  },
  { 
    id: 'rs232', 
    name: 'RS232', 
    primaryIcon: Cable,
    secondaryIcon: HardDrive,
    description: 'Connessione seriale'
  },
  { 
    id: 'usb', 
    name: 'USB', 
    primaryIcon: Usb,
    secondaryIcon: Cable,
    description: 'Connessione USB diretta'
  }
];

const DeviceForm: React.FC<DeviceFormProps> = ({ 
  clientId, 
  deviceId, 
  onSave, 
  onCancel,
  isModal = false
}) => {
  const { id } = useParams<{ id: string; deviceId: string }>();
  const resolvedClientId = clientId || id || '';
  const resolvedDeviceId = deviceId || useParams<{ deviceId: string }>().deviceId;
  const isEditMode = !!resolvedDeviceId;
  
  const { state, updateClient, addNotification } = useData();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState<Partial<Device>>({
    name: '',
    brand: '',
    model: '',
    serialNumber: '',
    registrationNumber: '',
    hasWarranty: false,
    warrantyExpiry: '',
    supportStatus: 'active',
    notes: '',
    type: 'laptop',
    verificationDate: '',
  });
  
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  const client = state.clients.find(c => c.id === resolvedClientId);

  const getVerificationStatus = (verificationDate: string) => {
    if (!verificationDate) return { isExpired: false, daysRemaining: 0 };
    
    const verification = new Date(verificationDate);
    const expiryDate = new Date(verification.setDate(verification.getDate() + 360));
    const today = new Date();
    const daysRemaining = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    return {
      isExpired: daysRemaining <= 0,
      daysRemaining: Math.max(0, daysRemaining)
    };
  };

  useEffect(() => {
    if (formData.type === 'cash_register' && formData.verificationDate) {
      const { isExpired, daysRemaining } = getVerificationStatus(formData.verificationDate);
      
      if (isExpired || daysRemaining <= 30) {
        const message = isExpired 
          ? `Verificazione periodica scaduta per ${formData.name}`
          : `Verificazione periodica in scadenza tra ${daysRemaining} giorni per ${formData.name}`;
          
        if (addNotification) {
          addNotification({
            title: 'Verificazione Periodica',
            message,
            type: isExpired ? 'error' : 'warning',
            isRead: false
          });
        }
      }
    }
  }, [formData.type, formData.verificationDate, formData.name]);
  
  useEffect(() => {
    if (isEditMode && resolvedDeviceId && client) {
      const device = client.devices?.find(d => d.id === resolvedDeviceId);
      if (device) {
        setFormData({
          ...device
        });
      }
    }
  }, [isEditMode, resolvedDeviceId, client]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      setFormData({
        ...formData,
        [name]: checkbox.checked
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
    
    if (formErrors[name]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  
  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.name?.trim()) {
      errors.name = "Il nome del dispositivo è obbligatorio";
    }
    
    if (!formData.brand?.trim()) {
      errors.brand = "La marca è obbligatoria";
    }
    
    if (!formData.model?.trim()) {
      errors.model = "Il modello è obbligatorio";
    }
    
    if (!formData.serialNumber?.trim()) {
      errors.serialNumber = "Il numero di serie è obbligatorio";
    }
    
    if (formData.hasWarranty && !formData.warrantyExpiry) {
      errors.warrantyExpiry = "La data di scadenza della garanzia è obbligatoria";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    if (!client) {
      setFormErrors({ submit: "Cliente non trovato" });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const currentDevices = [...(client.devices || [])];
      
      if (isEditMode && resolvedDeviceId) {
        const deviceIndex = currentDevices.findIndex(d => d.id === resolvedDeviceId);
        if (deviceIndex !== -1) {
          currentDevices[deviceIndex] = {
            ...currentDevices[deviceIndex],
            ...formData,
            clientId: resolvedClientId,
            locationId: formData.locationId || client.locations?.[0]?.id || '',
          } as Device;
        }
      } else {
        const newDevice: Device = {
          id: uuidv4(),
          clientId: resolvedClientId,
          locationId: formData.locationId || client.locations?.[0]?.id || '',
          name: formData.name || '',
          brand: formData.brand || '',
          model: formData.model || '',
          serialNumber: formData.serialNumber || '',
          registrationNumber: formData.registrationNumber || '',
          hasWarranty: formData.hasWarranty || false,
          warrantyExpiry: formData.warrantyExpiry,
          supportStatus: formData.supportStatus as 'active' | 'suspended' | 'expired',
          notes: formData.notes,
          type: formData.type,
          verificationDate: formData.verificationDate,
          cashRegisterType: formData.cashRegisterType,
          connectionType: formData.connectionType,
          ipAddress: formData.ipAddress,
          port: formData.port,
          comPort: formData.comPort,
          baudRate: formData.baudRate
        };
        
        currentDevices.push(newDevice);
      }
      
      await updateClient({
        ...client,
        devices: currentDevices
      });
      
      setSuccessMessage(isEditMode ? "Dispositivo aggiornato con successo" : "Dispositivo aggiunto con successo");
      
      if (onSave) {
        onSave();
        return;
      }
      
      setTimeout(() => {
        navigate(`/admin/clients/${resolvedClientId}`);
      }, 1500);
    } catch (error) {
      console.error("Error saving device:", error);
      setFormErrors({ submit: "Si è verificato un errore durante il salvataggio. Riprova." });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleCancel = () => {
    if (onCancel) {
      onCancel();
    } else {
      navigate(`/admin/clients/${resolvedClientId}`);
    }
  };
  
  if (state.isLoading) {
    return (
      <div className={`${isModal ? '' : 'page-container'} flex items-center justify-center h-full`}>
        <LoadingSpinner size="lg" text="Caricamento..." />
      </div>
    );
  }
  
  if (!client) {
    return (
      <div className={`${isModal ? '' : 'page-container'}`}>
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">Cliente non trovato.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className={`${isModal ? '' : 'page-container'}`}>
      {!isModal && (
        <div className="mb-6">
          <h1 className="page-title">{isEditMode ? 'Modifica Dispositivo' : 'Nuovo Dispositivo'}</h1>
          <p className="text-gray-600">
            {isEditMode ? 'Modifica i dati del dispositivo esistente' : 'Inserisci i dati per aggiungere un nuovo dispositivo'}
            {' '}per il cliente <strong>{client.name}</strong>
          </p>
        </div>
      )}
      
      {successMessage && (
        <div className="mb-6 bg-green-50 border-l-4 border-green-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <CheckCircle className="h-5 w-5 text-green-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-700">{successMessage}</p>
            </div>
          </div>
        </div>
      )}
      
      {formErrors.submit && (
        <div className="mb-6 bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{formErrors.submit}</p>
            </div>
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-6">
          <div className="px-6 py-4 bg-primary-700 text-white">
            <h2 className="text-lg font-medium">Informazioni Dispositivo</h2>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="form-label mb-2">
                  Tipo di Dispositivo <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                  {deviceTypes.map((type) => {
                    const TypeIcon = type.icon;
                    const isSelected = formData.type === type.id;
                    
                    return (
                      <button
                        key={type.id}
                        type="button"
                        onClick={() => setFormData({ ...formData, type: type.id })}
                        className={`flex flex-col items-center justify-center p-3 rounded-lg border-2 transition-all ${
                          isSelected 
                            ? 'border-primary-500 bg-primary-50 text-primary-700' 
                            : 'border-gray-200 hover:border-gray-300 text-gray-600'
                        }`}
                      >
                        <TypeIcon className={`h-8 w-8 mb-2 ${isSelected ? 'text-primary-600' : 'text-gray-500'}`} />
                        <span className="text-xs font-medium text-center">{type.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
              
              <div>
                <label htmlFor="name" className="form-label">
                  Nome Dispositivo <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className={`input ${formErrors.name ? 'border-red-300' : ''}`}
                  placeholder="Es. Notebook Ufficio, Registratore Cassa 1, ecc."
                  value={formData.name || ''}
                  onChange={handleInputChange}
                  required
                />
                {formErrors.name && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.name}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="brand" className="form-label">
                  Marca <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="brand"
                  name="brand"
                  className={`input ${formErrors.brand ? 'border-red-300' : ''}`}
                  placeholder="Es. HP, Dell, Apple, ecc."
                  value={formData.brand || ''}
                  onChange={handleInputChange}
                  required
                />
                {formErrors.brand && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.brand}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="model" className="form-label">
                  Modello <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="model"
                  name="model"
                  className={`input ${formErrors.model ? 'border-red-300' : ''}`}
                  placeholder="Es. Latitude 5510, MacBook Pro, ecc."
                  value={formData.model || ''}
                  onChange={handleInputChange}
                  required
                />
                {formErrors.model && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.model}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="serialNumber" className="form-label">
                  Numero di Serie <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="serialNumber"
                  name="serialNumber"
                  className={`input ${formErrors.serialNumber ? 'border-red-300' : ''}`}
                  placeholder="Es. SN12345678"
                  value={formData.serialNumber || ''}
                  onChange={handleInputChange}
                  required
                />
                {formErrors.serialNumber && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.serialNumber}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="registrationNumber" className="form-label">
                  Numero di Registrazione
                </label>
                <input
                  type="text"
                  id="registrationNumber"
                  name="registrationNumber"
                  className="input"
                  placeholder="Eventuale numero di registrazione"
                  value={formData.registrationNumber || ''}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="supportStatus" className="form-label">
                  Stato di Supporto
                </label>
                <select
                  id="supportStatus"
                  name="supportStatus"
                  className="input"
                  value={formData.supportStatus || 'active'}
                  onChange={handleInputChange}
                >
                  <option value="active">Attivo</option>
                  <option value="suspended">Sospeso</option>
                  <option value="expired">Scaduto</option>
                </select>
              </div>
              
              <div>
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    id="hasWarranty"
                    name="hasWarranty"
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                    checked={formData.hasWarranty || false}
                    onChange={handleInputChange}
                  />
                  <label htmlFor="hasWarranty" className="ml-2 block form-label mb-0">
                    In Garanzia
                  </label>
                </div>
                {formData.hasWarranty && (
                  <div className="mt-2">
                    <label htmlFor="warrantyExpiry" className="form-label">
                      Data Scadenza Garanzia <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="date"
                        id="warrantyExpiry"
                        name="warrantyExpiry"
                        className={`input pl-10 ${formErrors.warrantyExpiry ? 'border-red-300' : ''}`}
                        value={formData.warrantyExpiry || ''}
                        onChange={handleInputChange}
                        min={new Date().toISOString().split('T')[0]}
                      />
                    </div>
                    {formErrors.warrantyExpiry && (
                      <p className="mt-1 text-sm text-red-600">{formErrors.warrantyExpiry}</p>
                    )}
                  </div>
                )}
              </div>
              
              <div>
                <label htmlFor="locationId" className="form-label">
                  Sede
                </label>
                <select
                  id="locationId"
                  name="locationId"
                  className="input"
                  value={formData.locationId || (client.locations && client.locations.length > 0 ? client.locations[0].id : '')}
                  onChange={handleInputChange}
                >
                  {client.locations && client.locations.length > 0 ? (
                    client.locations.map(location => (
                      <option key={location.id} value={location.id}>
                        {location.name} {location.isHeadquarter ? '(Sede Principale)' : ''}
                      </option>
                    ))
                  ) : (
                    <option value="">Sede predefinita</option>
                  )}
                </select>
              </div>
              
              <div className="md:col-span-2">
                <label htmlFor="notes" className="form-label">
                  Note
                </label>
                <textarea
                  id="notes"
                  name="notes"
                  rows={3}
                  className="input"
                  placeholder="Eventuali note sul dispositivo"
                  value={formData.notes || ''}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </div>
        </div>
        
        {formData.type === 'cash_register' && (
          <div className={`md:col-span-2 p-4 rounded-lg border ${
            formData.verificationDate 
              ? getVerificationStatus(formData.verificationDate).isExpired 
                ? 'bg-red-50 border-red-200' 
                : 'bg-green-50 border-green-200'
              : 'bg-gray-50 border-gray-200'
          }`}>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Dettagli Registratore di Cassa</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="form-label">Tipo Registratore</label>
                <div className="flex space-x-4">
                  {cashRegisterTypes.map(type => (
                    <label key={type.id} className="flex items-center">
                      <input
                        type="radio"
                        name="cashRegisterType"
                        value={type.id}
                        checked={formData.cashRegisterType === type.id}
                        onChange={(e) => setFormData({
                          ...formData,
                          cashRegisterType: e.target.value as 'telemetria_epson' | 'custom'
                        })}
                        className="form-radio h-4 w-4 text-primary-600"
                      />
                      <span className="ml-2 text-sm text-gray-700">{type.name}</span>
                    </label>
                  ))}
                </div>
              </div>
              
              <div>
                <label htmlFor="verificationDate" className="form-label">
                  Data Verificazione Periodica
                </label>
                <input
                  type="date"
                  id="verificationDate"
                  name="verificationDate"
                  className="input"
                  value={formData.verificationDate || ''}
                  onChange={handleInputChange}
                />
                {formData.verificationDate && (
                  <div className="mt-2">
                    {(() => {
                      const { isExpired, daysRemaining } = getVerificationStatus(formData.verificationDate);
                      if (isExpired) {
                        return (
                          <p className="text-sm text-red-600 flex items-center">
                            <AlertTriangle className="h-4 w-4 mr-1" />
                            Verificazione scaduta
                          </p>
                        );
                      }
                      return (
                        <p className={`text-sm ${daysRemaining <= 30 ? 'text-yellow-600' : 'text-green-600'} flex items-center`}>
                          <Clock className="h-4 w-4 mr-1" />
                          {daysRemaining} giorni alla scadenza
                        </p>
                      );
                    })()}
                  </div>
                )}
              </div>
              
              <div>
                <label className="form-label">Tipo Connessione</label>
                <div className="grid grid-cols-2 gap-4">
                  {connectionTypes.map(type => (
                    <label 
                      key={type.id} 
                      className={`flex items-center p-3 rounded-lg border-2 transition-all cursor-pointer ${
                        formData.connectionType === type.id
                          ? 'border-primary-500 bg-primary-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="connectionType"
                        value={type.id}
                        checked={formData.connectionType === type.id}
                        onChange={(e) => setFormData({
                          ...formData,
                          connectionType: e.target.value as 'lan' | 'wifi' | 'rs232' | 'usb'
                        })}
                        className="sr-only"
                      />
                      <div className="flex-1 flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center relative">
                          <type.primaryIcon className="h-5 w-5 text-primary-600" />
                          <div className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-primary-200 flex items-center justify-center">
                            <type.secondaryIcon className="h-3 w-3 text-primary-700" />
                          </div>
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">{type.name}</p>
                          <p className="text-xs text-gray-500">{type.description}</p>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
              
              {(formData.connectionType === 'lan' || formData.connectionType === 'wifi') && (
                <div>
                  <label htmlFor="ipAddress" className="form-label">
                    Indirizzo IP
                  </label>
                  <input
                    type="text"
                    id="ipAddress"
                    name="ipAddress"
                    className="input"
                    placeholder="192.168.1.100"
                    value={formData.ipAddress || ''}
                    onChange={handleInputChange}
                  />
                </div>
              )}
              
              {(formData.connectionType === 'lan' || formData.connectionType === 'wifi') && (
                <div>
                  <label htmlFor="port" className="form-label">
                    Porta
                  </label>
                  <input
                    type="text"
                    id="port"
                    name="port"
                    className="input"
                    placeholder="9100"
                    value={formData.port || ''}
                    onChange={handleInputChange}
                  />
                </div>
              )}
              
              {formData.connectionType === 'rs232' && (
                <div>
                  <label htmlFor="comPort" className="form-label">
                    Porta COM
                  </label>
                  <input
                    type="text"
                    id="comPort"
                    name="comPort"
                    className="input"
                    placeholder="COM1"
                    value={formData.comPort || ''}
                    onChange={handleInputChange}
                  />
                </div>
              )}
              
              {formData.connectionType === 'rs232' && (
                <div>
                  <label htmlFor="baudRate" className="form-label">
                    Baud Rate
                  </label>
                  <select
                    id="baudRate"
                    name="baudRate"
                    className="input"
                    value={formData.baudRate || '9600'}
                    onChange={handleInputChange}
                  >
                    <option value="9600">9600</option>
                    <option value="19200">19200</option>
                    <option value="38400">38400</option>
                    <option value="57600">57600</option>
                    <option value="115200">115200</option>
                  </select>
                </div>
              )}
            </div>
          </div>
        )}
        
        <div className="flex justify-between">
          <button
            type="button"
            onClick={handleCancel}
            className="btn btn-secondary"
          >
            <X className="h-5 w-5 mr-1" />
            Annulla
          </button>
          
          <button
            type="submit"
            className="btn btn-primary"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <LoadingSpinner size="sm" color="white" />
            ) : (
              <>
                <Save className="h-5 w-5 mr-1" />
                {isEditMode ? 'Aggiorna Dispositivo' : 'Aggiungi Dispositivo'}
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default DeviceForm;