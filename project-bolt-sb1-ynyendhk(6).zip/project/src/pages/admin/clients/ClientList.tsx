import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Download, Upload, Users } from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import ClientCardGrid from '../../../components/ClientCardGrid';
import ImportPreview from '../../../components/ImportPreview';
import ImportLog from '../../../components/ImportLog';
import { Client } from '../../../types';
import toast from 'react-hot-toast';

const ClientList: React.FC = () => {
  const { state, deleteClient } = useData();
  const navigate = useNavigate();
  
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [clientToDelete, setClientToDelete] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importLogs, setImportLogs] = useState<any[]>([]);
  
  // Handle client deletion
  const handleDelete = async (clientId: string) => {
    try {
      await deleteClient(clientId);
      toast.success('Cliente eliminato con successo');
    } catch (error) {
      console.error('Error deleting client:', error);
      toast.error('Errore durante l\'eliminazione del cliente');
    }
  };
  
  // Handle client sharing
  const handleShare = (client: Client) => {
    // Implement sharing functionality
    toast.success('Link di condivisione copiato negli appunti');
  };
  
  // Handle client export
  const handleExport = (client: Client) => {
    // Implement export functionality
    toast.success('Esportazione completata');
  };
  
  // Handle bulk export
  const handleExportAll = () => {
    // Implement bulk export functionality
    toast.success('Esportazione di massa completata');
  };

  if (state.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center">
          <Users className="h-8 w-8 text-primary-600 mr-3" />
          <h1 className="text-2xl font-bold text-gray-900">
            Elenco clienti registrati
          </h1>
        </div>
        <p className="mt-1 text-sm text-gray-500">
          Gestisci e organizza l'anagrafica dei tuoi clienti
        </p>
      </div>

      {/* Client Grid */}
      <ClientCardGrid
        clients={state.clients}
        onDelete={handleDelete}
        onShare={handleShare}
        onExport={handleExport}
        onAdd={() => navigate('/admin/clients/new')}
        onImport={() => setIsImportModalOpen(true)}
        onExportAll={handleExportAll}
      />

      {/* Import Modal */}
      {isImportModalOpen && selectedFile && (
        <ImportPreview
          file={selectedFile}
          type="clients"
          onImport={(data, log) => {
            setImportLogs(prev => [...prev, log]);
            setIsImportModalOpen(false);
            setSelectedFile(null);
            toast.success(`Importati ${data.length} clienti con successo`);
          }}
          onCancel={() => {
            setIsImportModalOpen(false);
            setSelectedFile(null);
          }}
        />
      )}

      {/* Import Logs */}
      {importLogs.length > 0 && (
        <div className="mt-8">
          <ImportLog logs={importLogs} />
        </div>
      )}
    </div>
  );
};

export default ClientList;