import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Save, X, AlertTriangle, CheckCircle } from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { Client } from '../../../types';
import { BasicInfoSection, AddressSection, FiscalSection, CategorySection, CommunicationSection } from '../../../components/ClientFormSections';
import toast from 'react-hot-toast';

const ClientForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const isEditMode = !!id;
  
  const { state, addClient, updateClient } = useData();
  const navigate = useNavigate();
  
  // Form States
  const [formData, setFormData] = useState<Partial<Client>>({
    name: '',
    storeName: '',
    email: '',
    phone: '',
    mobile: '',
    address: '',
    city: '',
    postalCode: '',
    vatNumber: '',
    fiscalCode: '',
    bankName: '',
    bankIBAN: '',
    website: '',
    category: 'business',
    type: 'standard',
    enableWhatsApp: false,
    enableEmailNotifications: true,
    enableSMS: false,
    isInactive: false
  });
  
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Load client data if editing
  useEffect(() => {
    if (isEditMode && id) {
      const client = state.clients.find(c => c.id === id);
      if (client) {
        setFormData(client);
      }
    }
  }, [isEditMode, id, state.clients]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
    
    // Clear error when field is updated
    if (formErrors[name]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  
  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.name?.trim()) {
      errors.name = "Il nome è obbligatorio";
    }
    
    if (formData.email && !/^\S+@\S+\.\S+$/.test(formData.email)) {
      errors.email = "Formato email non valido";
    }
    
    if (formData.vatNumber && !/^\d{11}$/.test(formData.vatNumber)) {
      errors.vatNumber = "La partita IVA deve essere di 11 cifre";
    }
    
    if (formData.fiscalCode && !/^[A-Z0-9]{16}$/.test(formData.fiscalCode.toUpperCase())) {
      errors.fiscalCode = "Il codice fiscale deve essere di 16 caratteri";
    }

    if (formData.bankIBAN && !/^[A-Z]{2}\d{2}[A-Z0-9]{4}\d{20}$/i.test(formData.bankIBAN)) {
      errors.bankIBAN = "Formato IBAN non valido";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Verifica i campi evidenziati');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      if (isEditMode && id) {
        await updateClient(formData as Client);
        toast.success('Cliente aggiornato con successo');
      } else {
        await addClient({
          ...formData,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        toast.success('Cliente creato con successo');
      }
      
      navigate('/admin/clients');
    } catch (error) {
      console.error("Error saving client:", error);
      toast.error('Si è verificato un errore durante il salvataggio');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (state.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">
          {isEditMode ? 'Modifica Cliente' : 'Nuovo Cliente'}
        </h1>
        <p className="mt-2 text-sm text-gray-500">
          {isEditMode 
            ? 'Modifica i dati del cliente esistente' 
            : 'Inserisci i dati per creare un nuovo cliente'
          }
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <BasicInfoSection 
          formData={formData}
          onChange={handleInputChange}
          errors={formErrors}
        />
        
        <AddressSection 
          formData={formData}
          onChange={handleInputChange}
          errors={formErrors}
        />
        
        <FiscalSection 
          formData={formData}
          onChange={handleInputChange}
          errors={formErrors}
        />
        
        <CategorySection 
          formData={formData}
          onChange={handleInputChange}
        />
        
        <CommunicationSection 
          formData={formData}
          onChange={handleInputChange}
        />
        
        {/* Form Actions */}
        <div className="flex justify-between pt-6">
          <button
            type="button"
            onClick={() => navigate('/admin/clients')}
            className="macos-button flex items-center"
          >
            <X className="h-5 w-5 mr-1" />
            Annulla
          </button>
          
          <button
            type="submit"
            className="macos-button-primary flex items-center"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <LoadingSpinner size="sm" color="white" />
            ) : (
              <>
                <Save className="h-5 w-5 mr-1" />
                {isEditMode ? 'Aggiorna Cliente' : 'Crea Cliente'}
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ClientForm;