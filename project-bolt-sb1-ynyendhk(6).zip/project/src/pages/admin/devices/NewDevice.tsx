import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Save, X, AlertTriangle, CheckCircle, Laptop, Monitor, Printer, HardDrive, Key, Database, Network, Wifi, Smartphone, PenTool as Tool, Info, CreditCard, Clock, Calendar, Settings, Activity } from 'lucide-react';
import CashRegister from '../../../components/icons/CashRegister';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import HelpPostIt from '../../../components/HelpPostIt';
import { Device } from '../../../types';
import { v4 as uuidv4 } from 'uuid';

const deviceTypes = [
  { id: 'laptop', name: 'Laptop / Notebook', icon: Laptop },
  { id: 'desktop', name: 'PC Desktop', icon: Monitor },
  { id: 'cash_register', name: 'Registratore di Cassa', icon: CashRegister },
  { id: 'printer', name: 'Stampante', icon: Printer },
  { id: 'plotter', name: 'Plotter / Scanner', icon: Tool },
  { id: 'other', name: 'Altro', icon: HardDrive }
];

const connectionTypes = [
  { 
    id: 'lan', 
    name: 'LAN', 
    icon: Network,
    description: 'Connessione di rete cablata'
  },
  { 
    id: 'wifi', 
    name: 'Wi-Fi', 
    icon: Wifi,
    description: 'Connessione di rete wireless'
  },
  { 
    id: 'rs232', 
    name: 'RS232', 
    icon: Database,
    description: 'Connessione seriale'
  },
  { 
    id: 'usb', 
    name: 'USB', 
    icon: Smartphone,
    description: 'Connessione USB diretta'
  }
];

const NewDevice: React.FC = () => {
  const { state } = useData();
  const navigate = useNavigate();

  const [formData, setFormData] = useState<Partial<Device>>({
    name: '',
    type: 'laptop',
    brand: '',
    model: '',
    serialNumber: '',
    registrationNumber: '',
    fiscalNumber: '', // New Matricola Fiscale field
    hasWarranty: false,
    warrantyExpiry: '',
    supportStatus: 'active',
    notes: '',
    verificationDate: '',
    connectionType: 'lan',
    ipAddress: '',
    port: '',
    comPort: '',
    baudRate: '9600'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulated save - replace with actual save logic
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSubmitting(false);
    
    navigate('/admin/devices');
  };

  return (
    <div className="page-container">
      <div className="mb-6">
        <h1 className="page-title">Nuovo Dispositivo</h1>
        <p className="text-gray-600">Registra un nuovo dispositivo nel sistema</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Device Type Selection */}
        <div className="macos-window">
          <div className="macos-window-header">
            <h2 className="text-lg font-medium flex items-center">
              <HardDrive className="h-5 w-5 mr-2" />
              Tipo Dispositivo
            </h2>
          </div>
          
          <div className="macos-window-content">
            <HelpPostIt
              title="Suggerimento"
              content="Seleziona il tipo di dispositivo per visualizzare i campi specifici. Alcuni campi cambieranno in base al tipo selezionato."
              color="blue"
              icon={<Info className="h-5 w-5" />}
            />

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mt-6">
              {deviceTypes.map(type => (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, type: type.id }))}
                  className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all duration-200 ${
                    formData.type === type.id
                      ? 'border-primary-500 bg-primary-50 text-primary-700'
                      : 'border-gray-200 hover:border-primary-200 hover:bg-gray-50'
                  }`}
                >
                  <div className={`p-3 rounded-lg ${
                    formData.type === type.id
                      ? 'bg-primary-100'
                      : 'bg-gray-100'
                  }`}>
                    <type.icon className={`h-8 w-8 ${
                      formData.type === type.id
                        ? 'text-primary-600'
                        : 'text-gray-500'
                    }`} />
                  </div>
                  <span className="mt-2 text-sm font-medium text-center">
                    {type.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Basic Info */}
        <div className="macos-window">
          <div className="macos-window-header">
            <h2 className="text-lg font-medium flex items-center">
              <Info className="h-5 w-5 mr-2" />
              Informazioni Base
            </h2>
          </div>
          
          <div className="macos-window-content">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="form-label">Nome Dispositivo</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="macos-input"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Es. Registratore Cassa 1"
                />
              </div>

              <div>
                <label htmlFor="brand" className="form-label">Marca</label>
                <input
                  type="text"
                  id="brand"
                  name="brand"
                  className="macos-input"
                  value={formData.brand}
                  onChange={handleInputChange}
                  placeholder="Es. Epson, Custom, ecc."
                />
              </div>

              <div>
                <label htmlFor="model" className="form-label">Modello</label>
                <input
                  type="text"
                  id="model"
                  name="model"
                  className="macos-input"
                  value={formData.model}
                  onChange={handleInputChange}
                  placeholder="Es. FP-81 II RT"
                />
              </div>

              <div>
                <label htmlFor="serialNumber" className="form-label">Numero di Serie</label>
                <input
                  type="text"
                  id="serialNumber"
                  name="serialNumber"
                  className="macos-input"
                  value={formData.serialNumber}
                  onChange={handleInputChange}
                  placeholder="Es. 12345678"
                />
              </div>

              <div>
                <label htmlFor="registrationNumber" className="form-label">Numero di Registrazione</label>
                <input
                  type="text"
                  id="registrationNumber"
                  name="registrationNumber"
                  className="macos-input"
                  value={formData.registrationNumber}
                  onChange={handleInputChange}
                  placeholder="Es. REG123456"
                />
              </div>

              <div>
                <label htmlFor="fiscalNumber" className="form-label">
                  Matricola Fiscale
                  <span className="ml-1 text-xs text-gray-500">(Nuovo)</span>
                </label>
                <input
                  type="text"
                  id="fiscalNumber"
                  name="fiscalNumber"
                  className="macos-input"
                  value={formData.fiscalNumber}
                  onChange={handleInputChange}
                  placeholder="Es. 1234567890"
                />
                <HelpPostIt
                  title="Novità"
                  content="La Matricola Fiscale è un nuovo identificativo univoco assegnato dall'Agenzia delle Entrate."
                  color="yellow"
                  icon={<Info className="h-4 w-4" />}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Warranty & Support */}
        <div className="macos-window">
          <div className="macos-window-header">
            <h2 className="text-lg font-medium flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Garanzia e Supporto
            </h2>
          </div>
          
          <div className="macos-window-content">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    id="hasWarranty"
                    name="hasWarranty"
                    checked={formData.hasWarranty}
                    onChange={handleInputChange}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="hasWarranty" className="ml-2 text-sm font-medium text-gray-700">
                    In Garanzia
                  </label>
                </div>

                {formData.hasWarranty && (
                  <div className="mt-2">
                    <label htmlFor="warrantyExpiry" className="form-label">
                      Scadenza Garanzia
                    </label>
                    <input
                      type="date"
                      id="warrantyExpiry"
                      name="warrantyExpiry"
                      className="macos-input"
                      value={formData.warrantyExpiry}
                      onChange={handleInputChange}
                    />
                  </div>
                )}
              </div>

              <div>
                <label htmlFor="supportStatus" className="form-label">Stato Supporto</label>
                <select
                  id="supportStatus"
                  name="supportStatus"
                  className="macos-input"
                  value={formData.supportStatus}
                  onChange={handleInputChange}
                >
                  <option value="active">Attivo</option>
                  <option value="suspended">Sospeso</option>
                  <option value="expired">Scaduto</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Connection Settings */}
        <div className="macos-window">
          <div className="macos-window-header">
            <h2 className="text-lg font-medium flex items-center">
              <Network className="h-5 w-5 mr-2" />
              Connettività
            </h2>
          </div>
          
          <div className="macos-window-content">
            <div className="grid grid-cols-2 gap-4 mb-6">
              {connectionTypes.map(type => (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, connectionType: type.id }))}
                  className={`flex items-center p-4 rounded-xl border-2 transition-all ${
                    formData.connectionType === type.id
                      ? 'border-primary-500 bg-primary-50'
                      : 'border-gray-200 hover:border-primary-200'
                  }`}
                >
                  <div className={`p-3 rounded-lg ${
                    formData.connectionType === type.id
                      ? 'bg-primary-100'
                      : 'bg-gray-100'
                  }`}>
                    <type.icon className={`h-6 w-6 ${
                      formData.connectionType === type.id
                        ? 'text-primary-600'
                        : 'text-gray-500'
                    }`} />
                  </div>
                  <div className="ml-4">
                    <p className="font-medium">{type.name}</p>
                    <p className="text-sm text-gray-500">{type.description}</p>
                  </div>
                </button>
              ))}
            </div>

            {(formData.connectionType === 'lan' || formData.connectionType === 'wifi') && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="ipAddress" className="form-label">Indirizzo IP</label>
                  <input
                    type="text"
                    id="ipAddress"
                    name="ipAddress"
                    className="macos-input"
                    value={formData.ipAddress}
                    onChange={handleInputChange}
                    placeholder="192.168.1.100"
                  />
                </div>

                <div>
                  <label htmlFor="port" className="form-label">Porta</label>
                  <input
                    type="text"
                    id="port"
                    name="port"
                    className="macos-input"
                    value={formData.port}
                    onChange={handleInputChange}
                    placeholder="9100"
                  />
                </div>
              </div>
            )}

            {formData.connectionType === 'rs232' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="comPort" className="form-label">Porta COM</label>
                  <input
                    type="text"
                    id="comPort"
                    name="comPort"
                    className="macos-input"
                    value={formData.comPort}
                    onChange={handleInputChange}
                    placeholder="COM1"
                  />
                </div>

                <div>
                  <label htmlFor="baudRate" className="form-label">Baud Rate</label>
                  <select
                    id="baudRate"
                    name="baudRate"
                    className="macos-input"
                    value={formData.baudRate}
                    onChange={handleInputChange}
                  >
                    <option value="9600">9600</option>
                    <option value="19200">19200</option>
                    <option value="38400">38400</option>
                    <option value="57600">57600</option>
                    <option value="115200">115200</option>
                  </select>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Notes */}
        <div className="macos-window">
          <div className="macos-window-header">
            <h2 className="text-lg font-medium flex items-center">
              <Info className="h-5 w-5 mr-2" />
              Note Aggiuntive
            </h2>
          </div>
          
          <div className="macos-window-content">
            <textarea
              id="notes"
              name="notes"
              rows={4}
              className="macos-input"
              value={formData.notes}
              onChange={handleInputChange}
              placeholder="Inserisci eventuali note o informazioni aggiuntive..."
            />
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex justify-between">
          <button
            type="button"
            onClick={() => navigate('/admin/devices')}
            className="macos-button flex items-center"
          >
            <X className="h-5 w-5 mr-1" />
            Annulla
          </button>

          <button
            type="submit"
            className="macos-button-primary flex items-center"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <LoadingSpinner size="sm" color="white" />
            ) : (
              <>
                <Save className="h-5 w-5 mr-1" />
                Salva Dispositivo
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewDevice;