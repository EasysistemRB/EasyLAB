import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Download, Upload, Archive, RefreshCw, CheckCircle, 
  AlertTriangle, Clock, Calendar, Database, HardDrive,
  Settings, FileText, Save, Link, Key, LogOut, 
  Shield, Info, Book, UserPlus, ChevronRight, Globe, 
  Phone, Building, Mail, X, Eye, EyeOff, Lock, Unlock,
  CloudDrizzle, CloudLightning, CloudRain, CloudSnow, 
  CloudOff as CloudX, Smartphone, Tablet, Laptop, LampDesk as 
  Desktop, Printer, Wifi as WifiIcon, Database as DatabaseIcon, 
  Server as ServerIcon, Cloud as CloudIcon, HardDrive as 
  StorageIcon
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import { useBackup } from '../../../hooks/useBackup';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { formatBackupSize, calculateBackupStats } from '../../../utils/backupUtils';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

const BackupDashboard: React.FC = () => {
  const { state } = useData();
  const { createBackup, restoreBackup, getBackupHistory, deleteBackup, isLoading } = useBackup();
  const navigate = useNavigate();
  
  const [backupHistory, setBackupHistory] = useState<any[]>([]);
  const [selectedBackup, setSelectedBackup] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [backupStats, setBackupStats] = useState({
    totalSize: 0,
    averageSize: 0,
    successRate: 0,
    lastBackupDate: null as Date | null,
    backupTrend: 0,
    compressionRatio: 0,
    backupsByType: {
      full: 0,
      partial: 0
    },
    backupsByStatus: {
      success: 0,
      failed: 0,
      partial: 0
    }
  });
  
  // Load backup history and calculate stats
  useEffect(() => {
    const loadHistory = async () => {
      try {
        const history = await getBackupHistory();
        setBackupHistory(history);
        
        // Calculate statistics
        if (history.length > 0) {
          const stats = calculateBackupStats(history);
          setBackupStats(stats);
        }
      } catch (error) {
        console.error('Error loading backup history:', error);
      }
    };
    
    loadHistory();
  }, [getBackupHistory]);
  
  // Handle manual backup
  const handleBackup = async () => {
    try {
      await createBackup({ type: 'full' });
      setSuccessMessage('Backup creato con successo');
      // Refresh history
      const history = await getBackupHistory();
      setBackupHistory(history);
    } catch (error) {
      setErrorMessage('Errore durante la creazione del backup');
    }
  };
  
  // Handle restore
  const handleRestore = async () => {
    if (!selectedBackup) return;
    
    try {
      await restoreBackup(selectedBackup);
      setSuccessMessage('Backup ripristinato con successo');
    } catch (error) {
      setErrorMessage('Errore durante il ripristino del backup');
    }
  };
  
  // Handle delete backup
  const handleDelete = async (backupId: string) => {
    try {
      await deleteBackup(backupId);
      setSuccessMessage('Backup eliminato con successo');
      // Refresh history
      const history = await getBackupHistory();
      setBackupHistory(history);
    } catch (error) {
      setErrorMessage('Errore durante l\'eliminazione del backup');
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg p-4 mr-4">
              <Archive className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Gestione Backup</h1>
              <p className="mt-1 text-sm text-gray-500">
                Gestisci e monitora i backup del sistema
              </p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-blue-100">
                <Archive className="h-6 w-6 text-blue-600" />
              </div>
              <span className="text-2xl font-semibold text-blue-600">
                {backupStats.backupsByType.full + backupStats.backupsByType.partial}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Backup Totali</p>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-green-100">
                <Clock className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-2xl font-semibold text-green-600">
                {backupStats.lastBackupDate ? 
                  format(backupStats.lastBackupDate, 'dd/MM/yyyy') : 
                  'Mai'}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Ultimo Backup</p>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-purple-100">
                <HardDrive className="h-6 w-6 text-purple-600" />
              </div>
              <span className="text-2xl font-semibold text-purple-600">
                {formatBackupSize(backupStats.totalSize)}
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Spazio Totale</p>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-yellow-100">
                <CheckCircle className="h-6 w-6 text-yellow-600" />
              </div>
              <span className="text-2xl font-semibold text-yellow-600">
                {Math.round(backupStats.successRate)}%
              </span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-600">Tasso di Successo</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <button
            onClick={handleBackup}
            disabled={isLoading}
            className="btn bg-primary-600 text-white hover:bg-primary-700 flex items-center justify-center py-4"
          >
            {isLoading ? (
              <LoadingSpinner size="sm" color="white" />
            ) : (
              <>
                <Download className="h-6 w-6 mr-2" />
                Crea Nuovo Backup
              </>
            )}
          </button>
          
          <button
            onClick={handleRestore}
            disabled={isLoading || !selectedBackup}
            className="btn bg-yellow-600 text-white hover:bg-yellow-700 flex items-center justify-center py-4"
          >
            <RefreshCw className="h-6 w-6 mr-2" />
            Ripristina Backup
          </button>
          
          <button
            onClick={() => navigate('/admin/backup/settings')}
            className="btn bg-blue-600 text-white hover:bg-blue-700 flex items-center justify-center py-4"
          >
            <Settings className="h-6 w-6 mr-2" />
            Configura Backup
          </button>
        </div>

        {/* Backup History */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <div className="px-6 py-4 bg-primary-700 text-white">
            <h2 className="text-lg font-medium flex items-center">
              <Clock className="mr-2 h-5 w-5" />
              Cronologia Backup
            </h2>
          </div>
          
          <div className="p-6">
            {backupHistory.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Data
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Tipo
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Dimensione
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Stato
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Azioni
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {backupHistory.map((backup) => (
                      <tr key={backup.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            {format(new Date(backup.timestamp), 'dd/MM/yyyy')}
                          </div>
                          <div className="text-sm text-gray-500">
                            {format(new Date(backup.timestamp), 'HH:mm:ss')}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            backup.type === 'full' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {backup.type === 'full' ? 'Completo' : 'Parziale'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatBackupSize(backup.size)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Completato
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={() => setSelectedBackup(backup.id)}
                            className="text-primary-600 hover:text-primary-900 mr-3"
                          >
                            Seleziona
                          </button>
                          <button
                            onClick={() => handleDelete(backup.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <Database className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Nessun backup presente</p>
                <button
                  onClick={handleBackup}
                  className="mt-4 text-primary-600 hover:text-primary-800"
                >
                  Crea il primo backup
                </button>
              </div>
            )}
          </div>
        </div>
        
        {/* Success/Error Messages */}
        {successMessage && (
          <div className="fixed bottom-4 right-4 bg-green-50 text-green-800 rounded-lg p-4 shadow-lg flex items-center">
            <CheckCircle className="h-5 w-5 text-green-400 mr-2" />
            {successMessage}
          </div>
        )}
        
        {errorMessage && (
          <div className="fixed bottom-4 right-4 bg-red-50 text-red-800 rounded-lg p-4 shadow-lg flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-400 mr-2" />
            {errorMessage}
          </div>
        )}
      </div>
    </div>
  );
};

export default BackupDashboard;