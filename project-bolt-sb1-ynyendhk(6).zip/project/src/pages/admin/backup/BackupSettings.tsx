import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Download, Upload, Archive, RefreshCw, CheckCircle, 
  AlertTriangle, Clock, Calendar, Database, HardDrive,
  Settings, FileText, Save, Link, Key, LogOut, 
  Shield, Info, Book, UserPlus, ChevronRight, Globe, 
  Phone, Building, Mail, X, Eye, EyeOff, Lock, Unlock,
  CloudDrizzle, CloudLightning, CloudRain, CloudSnow, 
  CloudOff as CloudX, Smartphone, Tablet, Laptop, LampDesk as 
  Desktop, Printer, Wifi as WifiIcon, Database as DatabaseIcon, 
  Server as ServerIcon, Cloud as CloudIcon, HardDrive as 
  StorageIcon, Trash2
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import { useBackup } from '../../../hooks/useBackup';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { formatBackupSize, calculateBackupStats } from '../../../utils/backupUtils';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

const BackupSettings: React.FC = () => {
  const { state, updateSettings } = useData();
  const { createBackup, restoreBackup, isLoading: isBackupLoading } = useBackup();
  const navigate = useNavigate();
  
  const [backupSettings, setBackupSettings] = useState({
    frequency: state.settings.backupFrequency,
    time: state.settings.backupTime,
    retention: 30,
    components: {
      clients: true,
      appointments: true,
      tickets: true,
      settings: true
    },
    compress: true,
    encrypt: false
  });
  
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // Handle settings save
  const handleSaveSettings = async () => {
    try {
      await updateSettings({
        backupFrequency: backupSettings.frequency,
        backupTime: backupSettings.time
      });
      
      setSuccessMessage('Impostazioni salvate con successo');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (error) {
      setErrorMessage('Errore durante il salvataggio delle impostazioni');
      setTimeout(() => setErrorMessage(null), 3000);
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg p-4 mr-4">
              <Settings className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Configurazione Backup</h1>
              <p className="mt-1 text-sm text-gray-500">
                Personalizza le impostazioni di backup del sistema
              </p>
            </div>
          </div>
        </div>

        {/* Settings Form */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <div className="px-6 py-4 bg-primary-700 text-white">
            <h2 className="text-lg font-medium flex items-center">
              <FileText className="mr-2 h-5 w-5" />
              Impostazioni Backup
            </h2>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Frequenza Backup
                </label>
                <select
                  value={backupSettings.frequency}
                  onChange={(e) => setBackupSettings(prev => ({
                    ...prev,
                    frequency: e.target.value as 'daily' | 'weekly' | 'monthly'
                  }))}
                  className="mt-1 form-select"
                >
                  <option value="daily">Giornaliero</option>
                  <option value="weekly">Settimanale</option>
                  <option value="monthly">Mensile</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Orario Backup
                </label>
                <input
                  type="time"
                  value={backupSettings.time}
                  onChange={(e) => setBackupSettings(prev => ({
                    ...prev,
                    time: e.target.value
                  }))}
                  className="mt-1 form-input"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Periodo di Conservazione (giorni)
                </label>
                <input
                  type="number"
                  value={backupSettings.retention}
                  onChange={(e) => setBackupSettings(prev => ({
                    ...prev,
                    retention: parseInt(e.target.value)
                  }))}
                  min="1"
                  max="365"
                  className="mt-1 form-input"
                />
              </div>
            </div>
            
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-700 mb-2">
                Componenti da Includere
              </h3>
              <div className="space-y-2">
                {Object.entries(backupSettings.components).map(([key, value]) => (
                  <label key={key} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={value}
                      onChange={(e) => setBackupSettings(prev => ({
                        ...prev,
                        components: {
                          ...prev.components,
                          [key]: e.target.checked
                        }
                      }))}
                      className="form-checkbox h-4 w-4 text-primary-600"
                    />
                    <span className="ml-2 text-sm text-gray-700 capitalize">{key}</span>
                  </label>
                ))}
              </div>
            </div>
            
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-700 mb-2">
                Opzioni Avanzate
              </h3>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={backupSettings.compress}
                    onChange={(e) => setBackupSettings(prev => ({
                      ...prev,
                      compress: e.target.checked
                    }))}
                    className="form-checkbox h-4 w-4 text-primary-600"
                  />
                  <span className="ml-2 text-sm text-gray-700">Comprimi backup</span>
                </label>
                
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={backupSettings.encrypt}
                    onChange={(e) => setBackupSettings(prev => ({
                      ...prev,
                      encrypt: e.target.checked
                    }))}
                    className="form-checkbox h-4 w-4 text-primary-600"
                  />
                  <span className="ml-2 text-sm text-gray-700">Cripta backup</span>
                </label>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => navigate('/admin/backup')}
                className="mr-3 btn btn-secondary"
              >
                <X className="h-5 w-5 mr-1" />
                Annulla
              </button>
              
              <button
                onClick={handleSaveSettings}
                className="btn btn-primary"
              >
                <Save className="h-5 w-5 mr-1" />
                Salva Impostazioni
              </button>
            </div>
          </div>
        </div>
        
        {/* Success/Error Messages */}
        {successMessage && (
          <div className="fixed bottom-4 right-4 bg-green-50 text-green-800 rounded-lg p-4 shadow-lg flex items-center">
            <CheckCircle className="h-5 w-5 text-green-400 mr-2" />
            {successMessage}
          </div>
        )}
        
        {errorMessage && (
          <div className="fixed bottom-4 right-4 bg-red-50 text-red-800 rounded-lg p-4 shadow-lg flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-400 mr-2" />
            {errorMessage}
          </div>
        )}
      </div>
    </div>
  );
};

export default BackupSettings;