import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft, Edit, Trash2, MessageSquare, User, Calendar,
  Clock, AlertTriangle, CheckCircle, Send, PaperclipIcon,
  Download, Eye, Laptop, RefreshCw, AlertCircle
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { Ticket, TicketMessage } from '../../../types';
import { v4 as uuidv4 } from 'uuid';

const TicketDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { state, updateTicket, deleteTicket } = useData();
  const navigate = useNavigate();
  
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [newMessage, setNewMessage] = useState('');
  const [isInternalMessage, setIsInternalMessage] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Load ticket data
  useEffect(() => {
    if (!state.isLoading && id) {
      const foundTicket = state.tickets.find(t => t.id === id);
      if (foundTicket) {
        setTicket(foundTicket);
      } else {
        navigate('/admin/tickets');
      }
    }
  }, [id, state.isLoading, state.tickets, navigate]);
  
  const confirmDelete = async () => {
    if (!id) return;
    
    setIsDeleting(true);
    try {
      await deleteTicket(id);
      navigate('/admin/tickets');
    } catch (error) {
      console.error('Error deleting ticket:', error);
      setIsDeleting(false);
      setIsDeleteModalOpen(false);
    }
  };
  
  const handleAddMessage = async () => {
    if (!ticket || !newMessage.trim()) return;
    
    setIsSubmitting(true);
    
    try {
      const message: TicketMessage = {
        id: uuidv4(),
        ticketId: ticket.id,
        message: newMessage.trim(),
        createdBy: '1', // Admin ID
        createdAt: new Date().toISOString(),
        isInternal: isInternalMessage,
        attachments: []
      };
      
      const updatedTicket: Ticket = {
        ...ticket,
        messages: [...ticket.messages, message],
        updatedAt: new Date().toISOString()
      };
      
      await updateTicket(updatedTicket);
      setTicket(updatedTicket);
      setNewMessage('');
      setIsInternalMessage(false);
      setSelectedFiles(null);
    } catch (error) {
      console.error('Error adding message:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleStatusChange = async (newStatus: Ticket['status']) => {
    if (!ticket) return;
    
    try {
      const updatedTicket: Ticket = {
        ...ticket,
        status: newStatus,
        updatedAt: new Date().toISOString()
      };
      
      if (newStatus === 'resolved') {
        updatedTicket.resolvedAt = new Date().toISOString();
      }
      
      await updateTicket(updatedTicket);
      setTicket(updatedTicket);
    } catch (error) {
      console.error('Error updating ticket status:', error);
    }
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-yellow-100 text-yellow-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'waiting':
        return 'bg-purple-100 text-purple-800';
      case 'resolved':
        return 'bg-green-100 text-green-800';
      case 'closed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'open':
        return 'Aperto';
      case 'in-progress':
        return 'In Corso';
      case 'waiting':
        return 'In Attesa';
      case 'resolved':
        return 'Risolto';
      case 'closed':
        return 'Chiuso';
      default:
        return status;
    }
  };
  
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'low':
        return 'bg-blue-100 text-blue-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'critical':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'low':
        return 'Bassa';
      case 'medium':
        return 'Media';
      case 'high':
        return 'Alta';
      case 'critical':
        return 'Critica';
      default:
        return priority;
    }
  };
  
  if (state.isLoading || !ticket) {
    return (
      <div className="page-container flex items-center justify-center h-full">
        <LoadingSpinner size="lg" text="Caricamento dettagli ticket..." />
      </div>
    );
  }
  
  const client = state.clients.find(c => c.id === ticket.clientId);
  const device = ticket.deviceId ? client?.devices?.find(d => d.id === ticket.deviceId) : null;
  
  return (
    <div className="page-container">
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center">
          <button
            onClick={() => navigate('/admin/tickets')}
            className="mr-4 p-2 rounded-full hover:bg-gray-100"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </button>
          
          <div>
            <h1 className="page-title mb-1 flex items-center">
              {ticket.title}
              <span className={`ml-3 px-2 py-1 text-xs rounded-full ${getStatusColor(ticket.status)}`}>
                {getStatusLabel(ticket.status)}
              </span>
              <span className={`ml-2 px-2 py-1 text-xs rounded-full ${getPriorityColor(ticket.priority)}`}>
                {getPriorityLabel(ticket.priority)}
              </span>
            </h1>
            <p className="text-gray-600">Ticket #{ticket.ticketNumber}</p>
          </div>
        </div>
        
        <div className="mt-4 sm:mt-0 flex space-x-2">
          <button
            onClick={() => navigate(`/admin/tickets/${id}/edit`)}
            className="btn bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500 flex items-center"
          >
            <Edit className="h-5 w-5 mr-1" />
            Modifica
          </button>
          
          <button
            onClick={() => setIsDeleteModalOpen(true)}
            className="btn btn-danger flex items-center"
          >
            <Trash2 className="h-5 w-5 mr-1" />
            Elimina
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Ticket Description */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="px-6 py-4 bg-primary-700 text-white">
              <h2 className="text-lg font-medium">Descrizione</h2>
            </div>
            <div className="p-6">
              <p className="text-gray-700 whitespace-pre-wrap">{ticket.description}</p>
            </div>
          </div>
          
          {/* Messages */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="px-6 py-4 bg-blue-700 text-white">
              <h2 className="text-lg font-medium">Messaggi e Aggiornamenti</h2>
            </div>
            
            <div className="p-6">
              <div className="space-y-4 mb-6">
                {ticket.messages.map((message) => (
                  <div 
                    key={message.id} 
                    className={`p-4 rounded-lg ${
                      message.isInternal 
                        ? 'bg-yellow-50 border border-yellow-200' 
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        <div className={`p-2 rounded-full ${
                          message.isInternal 
                            ? 'bg-yellow-100 text-yellow-700' 
                            : 'bg-gray-200 text-gray-700'
                        }`}>
                          <MessageSquare className="h-4 w-4" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">
                            {message.isInternal ? 'Nota Interna' : 'Messaggio'}
                          </p>
                          <p className="text-xs text-gray-500">
                            {format(new Date(message.createdAt), 'dd/MM/yyyy HH:mm')}
                          </p>
                        </div>
                      </div>
                      
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="flex items-center space-x-2">
                          {message.attachments.map((attachment, index) => (
                            <a
                              key={index}
                              href={attachment}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1 hover:bg-gray-200 rounded"
                              title="Scarica allegato"
                            >
                              <Download className="h-4 w-4 text-gray-500" />
                            </a>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <div className="mt-2 text-sm text-gray-700">
                      {message.message}
                    </div>
                  </div>
                ))}
              </div>
              
              {/* New Message Form */}
              <div className="border-t border-gray-200 pt-4">
                <div className="mb-4">
                  <label htmlFor="newMessage" className="form-label">
                    Nuovo Messaggio
                  </label>
                  <textarea
                    id="newMessage"
                    rows={3}
                    className="input"
                    placeholder="Scrivi un nuovo messaggio..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isInternal"
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                        checked={isInternalMessage}
                        onChange={(e) => setIsInternalMessage(e.target.checked)}
                      />
                      <label htmlFor="isInternal" className="ml-2 block text-sm text-gray-900">
                        Nota interna
                      </label>
                    </div>
                    
                    <div>
                      <input
                        type="file"
                        id="attachments"
                        className="sr-only"
                        multiple
                        onChange={(e) => setSelectedFiles(e.target.files)}
                      />
                      <label
                        htmlFor="attachments"
                        className="cursor-pointer inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                      >
                        <PaperclipIcon className="h-4 w-4 mr-2" />
                        Allega file
                      </label>
                    </div>
                  </div>
                  
                  <button
                    type="button"
                    onClick={handleAddMessage}
                    disabled={!newMessage.trim() || isSubmitting}
                    className="btn btn-primary"
                  >
                    {isSubmitting ? (
                      <LoadingSpinner size="sm" color="white" />
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Invia
                      </>
                    )}
                  </button>
                </div>
                
                {selectedFiles && selectedFiles.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm text-gray-500">
                      {selectedFiles.length} file selezionati
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Status Card */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Stato Ticket</h2>
            </div>
            
            <div className="p-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">Stato Attuale</label>
                  <select
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                    value={ticket.status}
                    onChange={(e) => handleStatusChange(e.target.value as Ticket['status'])}
                  >
                    <option value="open">Aperto</option>
                    <option value="in-progress">In Corso</option>
                    <option value="waiting">In Attesa</option>
                    <option value="resolved">Risolto</option>
                    <option value="closed">Chiuso</option>
                  </select>
                </div>
                
                <div className="pt-4 border-t border-gray-200">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Data Apertura</span>
                    <span className="font-medium">
                      {format(new Date(ticket.createdAt), 'dd/MM/yyyy HH:mm')}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm mt-2">
                    <span className="text-gray-500">Ultimo Aggiornamento</span>
                    <span className="font-medium">
                      {format(new Date(ticket.updatedAt), 'dd/MM/yyyy HH:mm')}
                    </span>
                  </div>
                  
                  {ticket.resolvedAt && (
                    <div className="flex items-center justify-between text-sm mt-2">
                      <span className="text-gray-500">Data Risoluzione</span>
                      <span className="font-medium">
                        {format(new Date(ticket.resolvedAt), 'dd/MM/yyyy HH:mm')}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Client Info Card */}
          {client && (
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-900">Informazioni Cliente</h2>
              </div>
              
              <div className="p-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Cliente</label>
                    <p className="mt-1">
                      <a 
                        href={`/admin/clients/${client.id}`}
                        className="text-primary-600 hover:text-primary-900"
                      >
                        {client.name}
                      </a>
                    </p>
                    <p className="text-sm text-gray-500">{client.clientCode}</p>
                  </div>
                  
                  {device && (
                    <div className="pt-4 border-t border-gray-200">
                      <label className="text-sm font-medium text-gray-700">Dispositivo</label>
                      <p className="mt-1">{device.name}</p>
                      <p className="text-sm text-gray-500">
                        {device.brand} {device.model}
                      </p>
                      <p className="text-xs text-gray-500">
                        S/N: {device.serialNumber}
                      </p>
                    </div>
                  )}
                  
                  <div className="pt-4 border-t border-gray-200">
                    <button
                      onClick={() => navigate(`/admin/clients/${client.id}`)}
                      className="w-full btn btn-secondary text-sm"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Visualizza Cliente
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="px-4 py-3 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">Conferma eliminazione</h3>
            </div>
            
            <div className="p-4">
              <div className="bg-red-50 p-4 rounded-md mb-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <AlertTriangle className="h-5 w-5 text-red-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">
                      Attenzione: Questa azione è irreversibile
                    </h3>
                  </div>
                </div>
              </div>
              
              <p className="text-gray-700">
                Sei sicuro di voler eliminare questo ticket?
              </p>
              <p className="text-sm text-gray-500 mt-2">
                Tutti i dati associati a questo ticket, inclusi messaggi e allegati, verranno eliminati permanentemente.
              </p>
            </div>
            
            <div className="px-4 py-3 bg-gray-50 flex justify-end space-x-2 rounded-b-lg">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setIsDeleteModalOpen(false)}
              >
                Annulla
              </button>
              <button
                type="button"
                className="btn btn-danger flex items-center"
                onClick={confirmDelete}
                disabled={isDeleting}
              >
                {isDeleting ? (
                  <LoadingSpinner size="sm" color="white" />
                ) : (
                  <>
                    <Trash2 className="h-4 w-4 mr-1" />
                    Elimina
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TicketDetail;