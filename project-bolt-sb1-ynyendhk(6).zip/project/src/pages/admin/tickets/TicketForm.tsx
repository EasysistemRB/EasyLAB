import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Save, X, AlertTriangle, CheckCircle, User, MessageSquare,
  AlertCircle, Clock, Calendar, Laptop, Send, PaperclipIcon,
  Eye, Download, Trash2, Building, Mail, Phone, MapPin, Globe,
  FileText, Info, Shield, CreditCard, Key, Lock, Database,
  Smartphone, Network, Wifi, Cpu, Wrench, PenTool as Tool,
  Settings, Activity, Zap, Bell
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { Ticket, TicketMessage } from '../../../types';
import { v4 as uuidv4 } from 'uuid';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import HelpPostIt from '../../../components/HelpPostIt';

const TicketForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const isEditMode = !!id;
  
  const { state, addTicket, updateTicket } = useData();
  const navigate = useNavigate();
  
  // Form States
  const [formData, setFormData] = useState<Partial<Ticket>>({
    title: '',
    description: '',
    priority: 'medium',
    status: 'open',
    clientId: '',
    deviceId: '',
    messages: [],
  });
  
  const [newMessage, setNewMessage] = useState('');
  const [isInternalMessage, setIsInternalMessage] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  // Load ticket data if editing
  useEffect(() => {
    if (isEditMode && id) {
      const ticket = state.tickets.find(t => t.id === id);
      if (ticket) {
        setFormData(ticket);
      }
    }
  }, [isEditMode, id, state.tickets]);
  
  // Get available devices for selected client
  const clientDevices = formData.clientId ? 
    state.clients.find(c => c.id === formData.clientId)?.devices || [] : 
    [];
  
  // Handle form field changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when field is changed
    if (formErrors[name]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  
  // Handle client change
  const handleClientChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const clientId = e.target.value;
    setFormData(prev => ({
      ...prev,
      clientId,
      deviceId: '' // Reset device when client changes
    }));
  };
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedFiles(e.target.files);
  };
  
  // Form validation
  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      errors.title = "Il titolo è obbligatorio";
    }
    
    if (!formData.description?.trim()) {
      errors.description = "La descrizione è obbligatoria";
    }
    
    if (!formData.clientId) {
      errors.clientId = "Seleziona un cliente";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      if (isEditMode && id) {
        // Update existing ticket
        await updateTicket(formData as Ticket);
        setSuccessMessage("Ticket aggiornato con successo");
      } else {
        // Add new ticket
        const newTicket = await addTicket({
          ...formData,
          priority: formData.priority || 'medium',
          status: 'open',
          createdBy: '1', // Admin ID
        });
        setSuccessMessage("Ticket creato con successo");
      }
      
      // Navigate back after a short delay
      setTimeout(() => {
        navigate('/admin/tickets');
      }, 1500);
    } catch (error) {
      console.error("Error saving ticket:", error);
      setFormErrors({ submit: "Si è verificato un errore durante il salvataggio. Riprova." });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Handle adding a new message
  const handleAddMessage = () => {
    if (!newMessage.trim()) return;
    
    const message: TicketMessage = {
      id: uuidv4(),
      ticketId: id || '',
      message: newMessage.trim(),
      createdBy: '1', // Admin ID
      createdAt: new Date().toISOString(),
      isInternal: isInternalMessage,
      attachments: []
    };
    
    setFormData(prev => ({
      ...prev,
      messages: [...(prev.messages || []), message],
      updatedAt: new Date().toISOString()
    }));
    
    setNewMessage('');
    setIsInternalMessage(false);
    setSelectedFiles(null);
  };
  
  if (state.isLoading) {
    return (
      <div className="page-container flex items-center justify-center h-full">
        <LoadingSpinner size="lg" text="Caricamento..." />
      </div>
    );
  }
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center">
          <div className="flex-shrink-0 bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg p-4 mr-4">
            <MessageSquare className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {isEditMode ? 'Modifica Ticket' : 'Nuovo Ticket'}
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              {isEditMode 
                ? 'Modifica i dettagli del ticket esistente' 
                : 'Crea un nuovo ticket di assistenza'
              }
            </p>
          </div>
        </div>
      </div>
      
      {successMessage && (
        <div className="mb-6 bg-green-50 border-l-4 border-green-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <CheckCircle className="h-5 w-5 text-green-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-700">{successMessage}</p>
            </div>
          </div>
        </div>
      )}
      
      {formErrors.submit && (
        <div className="mb-6 bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{formErrors.submit}</p>
            </div>
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        {/* Client Selection */}
        <div className="macos-window mb-6">
          <div className="macos-window-header">
            <h2 className="text-lg font-medium flex items-center">
              <User className="h-5 w-5 mr-2" />
              Selezione Cliente
            </h2>
          </div>
          
          <div className="macos-window-content">
            <HelpPostIt
              title="Suggerimento"
              content="Seleziona prima il cliente per visualizzare i suoi dispositivi. Puoi anche creare un ticket senza associare un dispositivo specifico."
              color="blue"
              icon={<Info className="h-5 w-5" />}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <div>
                <label htmlFor="clientId" className="form-label">
                  Cliente <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Building className="h-5 w-5 text-gray-400" />
                  </div>
                  <select
                    id="clientId"
                    name="clientId"
                    className={`macos-input pl-10 ${formErrors.clientId ? 'border-red-300' : ''}`}
                    value={formData.clientId || ''}
                    onChange={handleClientChange}
                    required
                  >
                    <option value="">Seleziona un cliente</option>
                    {state.clients.map(client => (
                      <option key={client.id} value={client.id}>
                        {client.name} ({client.clientCode})
                      </option>
                    ))}
                  </select>
                </div>
                {formErrors.clientId && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.clientId}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="deviceId" className="form-label">
                  Dispositivo
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Laptop className="h-5 w-5 text-gray-400" />
                  </div>
                  <select
                    id="deviceId"
                    name="deviceId"
                    className="macos-input pl-10"
                    value={formData.deviceId || ''}
                    onChange={handleInputChange}
                    disabled={!formData.clientId || clientDevices.length === 0}
                  >
                    <option value="">Seleziona un dispositivo</option>
                    {clientDevices.map(device => (
                      <option key={device.id} value={device.id}>
                        {device.name} ({device.brand} {device.model})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Ticket Details */}
        <div className="macos-window mb-6">
          <div className="macos-window-header">
            <h2 className="text-lg font-medium flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Dettagli Ticket
            </h2>
          </div>
          
          <div className="macos-window-content">
            <HelpPostIt
              title="Suggerimento"
              content="Fornisci una descrizione dettagliata del problema. Più informazioni fornisci, più velocemente potremo aiutarti a risolverlo."
              color="yellow"
              icon={<Info className="h-5 w-5" />}
            />
            
            <div className="space-y-6 mt-6">
              <div>
                <label htmlFor="title" className="form-label">
                  Titolo <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MessageSquare className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    className={`macos-input pl-10 ${formErrors.title ? 'border-red-300' : ''}`}
                    placeholder="Descrizione breve del problema"
                    value={formData.title || ''}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                {formErrors.title && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.title}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="description" className="form-label">
                  Descrizione <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <textarea
                    id="description"
                    name="description"
                    rows={4}
                    className={`macos-input ${formErrors.description ? 'border-red-300' : ''}`}
                    placeholder="Descrizione dettagliata del problema..."
                    value={formData.description || ''}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                {formErrors.description && (
                  <p className="mt-1 text-sm text-red-600">{formErrors.description}</p>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="priority" className="form-label">Priorità</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Zap className="h-5 w-5 text-gray-400" />
                    </div>
                    <select
                      id="priority"
                      name="priority"
                      className="macos-input pl-10"
                      value={formData.priority || 'medium'}
                      onChange={handleInputChange}
                    >
                      <option value="low">Bassa</option>
                      <option value="medium">Media</option>
                      <option value="high">Alta</option>
                      <option value="critical">Critica</option>
                    </select>
                  </div>
                </div>
                
                {isEditMode && (
                  <div>
                    <label htmlFor="status" className="form-label">Stato</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Activity className="h-5 w-5 text-gray-400" />
                      </div>
                      <select
                        id="status"
                        name="status"
                        className="macos-input pl-10"
                        value={formData.status || 'open'}
                        onChange={handleInputChange}
                      >
                        <option value="open">Aperto</option>
                        <option value="in-progress">In Corso</option>
                        <option value="waiting">In Attesa</option>
                        <option value="resolved">Risolto</option>
                        <option value="closed">Chiuso</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Messages Section */}
        {isEditMode && (
          <div className="macos-window mb-6">
            <div className="macos-window-header">
              <h2 className="text-lg font-medium flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                Messaggi e Aggiornamenti
              </h2>
            </div>
            
            <div className="macos-window-content">
              <HelpPostIt
                title="Suggerimento"
                content="Usa le note interne per comunicazioni riservate al team. I messaggi normali saranno visibili anche al cliente."
                color="green"
                icon={<Info className="h-5 w-5" />}
              />
              
              {/* Messages List */}
              <div className="mt-6 space-y-4">
                {formData.messages?.map((message) => (
                  <div 
                    key={message.id} 
                    className={`p-4 rounded-lg ${
                      message.isInternal 
                        ? 'bg-yellow-50 border border-yellow-200' 
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        <div className={`p-2 rounded-full ${
                          message.isInternal 
                            ? 'bg-yellow-100 text-yellow-700' 
                            : 'bg-gray-200 text-gray-700'
                        }`}>
                          <MessageSquare className="h-4 w-4" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">
                            {message.isInternal ? 'Nota Interna' : 'Messaggio'}
                          </p>
                          <p className="text-xs text-gray-500">
                            {format(new Date(message.createdAt), 'dd/MM/yyyy HH:mm')}
                          </p>
                        </div>
                      </div>
                      
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="flex items-center space-x-2">
                          {message.attachments.map((attachment, index) => (
                            <a
                              key={index}
                              href={attachment}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1 hover:bg-gray-200 rounded"
                              title="Scarica allegato"
                            >
                              <Download className="h-4 w-4 text-gray-500" />
                            </a>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <div className="mt-2 text-sm text-gray-700">
                      {message.message}
                    </div>
                  </div>
                ))}
              </div>
              
              {/* New Message Form */}
              <div className="mt-6 border-t border-gray-200 pt-6">
                <div className="mb-4">
                  <label htmlFor="newMessage" className="form-label">
                    Nuovo Messaggio
                  </label>
                  <textarea
                    id="newMessage"
                    rows={3}
                    className="macos-input"
                    placeholder="Scrivi un nuovo messaggio..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isInternal"
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                        checked={isInternalMessage}
                        onChange={(e) => setIsInternalMessage(e.target.checked)}
                      />
                      <label htmlFor="isInternal" className="ml-2 block text-sm text-gray-900">
                        Nota interna
                      </label>
                    </div>
                    
                    <div>
                      <input
                        type="file"
                        id="attachments"
                        className="sr-only"
                        multiple
                        onChange={handleFileChange}
                      />
                      <label
                        htmlFor="attachments"
                        className="cursor-pointer inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                      >
                        <PaperclipIcon className="h-4 w-4 mr-2" />
                        Allega file
                      </label>
                    </div>
                  </div>
                  
                  <button
                    type="button"
                    onClick={handleAddMessage}
                    disabled={!newMessage.trim()}
                    className="macos-button-primary"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Invia
                  </button>
                </div>
                
                {selectedFiles && selectedFiles.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm text-gray-500">
                      {selectedFiles.length} file selezionati
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Form Actions */}
        <div className="flex justify-between">
          <button
            type="button"
            onClick={() => navigate('/admin/tickets')}
            className="macos-button flex items-center"
          >
            <X className="h-5 w-5 mr-1" />
            Annulla
          </button>
          
          <button
            type="submit"
            className="macos-button-primary flex items-center"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <LoadingSpinner size="sm" color="white" />
            ) : (
              <>
                <Save className="h-5 w-5 mr-1" />
                {isEditMode ? 'Aggiorna Ticket' : 'Crea Ticket'}
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default TicketForm;