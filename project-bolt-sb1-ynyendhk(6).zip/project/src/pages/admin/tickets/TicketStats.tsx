import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart2, PieChart, Calendar, Clock, CheckCircle, 
  XCircle, AlertTriangle, ArrowUpRight, ArrowDownRight,
  TrendingUp, User, MessageSquare, Activity, RefreshCw,
  AlertCircle, Server, Cpu, Network, Wifi, Cloud, Monitor, 
  Headphones, Mouse, Keyboard, Terminal, Package, Coffee, 
  Layers, Folder, FileSearch, Trash2, RotateCw, Archive, 
  Box, Briefcase, ChevronRight, ChevronDown, ChevronUp, 
  Database, MemoryStick as Memory, Disc, Gauge, Thermometer, 
  Wind, Waves, Droplet, Percent, TrendingDown, Maximize2, 
  Minimize2, BarChart, LineChart, Hexagon, Circle, Square, 
  Triangle, Octagon, Star, Repeat, Power, Loader, Slash, 
  XOctagon, ShieldOff, WifiOff, CloudOff, ServerOff, 
  HardDrive, Settings, FileText, Save, Link, Key, LogOut, 
  Upload, Download, Shield, Code, GitBranch, GitMerge, 
  GitPullRequest, PenTool as Tool, CheckSquare, Info, Lock, 
  Unlock, CloudDrizzle, CloudLightning, CloudRain, CloudSnow, 
  CloudOff as CloudX, Smartphone, Tablet, Laptop, LampDesk as 
  Desktop, Printer, Wifi as WifiIcon, Database as DatabaseIcon, 
  Server as ServerIcon, Cloud as CloudIcon, HardDrive as 
  StorageIcon, Globe, X, ChevronLeft
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { format, isAfter, isBefore, parseISO, startOfMonth, endOfMonth, addMonths, subMonths } from 'date-fns';
import { it } from 'date-fns/locale';

const TicketStats: React.FC = () => {
  const { state } = useData();
  const navigate = useNavigate();
  
  const [currentPeriod, setCurrentPeriod] = useState<Date>(new Date());
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'month' | 'year'>('month');
  const [realtimeStats, setRealtimeStats] = useState({
    cpuUsage: 45,
    memoryUsage: 30,
    storageUsage: 65,
    networkLatency: 45
  });

  // Update realtime stats periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setRealtimeStats(prev => ({
        cpuUsage: Math.min(100, Math.max(0, prev.cpuUsage + (Math.random() * 10 - 5))),
        memoryUsage: Math.min(100, Math.max(0, prev.memoryUsage + (Math.random() * 8 - 4))),
        storageUsage: Math.min(100, Math.max(0, prev.storageUsage + (Math.random() * 2 - 1))),
        networkLatency: Math.min(200, Math.max(10, prev.networkLatency + (Math.random() * 20 - 10)))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Get period dates
  const getPeriodDates = useMemo(() => {
    if (viewMode === 'month') {
      const start = startOfMonth(currentPeriod);
      const end = endOfMonth(currentPeriod);
      return { start, end };
    } else {
      // Year
      const start = new Date(currentPeriod.getFullYear(), 0, 1);
      const end = new Date(currentPeriod.getFullYear(), 11, 31);
      return { start, end };
    }
  }, [currentPeriod, viewMode]);
  
  // Simulate a refresh
  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };
  
  // Get tickets in current period
  const ticketsInPeriod = useMemo(() => {
    return state.tickets.filter(ticket => {
      try {
        const ticketDate = parseISO(ticket.createdAt);
        return isAfter(ticketDate, getPeriodDates.start) && 
               isBefore(ticketDate, getPeriodDates.end);
      } catch (error) {
        return false;
      }
    });
  }, [state.tickets, getPeriodDates]);
  
  // Calculate statistics
  const statistics = useMemo(() => {
    const total = ticketsInPeriod.length;
    
    // Status counts
    const statusCounts = {
      open: ticketsInPeriod.filter(t => t.status === 'open').length,
      inProgress: ticketsInPeriod.filter(t => t.status === 'in-progress').length,
      waiting: ticketsInPeriod.filter(t => t.status === 'waiting').length,
      resolved: ticketsInPeriod.filter(t => t.status === 'resolved').length,
      closed: ticketsInPeriod.filter(t => t.status === 'closed').length
    };
    
    // Priority counts
    const priorityCounts = {
      low: ticketsInPeriod.filter(t => t.priority === 'low').length,
      medium: ticketsInPeriod.filter(t => t.priority === 'medium').length,
      high: ticketsInPeriod.filter(t => t.priority === 'high').length,
      critical: ticketsInPeriod.filter(t => t.priority === 'critical').length
    };
    
    // Resolution time
    const resolvedTickets = ticketsInPeriod.filter(t => t.resolvedAt);
    let averageResolutionTime = 0;
    if (resolvedTickets.length > 0) {
      const totalTime = resolvedTickets.reduce((acc, ticket) => {
        const created = new Date(ticket.createdAt).getTime();
        const resolved = new Date(ticket.resolvedAt!).getTime();
        return acc + (resolved - created);
      }, 0);
      averageResolutionTime = totalTime / resolvedTickets.length / (1000 * 60 * 60); // Convert to hours
    }
    
    // Response time (time to first response)
    let averageResponseTime = 0;
    const ticketsWithResponses = ticketsInPeriod.filter(t => t.messages.length > 0);
    if (ticketsWithResponses.length > 0) {
      const totalTime = ticketsWithResponses.reduce((acc, ticket) => {
        const created = new Date(ticket.createdAt).getTime();
        const firstResponse = new Date(ticket.messages[0].createdAt).getTime();
        return acc + (firstResponse - created);
      }, 0);
      averageResponseTime = totalTime / ticketsWithResponses.length / (1000 * 60); // Convert to minutes
    }
    
    // Client distribution
    const clientCounts: Record<string, number> = {};
    ticketsInPeriod.forEach(ticket => {
      clientCounts[ticket.clientId] = (clientCounts[ticket.clientId] || 0) + 1;
    });
    
    return {
      total,
      statusCounts,
      priorityCounts,
      averageResolutionTime,
      averageResponseTime,
      clientCounts
    };
  }, [ticketsInPeriod]);
  
  // Format for period title
  const periodTitle = useMemo(() => {
    if (viewMode === 'month') {
      return format(currentPeriod, 'MMMM yyyy', { locale: it });
    } else {
      return format(currentPeriod, 'yyyy');
    }
  }, [currentPeriod, viewMode]);
  
  // Navigation between periods
  const navigatePrevious = () => {
    if (viewMode === 'month') {
      setCurrentPeriod(subMonths(currentPeriod, 1));
    } else {
      setCurrentPeriod(new Date(currentPeriod.getFullYear() - 1, 0, 1));
    }
  };
  
  const navigateNext = () => {
    if (viewMode === 'month') {
      setCurrentPeriod(addMonths(currentPeriod, 1));
    } else {
      setCurrentPeriod(new Date(currentPeriod.getFullYear() + 1, 0, 1));
    }
  };
  
  if (state.isLoading) {
    return (
      <div className="page-container flex items-center justify-center h-full">
        <LoadingSpinner size="lg" text="Caricamento statistiche..." />
      </div>
    );
  }
  
  return (
    <div className="page-container">
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="page-title mb-1">Statistiche Ticket</h1>
          <p className="text-gray-600">Analisi e metriche dei ticket di assistenza</p>
        </div>
        
        <div className="mt-4 sm:mt-0 flex items-center space-x-3">
          <div className="p-1 bg-white/90 backdrop-blur-sm rounded-lg shadow-sm flex">
            <button
              onClick={() => setViewMode('month')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium ${
                viewMode === 'month' 
                  ? 'bg-primary-100 text-primary-800' 
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Mese
            </button>
            <button
              onClick={() => setViewMode('year')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium ${
                viewMode === 'year' 
                  ? 'bg-primary-100 text-primary-800' 
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Anno
            </button>
          </div>
          
          <button 
            onClick={handleRefresh}
            className="p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-sm text-gray-500 hover:bg-gray-50"
            disabled={refreshing}
          >
            <RefreshCw className={`h-5 w-5 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>
      
      {/* Period Navigation */}
      <div className="mb-6 macos-window">
        <div className="p-4 bg-primary-600 text-white flex justify-between items-center">
          <button
            onClick={navigatePrevious}
            className="p-1 rounded-full hover:bg-primary-500"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          
          <h2 className="text-xl font-bold capitalize">
            {periodTitle}
          </h2>
          
          <button
            onClick={navigateNext}
            className="p-1 rounded-full hover:bg-primary-500"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
        
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center p-4 macos-card">
            <div className="flex-shrink-0 p-3 rounded-full bg-primary-100 text-primary-600">
              <MessageSquare className="h-8 w-8" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Totale Ticket</h3>
              <div className="flex items-baseline">
                <p className="text-3xl font-bold text-primary-600">{statistics.total}</p>
                <span className="ml-2 text-sm text-gray-500">nel periodo selezionato</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center p-4 macos-card">
            <div className="flex-shrink-0 p-3 rounded-full bg-green-100 text-green-600">
              <Activity className="h-8 w-8" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Tasso di Risoluzione</h3>
              <div className="flex items-baseline">
                <p className="text-3xl font-bold text-green-600">
                  {statistics.total > 0 
                    ? Math.round((statistics.statusCounts.resolved / statistics.total) * 100) 
                    : 0}%
                </p>
                <span className="ml-2 text-sm text-gray-500">ticket risolti</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Status Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
        <div className="macos-card">
          <div className="flex items-center justify-between">
            <div className="p-2 rounded-full bg-yellow-100 text-yellow-700">
              <AlertCircle className="h-6 w-6" />
            </div>
            <span className="text-2xl font-semibold text-yellow-700">
              {statistics.statusCounts.open}
            </span>
          </div>
          <p className="mt-2 text-sm font-medium text-gray-600">Aperti</p>
          <div className="mt-2 h-1 bg-gray-200 rounded-full">
            <div 
              className="h-full bg-yellow-500 rounded-full"
              style={{ 
                width: `${statistics.total > 0 
                  ? (statistics.statusCounts.open / statistics.total) * 100 
                  : 0}%` 
              }}
            ></div>
          </div>
        </div>
        
        <div className="macos-card">
          <div className="flex items-center justify-between">
            <div className="p-2 rounded-full bg-blue-100 text-blue-700">
              <RefreshCw className="h-6 w-6" />
            </div>
            <span className="text-2xl font-semibold text-blue-700">
              {statistics.statusCounts.inProgress}
            </span>
          </div>
          <p className="mt-2 text-sm font-medium text-gray-600">In Corso</p>
          <div className="mt-2 h-1 bg-gray-200 rounded-full">
            <div 
              className="h-full bg-blue-500 rounded-full"
              style={{ 
                width: `${statistics.total > 0 
                  ? (statistics.statusCounts.inProgress / statistics.total) * 100 
                  : 0}%` 
              }}
            ></div>
          </div>
        </div>
        
        <div className="macos-card">
          <div className="flex items-center justify-between">
            <div className="p-2 rounded-full bg-purple-100 text-purple-700">
              <Clock className="h-6 w-6" />
            </div>
            <span className="text-2xl font-semibold text-purple-700">
              {statistics.statusCounts.waiting}
            </span>
          </div>
          <p className="mt-2 text-sm font-medium text-gray-600">In Attesa</p>
          <div className="mt-2 h-1 bg-gray-200 rounded-full">
            <div 
              className="h-full bg-purple-500 rounded-full"
              style={{ 
                width: `${statistics.total > 0 
                  ? (statistics.statusCounts.waiting / statistics.total) * 100 
                  : 0}%` 
              }}
            ></div>
          </div>
        </div>
        
        <div className="macos-card">
          <div className="flex items-center justify-between">
            <div className="p-2 rounded-full bg-green-100 text-green-700">
              <CheckCircle className="h-6 w-6" />
            </div>
            <span className="text-2xl font-semibold text-green-700">
              {statistics.statusCounts.resolved}
            </span>
          </div>
          <p className="mt-2 text-sm font-medium text-gray-600">Risolti</p>
          <div className="mt-2 h-1 bg-gray-200 rounded-full">
            <div 
              className="h-full bg-green-500 rounded-full"
              style={{ 
                width: `${statistics.total > 0 
                  ? (statistics.statusCounts.resolved / statistics.total) * 100 
                  : 0}%` 
              }}
            ></div>
          </div>
        </div>
        
        <div className="macos-card">
          <div className="flex items-center justify-between">
            <div className="p-2 rounded-full bg-gray-100 text-gray-700">
              <XCircle className="h-6 w-6" />
            </div>
            <span className="text-2xl font-semibold text-gray-700">
              {statistics.statusCounts.closed}
            </span>
          </div>
          <p className="mt-2 text-sm font-medium text-gray-600">Chiusi</p>
          <div className="mt-2 h-1 bg-gray-200 rounded-full">
            <div 
              className="h-full bg-gray-500 rounded-full"
              style={{ 
                width: `${statistics.total > 0 
                  ? (statistics.statusCounts.closed / statistics.total) * 100 
                  : 0}%` 
              }}
            ></div>
          </div>
        </div>
      </div>
      
      {/* Priority Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="macos-window">
          <div className="macos-window-header">
            <h3 className="font-semibold flex items-center">
              <PieChart className="mr-2 h-5 w-5" />
              Distribuzione per Priorità
            </h3>
          </div>
          
          <div className="macos-window-content">
            <div className="space-y-4">
              {/* Critical */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Critica</span>
                  <span className="text-sm font-medium text-red-600">
                    {statistics.priorityCounts.critical}
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-red-500 rounded-full"
                    style={{ 
                      width: `${statistics.total > 0 
                        ? (statistics.priorityCounts.critical / statistics.total) * 100 
                        : 0}%` 
                    }}
                  ></div>
                </div>
              </div>
              
              {/* High */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Alta</span>
                  <span className="text-sm font-medium text-orange-600">
                    {statistics.priorityCounts.high}
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-orange-500 rounded-full"
                    style={{ 
                      width: `${statistics.total > 0 
                        ? (statistics.priorityCounts.high / statistics.total) * 100 
                        : 0}%` 
                    }}
                  ></div>
                </div>
              </div>
              
              {/* Medium */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Media</span>
                  <span className="text-sm font-medium text-yellow-600">
                    {statistics.priorityCounts.medium}
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-yellow-500 rounded-full"
                    style={{ 
                      width: `${statistics.total > 0 
                        ? (statistics.priorityCounts.medium / statistics.total) * 100 
                        : 0}%` 
                    }}
                  ></div>
                </div>
              </div>
              
              {/* Low */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Bassa</span>
                  <span className="text-sm font-medium text-blue-600">
                    {statistics.priorityCounts.low}
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-blue-500 rounded-full"
                    style={{ 
                      width: `${statistics.total > 0 
                        ? (statistics.priorityCounts.low / statistics.total) * 100 
                        : 0}%` 
                    }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Response Times */}
        <div className="macos-window">
          <div className="macos-window-header">
            <h3 className="font-semibold flex items-center">
              <Clock className="mr-2 h-5 w-5" />
              Tempi di Risposta
            </h3>
          </div>
          
          <div className="macos-window-content">
            <div className="space-y-6">
              {/* Average Resolution Time */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">
                    Tempo Medio di Risoluzione
                  </span>
                  <span className="text-lg font-semibold text-green-600">
                    {statistics.averageResolutionTime.toFixed(1)} ore
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-green-500 rounded-full"
                    style={{ width: `${Math.min((statistics.averageResolutionTime / 48) * 100, 100)}%` }}
                  ></div>
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  Target: 48 ore
                </p>
              </div>
              
              {/* First Response Time */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">
                    Tempo Medio Prima Risposta
                  </span>
                  <span className="text-lg font-semibold text-blue-600">
                    {statistics.averageResponseTime.toFixed(0)} min
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${Math.min((statistics.averageResponseTime / 60) * 100, 100)}%` }}
                  ></div>
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  Target: 60 minuti
                </p>
              </div>
              
              {/* Client Distribution */}
              <div className="pt-4 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">
                  Distribuzione per Cliente
                </h4>
                {Object.entries(statistics.clientCounts)
                  .sort(([, a], [, b]) => b - a)
                  .slice(0, 5)
                  .map(([clientId, count]) => {
                    const client = state.clients.find(c => c.id === clientId);
                    return (
                      <div key={clientId} className="mb-2 last:mb-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-gray-600 truncate">
                            {client?.name || 'Cliente sconosciuto'}
                          </span>
                          <span className="text-sm font-medium">{count}</span>
                        </div>
                        <div className="w-full h-1.5 bg-gray-200 rounded-full">
                          <div 
                            className="h-full bg-primary-500 rounded-full"
                            style={{ 
                              width: `${(count / statistics.total) * 100}%` 
                            }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Performance Analysis */}
      <div className="macos-window">
        <div className="macos-window-header">
          <h3 className="font-semibold flex items-center">
            <TrendingUp className="mr-2 h-5 w-5" />
            Analisi delle Performance
          </h3>
        </div>
        
        <div className="macos-window-content">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Resolution Rate */}
            <div className="macos-card">
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-full bg-green-100 text-green-600">
                  <CheckCircle className="h-6 w-6" />
                </div>
                <span className="text-2xl font-bold text-green-600">
                  {statistics.total > 0 
                    ? Math.round((statistics.statusCounts.resolved / statistics.total) * 100) 
                    : 0}%
                </span>
              </div>
              <p className="mt-2 text-sm font-medium text-gray-600">
                Tasso di Risoluzione
              </p>
              <p className="text-xs text-gray-500">
                {statistics.statusCounts.resolved} ticket risolti su {statistics.total}
              </p>
            </div>
            
            {/* Average Response Time */}
            <div className="macos-card">
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-full bg-blue-100 text-blue-600">
                  <Clock className="h-6 w-6" />
                </div>
                <span className="text-2xl font-bold text-blue-600">
                  {Math.round(statistics.averageResponseTime)} min
                </span>
              </div>
              <p className="mt-2 text-sm font-medium text-gray-600">
                Tempo Medio di Risposta
              </p>
              <p className="text-xs text-gray-500">
                Target: 60 minuti
              </p>
            </div>
            
            {/* Critical Issues */}
            <div className="macos-card">
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-full bg-red-100 text-red-600">
                  <AlertTriangle className="h-6 w-6" />
                </div>
                <span className="text-2xl font-bold text-red-600">
                  {statistics.priorityCounts.critical}
                </span>
              </div>
              <p className="mt-2 text-sm font-medium text-gray-600">
                Problemi Critici
              </p>
              <p className="text-xs text-gray-500">
                {statistics.priorityCounts.critical > 0 ? 'Richiede attenzione immediata' : 'Nessun problema critico'}
              </p>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-gray-50/50 backdrop-blur-sm rounded-lg border border-gray-200/50">
            <h4 className="text-lg font-medium text-gray-800 mb-2">Analisi delle Performance</h4>
            <p className="text-gray-600 mb-4">
              {(() => {
                const resolutionRate = statistics.total > 0 
                  ? (statistics.statusCounts.resolved / statistics.total) * 100 
                  : 0;
                
                if (statistics.total === 0) {
                  return "Non ci sono sufficienti dati per questo periodo per generare un'analisi.";
                }
                
                if (resolutionRate > 70) {
                  return `Ottimo tasso di risoluzione (${Math.round(resolutionRate)}%). Le richieste di assistenza sono gestite con grande efficienza. Il tempo medio di risposta è di ${Math.round(statistics.averageResponseTime)} minuti, ${statistics.averageResponseTime <= 60 ? 'entro' : 'sopra'} il target di 60 minuti.`;
                } else if (resolutionRate > 50) {
                  return `Buon tasso di risoluzione (${Math.round(resolutionRate)}%). C'è ancora margine di miglioramento nella gestione dei ticket. Il tempo medio di risposta è di ${Math.round(statistics.averageResponseTime)} minuti.`;
                } else {
                  return `Tasso di risoluzione basso (${Math.round(resolutionRate)}%). È necessario migliorare l'efficienza nella gestione dei ticket. Il tempo medio di risposta è di ${Math.round(statistics.averageResponseTime)} minuti, significativamente ${statistics.averageResponseTime <= 60 ? 'entro' : 'sopra'} il target.`;
                }
              })()}
            </p>
            
            <div className="mt-4">
              <h5 className="text-sm font-medium text-gray-700 mb-2">Suggerimenti</h5>
              <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                <li>Prioritizza i ticket critici e ad alta priorità</li>
                <li>Monitora attivamente i ticket in attesa di risposta</li>
                <li>Mantieni aggiornati i clienti sullo stato dei loro ticket</li>
                <li>Documenta le soluzioni per problemi ricorrenti</li>
                <li>Analizza i pattern dei problemi per identificare aree di miglioramento</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TicketStats;