import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, Search, Filter, AlertTriangle, CheckCircle, 
  Clock, MessageSquare, User, Calendar, ChevronDown,
  ChevronUp, Edit, Eye, Trash2, RefreshCw, BarChart2,
  AlertCircle, Archive, TicketCheck, FileCheck, Store,
  Briefcase, UserCircle, Home, CreditCard, Globe, Database,
  MessageCircle, Shield, Info, Building, Mail, Phone,
  FileText, Download, Upload, Smartphone, Network, Wifi,
  Cpu, Wrench, PenTool as Tool, Settings, Activity, Zap,
  Bell, X
} from 'lucide-react';
import { useData } from '../../../context/DataContext';
import LoadingSpinner from '../../../components/LoadingSpinner';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

const TicketList: React.FC = () => {
  const { state } = useData();
  const navigate = useNavigate();
  
  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [clientFilter, setClientFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  
  // Table state
  const [sortField, setSortField] = useState<string>('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [filteredTickets, setFilteredTickets] = useState(state.tickets);
  
  // Apply filters and sorting
  useEffect(() => {
    if (state.isLoading) return;
    
    let filtered = [...state.tickets];
    
    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(ticket => 
        ticket.title.toLowerCase().includes(searchLower) || 
        ticket.description.toLowerCase().includes(searchLower) ||
        ticket.ticketNumber.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(ticket => ticket.status === statusFilter);
    }
    
    // Apply priority filter
    if (priorityFilter !== 'all') {
      filtered = filtered.filter(ticket => ticket.priority === priorityFilter);
    }
    
    // Apply client filter
    if (clientFilter !== 'all') {
      filtered = filtered.filter(ticket => ticket.clientId === clientFilter);
    }
    
    // Apply date filter
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    switch (dateFilter) {
      case 'today':
        filtered = filtered.filter(ticket => {
          const ticketDate = new Date(ticket.createdAt);
          ticketDate.setHours(0, 0, 0, 0);
          return ticketDate.getTime() === today.getTime();
        });
        break;
      case 'week':
        const weekAgo = new Date(today);
        weekAgo.setDate(weekAgo.getDate() - 7);
        filtered = filtered.filter(ticket => new Date(ticket.createdAt) >= weekAgo);
        break;
      case 'month':
        const monthAgo = new Date(today);
        monthAgo.setMonth(monthAgo.getMonth() - 1);
        filtered = filtered.filter(ticket => new Date(ticket.createdAt) >= monthAgo);
        break;
    }
    
    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortField) {
        case 'ticketNumber':
          comparison = a.ticketNumber.localeCompare(b.ticketNumber);
          break;
        case 'title':
          comparison = a.title.localeCompare(b.title);
          break;
        case 'client':
          const clientA = state.clients.find(c => c.id === a.clientId)?.name || '';
          const clientB = state.clients.find(c => c.id === b.clientId)?.name || '';
          comparison = clientA.localeCompare(clientB);
          break;
        case 'priority':
          const priorityOrder = { critical: 3, high: 2, medium: 1, low: 0 };
          comparison = (priorityOrder[a.priority] || 0) - (priorityOrder[b.priority] || 0);
          break;
        case 'status':
          comparison = a.status.localeCompare(b.status);
          break;
        case 'createdAt':
          comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          break;
        case 'updatedAt':
          comparison = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
          break;
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });
    
    setFilteredTickets(filtered);
  }, [
    state.isLoading,
    state.tickets,
    state.clients,
    search,
    statusFilter,
    priorityFilter,
    clientFilter,
    dateFilter,
    sortField,
    sortDirection
  ]);
  
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };
  
  const renderSortIcon = (field: string) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />;
  };
  
  const getStatusColor = (status: string, priority: string) => {
    if (priority === 'critical') {
      return 'bg-red-100 text-red-800 animate-pulse-scale';
    }
    
    switch (status) {
      case 'open':
        return 'bg-yellow-100 text-yellow-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'waiting':
        return 'bg-purple-100 text-purple-800';
      case 'resolved':
        return 'bg-green-100 text-green-800';
      case 'closed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'open':
        return 'Aperto';
      case 'in-progress':
        return 'In Corso';
      case 'waiting':
        return 'In Attesa';
      case 'resolved':
        return 'Risolto';
      case 'closed':
        return 'Chiuso';
      default:
        return status;
    }
  };
  
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'low':
        return 'bg-blue-100 text-blue-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'critical':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'low':
        return 'Bassa';
      case 'medium':
        return 'Media';
      case 'high':
        return 'Alta';
      case 'critical':
        return 'Critica';
      default:
        return priority;
    }
  };
  
  const getClientName = (clientId: string) => {
    const client = state.clients.find(c => c.id === clientId);
    return client ? client.name : 'Cliente sconosciuto';
  };
  
  // Get ticket statistics with percentages
  const getTicketStatistics = () => {
    const total = state.tickets.length;
    const open = state.tickets.filter(t => t.status === 'open').length;
    const inProgress = state.tickets.filter(t => t.status === 'in-progress').length;
    const waiting = state.tickets.filter(t => t.status === 'waiting').length;
    const resolved = state.tickets.filter(t => t.status === 'resolved').length;
    const closed = state.tickets.filter(t => t.status === 'closed').length;
    const critical = state.tickets.filter(t => t.priority === 'critical').length;
    
    // Calculate percentages
    const getPercentage = (value: number) => total > 0 ? Math.round((value / total) * 100) : 0;
    
    return {
      total,
      open: { count: open, percentage: getPercentage(open) },
      inProgress: { count: inProgress, percentage: getPercentage(inProgress) },
      waiting: { count: waiting, percentage: getPercentage(waiting) },
      resolved: { count: resolved, percentage: getPercentage(resolved) },
      closed: { count: closed, percentage: getPercentage(closed) },
      critical: { count: critical, percentage: getPercentage(critical) }
    };
  };
  
  const stats = getTicketStatistics();
  
  if (state.isLoading) {
    return (
      <div className="page-container flex items-center justify-center h-full">
        <LoadingSpinner size="lg" text="Caricamento ticket..." />
      </div>
    );
  }
  
  return (
    <div className="page-container">
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <TicketCheck className="h-8 w-8 mr-3 text-primary-600" />
            <span className="text-primary-600">Gestione ticket di assistenza</span>
          </h1>
          <p className="text-gray-600 mt-1">Monitora e gestisci tutte le richieste di assistenza</p>
        </div>
        
        <div className="mt-4 sm:mt-0 flex space-x-2">
          <button
            onClick={() => navigate('/admin/tickets/stats')}
            className="macos-button flex items-center bg-white/90 backdrop-blur-sm border border-gray-200/50 shadow-sm hover:bg-gray-50/90 transition-all duration-200"
          >
            <BarChart2 className="h-4 w-4 mr-2 text-primary-600" />
            <span>Statistiche</span>
          </button>
          
          <button
            onClick={() => navigate('/admin/tickets/new')}
            className="macos-button-primary flex items-center bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700 text-white shadow-sm transition-all duration-200 transform hover:scale-105"
          >
            <Plus className="h-4 w-4 mr-2" />
            <span>Nuovo Ticket</span>
          </button>
        </div>
      </div>
      
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-7 gap-4 mb-6">
        <div className="bg-white/80 backdrop-blur-lg rounded-lg shadow-lg border border-gray-200/50 flex p-4 items-center transform hover:scale-105 transition-all duration-300">
          <div className="rounded-full p-2 bg-gradient-to-br from-gray-100 to-gray-200 text-gray-600 mr-3">
            <MessageSquare className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Totali</p>
            <p className="text-xl font-semibold">{stats.total}</p>
          </div>
        </div>
        
        <div className="bg-yellow-50/80 backdrop-blur-lg rounded-lg shadow-lg border border-yellow-200/50 flex p-4 items-center transform hover:scale-105 transition-all duration-300">
          <div className="rounded-full p-2 bg-gradient-to-br from-yellow-100 to-yellow-200 text-yellow-600 mr-3">
            <AlertCircle className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-yellow-800">Aperti</p>
            <div className="flex items-baseline">
              <p className="text-xl font-semibold text-yellow-900">{stats.open.count}</p>
              <p className="ml-2 text-sm text-yellow-700">{stats.open.percentage}%</p>
            </div>
            <div className="w-full h-1 bg-yellow-200/50 rounded-full mt-1">
              <div 
                className="h-full bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full transition-all duration-300"
                style={{ width: `${stats.open.percentage}%` }}
              ></div>
            </div>
          </div>
        </div>
        
        <div className="bg-blue-50/80 backdrop-blur-lg rounded-lg shadow-lg border border-blue-200/50 flex p-4 items-center transform hover:scale-105 transition-all duration-300">
          <div className="rounded-full p-2 bg-gradient-to-br from-blue-100 to-blue-200 text-blue-600 mr-3">
            <RefreshCw className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-blue-800">In Corso</p>
            <div className="flex items-baseline">
              <p className="text-xl font-semibold text-blue-900">{stats.inProgress.count}</p>
              <p className="ml-2 text-sm text-blue-700">{stats.inProgress.percentage}%</p>
            </div>
            <div className="w-full h-1 bg-blue-200/50 rounded-full mt-1">
              <div 
                className="h-full bg-gradient-to-r from-blue-400 to-blue-500 rounded-full transition-all duration-300"
                style={{ width: `${stats.inProgress.percentage}%` }}
              ></div>
            </div>
          </div>
        </div>
        
        <div className="bg-purple-50/80 backdrop-blur-lg rounded-lg shadow-lg border border-purple-200/50 flex p-4 items-center transform hover:scale-105 transition-all duration-300">
          <div className="rounded-full p-2 bg-gradient-to-br from-purple-100 to-purple-200 text-purple-600 mr-3">
            <Clock className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-purple-800">In Attesa</p>
            <div className="flex items-baseline">
              <p className="text-xl font-semibold text-purple-900">{stats.waiting.count}</p>
              <p className="ml-2 text-sm text-purple-700">{stats.waiting.percentage}%</p>
            </div>
            <div className="w-full h-1 bg-purple-200/50 rounded-full mt-1">
              <div 
                className="h-full bg-gradient-to-r from-purple-400 to-purple-500 rounded-full transition-all duration-300"
                style={{ width: `${stats.waiting.percentage}%` }}
              ></div>
            </div>
          </div>
        </div>
        
        <div className="bg-green-50/80 backdrop-blur-lg rounded-lg shadow-lg border border-green-200/50 flex p-4 items-center transform hover:scale-105 transition-all duration-300">
          <div className="rounded-full p-2 bg-gradient-to-br from-green-100 to-green-200 text-green-600 mr-3">
            <CheckCircle className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-green-800">Risolti</p>
            <div className="flex items-baseline">
              <p className="text-xl font-semibold text-green-900">{stats.resolved.count}</p>
              <p className="ml-2 text-sm text-green-700">{stats.resolved.percentage}%</p>
            </div>
            <div className="w-full h-1 bg-green-200/50 rounded-full mt-1">
              <div 
                className="h-full bg-gradient-to-r from-green-400 to-green-500 rounded-full transition-all duration-300"
                style={{ width: `${stats.resolved.percentage}%` }}
              ></div>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50/80 backdrop-blur-lg rounded-lg shadow-lg border border-gray-200/50 flex p-4 items-center transform hover:scale-105 transition-all duration-300">
          <div className="rounded-full p-2 bg-gradient-to-br from-gray-100 to-gray-200 text-gray-600 mr-3">
            <Archive className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-gray-800">Chiusi</p>
            <div className="flex items-baseline">
              <p className="text-xl font-semibold text-gray-900">{stats.closed.count}</p>
              <p className="ml-2 text-sm text-gray-700">{stats.closed.percentage}%</p>
            </div>
            <div className="w-full h-1 bg-gray-200/50 rounded-full mt-1">
              <div 
                className="h-full bg-gradient-to-r from-gray-400 to-gray-500 rounded-full transition-all duration-300"
                style={{ width: `${stats.closed.percentage}%` }}
              ></div>
            </div>
          </div>
        </div>
        
        <div className="bg-red-50/80 backdrop-blur-lg rounded-lg shadow-lg border border-red-200/50 flex p-4 items-center transform hover:scale-105 transition-all duration-300">
          <div className="rounded-full p-2 bg-gradient-to-br from-red-100 to-red-200 text-red-600 mr-3">
            <AlertTriangle className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm text-red-800">Critici</p>
            <div className="flex items-baseline">
              <p className="text-xl font-semibold text-red-900">{stats.critical.count}</p>
              <p className="ml-2 text-sm text-red-700">{stats.critical.percentage}%</p>
            </div>
            <div className="w-full h-1 bg-red-200/50 rounded-full mt-1">
              <div 
                className="h-full bg-gradient-to-r from-red-400 to-red-500 rounded-full transition-all duration-300"
                style={{ width: `${stats.critical.percentage}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white/90 backdrop-blur-lg p-4 shadow-lg rounded-lg mb-6 border border-gray-200/50">
        <div className="flex flex-col md:flex-row md:items-center mb-4 space-y-3 md:space-y-0 md:space-x-4">
          <div className="flex-1">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="macos-input pl-10 w-full bg-white/50 backdrop-blur-sm border-gray-200/50 focus:border-primary-500 focus:ring focus:ring-primary-200"
                placeholder="Cerca ticket..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <select
              className="macos-input bg-white/50 backdrop-blur-sm border-gray-200/50 focus:border-primary-500 focus:ring focus:ring-primary-200"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">Tutti gli stati</option>
              <option value="open">Aperti</option>
              <option value="in-progress">In Corso</option>
              <option value="waiting">In Attesa</option>
              <option value="resolved">Risolti</option>
              <option value="closed">Chiusi</option>
            </select>
            
            <select
              className="macos-input bg-white/50 backdrop-blur-sm border-gray-200/50 focus:border-primary-500 focus:ring focus:ring-primary-200"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            >
              <option value="all">Tutte le priorità</option>
              <option value="low">Bassa</option>
              <option value="medium">Media</option>
              <option value="high">Alta</option>
              <option value="critical">Critica</option>
            </select>
            
            <select
              className="macos-input bg-white/50 backdrop-blur-sm border-gray-200/50 focus:border-primary-500 focus:ring focus:ring-primary-200"
              value={clientFilter}
              onChange={(e) => setClientFilter(e.target.value)}
            >
              <option value="all">Tutti i clienti</option>
              {state.clients.map((client) => (
                <option key={client.id} value={client.id}>
                  {client.name}
                </option>
              ))}
            </select>
            
            <select
              className="macos-input bg-white/50 backdrop-blur-sm border-gray-200/50 focus:border-primary-500 focus:ring focus:ring-primary-200"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value as any)}
            >
              <option value="all">Tutte le date</option>
              <option value="today">Oggi</option>
              <option value="week">Ultimi 7 giorni</option>
              <option value="month">Ultimo mese</option>
            </select>
          </div>
        </div>
        
        <div className="mt-2 text-sm text-gray-500">
          {filteredTickets.length} ticket trovati
        </div>
      </div>
      
      {/* Tickets Table */}
      <div className="bg-white/90 backdrop-blur-lg shadow-lg rounded-lg overflow-hidden border border-gray-200/50">
        {filteredTickets.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200/50">
              <thead className="bg-gray-50/50">
                <tr>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('ticketNumber')}
                  >
                    <div className="flex items-center">
                      Numero Ticket
                      {renderSortIcon('ticketNumber')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('title')}
                  >
                    <div className="flex items-center">
                      Titolo
                      {renderSortIcon('title')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('client')}
                  >
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-1" />
                      Cliente
                      {renderSortIcon('client')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('priority')}
                  >
                    <div className="flex items-center">
                      Priorità
                      {renderSortIcon('priority')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('status')}
                  >
                    <div className="flex items-center">
                      Stato
                      {renderSortIcon('status')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('createdAt')}
                  >
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Data Apertura
                      {renderSortIcon('createdAt')}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('updatedAt')}
                  >
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      Ultimo Aggiornamento
                      {renderSortIcon('updatedAt')}
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Azioni
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white/50 divide-y divide-gray-200/50">
                {filteredTickets.map((ticket) => (
                  <tr 
                    key={ticket.id} 
                    className={`hover:bg-gray-50/50 transition-colors duration-150 ${
                      ticket.priority === 'critical' ? 'bg-red-50/50' : ''
                    }`}
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {ticket.ticketNumber}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{ticket.title}</div>
                      <div className="text-sm text-gray-500 truncate max-w-xs">
                        {ticket.description}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {getClientName(ticket.clientId)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(ticket.priority)}`}>
                        {getPriorityLabel(ticket.priority)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {ticket.priority === 'critical' && (
                          <span className="w-2 h-2 bg-red-500 rounded-full mr-2 animate-pulse"></span>
                        )}
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          getStatusColor(ticket.status, ticket.priority)
                        }`}>
                          {getStatusLabel(ticket.status)}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(new Date(ticket.createdAt), 'dd/MM/yyyy HH:mm')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(new Date(ticket.updatedAt), 'dd/MM/yyyy HH:mm')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={() => navigate(`/admin/tickets/${ticket.id}`)}
                          className="macos-button-icon"
                          title="Visualizza dettagli"
                        >
                          <Eye className="h-4 w-4 text-primary-600 hover:text-primary-700" />
                        </button>
                        
                        <button
                          onClick={() => navigate(`/admin/tickets/${ticket.id}/edit`)}
                          className="macos-button-icon"
                          title="Modifica ticket"
                        >
                          <Edit className="h-4 w-4 text-blue-600 hover:text-blue-700" />
                        </button>
                        
                        <button
                          onClick={() => handleDelete(ticket.id)}
                          className="macos-button-icon"
                          title="Elimina ticket"
                        >
                          <Trash2 className="h-4 w-4 text-red-600 hover:text-red-700" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-6 text-center">
            <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 mb-4">Nessun ticket trovato con i filtri attuali.</p>
            <button
              onClick={() => {
                setSearch('');
                setStatusFilter('all');
                setPriorityFilter('all');
                setClientFilter('all');
                setDateFilter('all');
              }}
              className="macos-button text-primary-600 hover:text-primary-700"
            >
              Cancella tutti i filtri
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TicketList;