import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { TicketCheck, Calendar, CheckCircle, Bell, ExternalLink, QrCode, Mail, MessageSquare, FileText, Clock, Download, User, FileClock, Phone, Key, MapPin, ShieldCheck, Info, Asterisk as CashRegister, Printer, Laptop, Monitor, HardDrive, AlertTriangle, Settings, Database, Smartphone, Wifi, Cpu, Wrench, PenTool as Tool, RefreshCw, Globe, Building, Eye } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import LoadingSpinner from '../../components/LoadingSpinner';
import { QRCodeSVG } from 'qrcode.react';
import { Client, SharedFile } from '../../types';
import { format, addDays } from 'date-fns';
import { it } from 'date-fns/locale';
import SharedFilesManager from '../../components/SharedFilesManager';

const Dashboard: React.FC = () => {
  const { state: dataState } = useData();
  const { state: authState } = useAuth();
  const navigate = useNavigate();
  
  const [client, setClient] = useState<Client | null>(null);
  const [activeTab, setActiveTab] = useState<'info' | 'appointments' | 'tickets' | 'files'>('info');
  
  useEffect(() => {
    if (authState.user?.clientId && !dataState.isLoading) {
      const foundClient = dataState.clients.find(c => c.id === authState.user?.clientId);
      if (foundClient) {
        setClient(foundClient);
      }
    }
  }, [authState.user, dataState.clients, dataState.isLoading]);

  if (dataState.isLoading || !client) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 flex items-center justify-center">
        <LoadingSpinner size="lg" text="Caricamento..." color="white" />
      </div>
    );
  }

  // Client tickets
  const clientTickets = dataState.tickets.filter(ticket => ticket.clientId === client.id);
  const openTickets = clientTickets.filter(ticket => 
    ticket.status === 'open' || ticket.status === 'in-progress'
  ).length;
  
  // Client appointments
  const clientAppointments = dataState.appointments.filter(appointment => appointment.clientId === client.id);
  
  const todayAppointments = clientAppointments.filter(appointment => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const appointmentDate = new Date(appointment.date);
    appointmentDate.setHours(0, 0, 0, 0);
    return appointmentDate.getTime() === today.getTime();
  }).length;
  
  const upcomingAppointments = clientAppointments.filter(appointment => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const appointmentDate = new Date(appointment.date);
    appointmentDate.setHours(0, 0, 0, 0);
    return appointmentDate.getTime() > today.getTime();
  }).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Area Cliente</h1>
          <p className="text-gray-300">Benvenuto nell'area personale, {client.name}</p>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <nav className="flex space-x-4">
            <button
              onClick={() => setActiveTab('info')}
              className={`px-4 py-2 rounded-lg flex items-center ${
                activeTab === 'info'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              <User className="h-5 w-5 mr-2" />
              Informazioni
            </button>
            
            <button
              onClick={() => setActiveTab('appointments')}
              className={`px-4 py-2 rounded-lg flex items-center ${
                activeTab === 'appointments'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Calendar className="h-5 w-5 mr-2" />
              Appuntamenti
              {upcomingAppointments > 0 && (
                <span className="ml-2 bg-blue-500 text-white px-2 py-0.5 rounded-full text-xs">
                  {upcomingAppointments}
                </span>
              )}
            </button>
            
            <button
              onClick={() => setActiveTab('tickets')}
              className={`px-4 py-2 rounded-lg flex items-center ${
                activeTab === 'tickets'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              <TicketCheck className="h-5 w-5 mr-2" />
              Ticket
              {openTickets > 0 && (
                <span className="ml-2 bg-yellow-500 text-white px-2 py-0.5 rounded-full text-xs">
                  {openTickets}
                </span>
              )}
            </button>
            
            <button
              onClick={() => setActiveTab('files')}
              className={`px-4 py-2 rounded-lg flex items-center ${
                activeTab === 'files'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              <FileText className="h-5 w-5 mr-2" />
              File
              {client.sharedFiles && client.sharedFiles.length > 0 && (
                <span className="ml-2 bg-blue-500 text-white px-2 py-0.5 rounded-full text-xs">
                  {client.sharedFiles.length}
                </span>
              )}
            </button>
          </nav>
        </div>

        {/* Content Area */}
        <div className="space-y-8">
          {activeTab === 'info' && (
            <>
              {/* Client Info Card */}
              <div className="bg-white/10 backdrop-blur-lg rounded-xl shadow-xl overflow-hidden border border-white/20">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center">
                      <div className="h-16 w-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                        <span className="text-2xl font-bold text-white">{client.name.charAt(0)}</span>
                      </div>
                      <div className="ml-4">
                        <h2 className="text-xl font-bold text-white">{client.name}</h2>
                        <p className="text-gray-300">Codice: {client.clientCode}</p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button className="p-2 bg-blue-500/20 rounded-lg text-blue-300 hover:bg-blue-500/30">
                        <Settings className="h-5 w-5" />
                      </button>
                      <button className="p-2 bg-blue-500/20 rounded-lg text-blue-300 hover:bg-blue-500/30">
                        <Bell className="h-5 w-5" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      {client.email && (
                        <div className="flex items-center p-3 bg-white/5 rounded-lg">
                          <Mail className="h-5 w-5 text-blue-400" />
                          <div className="ml-3">
                            <p className="text-sm text-gray-400">Email</p>
                            <a href={`mailto:${client.email}`} className="text-white hover:text-blue-300">
                              {client.email}
                            </a>
                          </div>
                        </div>
                      )}

                      {client.phone && (
                        <div className="flex items-center p-3 bg-white/5 rounded-lg">
                          <Phone className="h-5 w-5 text-blue-400" />
                          <div className="ml-3">
                            <p className="text-sm text-gray-400">Telefono</p>
                            <a href={`tel:${client.phone}`} className="text-white hover:text-blue-300">
                              {client.phone}
                            </a>
                          </div>
                        </div>
                      )}

                      {client.address && (
                        <div className="flex items-start p-3 bg-white/5 rounded-lg">
                          <MapPin className="h-5 w-5 text-blue-400 mt-1" />
                          <div className="ml-3">
                            <p className="text-sm text-gray-400">Indirizzo</p>
                            <p className="text-white">
                              {client.address}
                              {client.city && <span className="block">{client.city}</span>}
                              {client.postalCode && <span>{client.postalCode}</span>}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4">
                      {client.vatNumber && (
                        <div className="flex items-center p-3 bg-white/5 rounded-lg">
                          <Building className="h-5 w-5 text-blue-400" />
                          <div className="ml-3">
                            <p className="text-sm text-gray-400">Partita IVA</p>
                            <p className="text-white font-mono">{client.vatNumber}</p>
                          </div>
                        </div>
                      )}

                      {client.fiscalCode && (
                        <div className="flex items-center p-3 bg-white/5 rounded-lg">
                          <Shield className="h-5 w-5 text-blue-400" />
                          <div className="ml-3">
                            <p className="text-sm text-gray-400">Codice Fiscale</p>
                            <p className="text-white font-mono">{client.fiscalCode}</p>
                          </div>
                        </div>
                      )}

                      {client.website && (
                        <div className="flex items-center p-3 bg-white/5 rounded-lg">
                          <Globe className="h-5 w-5 text-blue-400" />
                          <div className="ml-3">
                            <p className="text-sm text-gray-400">Sito Web</p>
                            <a 
                              href={client.website} 
                              target="_blank" 
                              rel="noopener noreferrer" 
                              className="text-white hover:text-blue-300 flex items-center"
                            >
                              {client.website}
                              <ExternalLink className="h-4 w-4 ml-1" />
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                  <div className="flex items-center justify-between">
                    <div className="p-3 bg-yellow-500/20 rounded-lg">
                      <TicketCheck className="h-6 w-6 text-yellow-500" />
                    </div>
                    <span className="text-2xl font-bold text-white">{openTickets}</span>
                  </div>
                  <p className="mt-2 text-gray-300">Ticket Aperti</p>
                </div>

                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                  <div className="flex items-center justify-between">
                    <div className="p-3 bg-green-500/20 rounded-lg">
                      <Calendar className="h-6 w-6 text-green-500" />
                    </div>
                    <span className="text-2xl font-bold text-white">{todayAppointments}</span>
                  </div>
                  <p className="mt-2 text-gray-300">Appuntamenti Oggi</p>
                </div>

                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                  <div className="flex items-center justify-between">
                    <div className="p-3 bg-blue-500/20 rounded-lg">
                      <Clock className="h-6 w-6 text-blue-500" />
                    </div>
                    <span className="text-2xl font-bold text-white">{upcomingAppointments}</span>
                  </div>
                  <p className="mt-2 text-gray-300">Prossimi Appuntamenti</p>
                </div>
              </div>

              {/* Devices Section */}
              <div className="bg-white/10 backdrop-blur-lg rounded-xl shadow-xl overflow-hidden border border-white/20">
                <div className="p-6">
                  <h2 className="text-xl font-bold text-white mb-6 flex items-center">
                    <Laptop className="h-6 w-6 mr-2 text-blue-400" />
                    Dispositivi Registrati
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {client.devices?.map((device) => {
                      // Get device icon based on type
                      const DeviceIcon = (() => {
                        switch (device.type) {
                          case 'cash_register':
                            return CashRegister;
                          case 'printer':
                            return Printer;
                          case 'laptop':
                            return Laptop;
                          case 'desktop':
                            return Monitor;
                          default:
                            return HardDrive;
                        }
                      })();

                      // Check verification status for cash registers
                      const verificationStatus = device.type === 'cash_register' && device.verificationDate ? (() => {
                        const verificationDate = new Date(device.verificationDate);
                        const expiryDate = addDays(verificationDate, 360);
                        const today = new Date();
                        const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                        
                        return {
                          isExpired: daysUntilExpiry <= 0,
                          daysRemaining: daysUntilExpiry,
                          expiryDate
                        };
                      })() : null;

                      return (
                        <div 
                          key={device.id}
                          className={`rounded-lg border ${
                            verificationStatus?.isExpired
                              ? 'bg-red-900/20 border-red-500/30'
                              : 'bg-white/5 border-white/10'
                          } p-4 backdrop-blur-lg`}
                        >
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center">
                              <div className={`p-2 rounded-lg ${
                                verificationStatus?.isExpired
                                  ? 'bg-red-500/20 text-red-400'
                                  : 'bg-blue-500/20 text-blue-400'
                              }`}>
                                <DeviceIcon className="h-6 w-6" />
                              </div>
                              <div className="ml-3">
                                <h3 className="text-white font-medium">{device.name}</h3>
                                <p className="text-gray-400 text-sm">
                                  {device.brand} {device.model}
                                </p>
                              </div>
                            </div>

                            {verificationStatus && (
                              <div className={`flex items-center ${
                                verificationStatus.isExpired
                                  ? 'text-red-400'
                                  : verificationStatus.daysRemaining <= 30
                                  ? 'text-yellow-400'
                                  : 'text-green-400'
                              }`}>
                                <div className={`h-2 w-2 rounded-full mr-2 ${
                                  verificationStatus.isExpired
                                    ? 'bg-red-400 animate-pulse'
                                    : verificationStatus.daysRemaining <= 30
                                    ? 'bg-yellow-400 animate-pulse'
                                    : 'bg-green-400'
                                }`}></div>
                                <span className="text-xs">
                                  {verificationStatus.isExpired
                                    ? 'Scaduto'
                                    : `${verificationStatus.daysRemaining}g`}
                                </span>
                              </div>
                            )}
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center text-gray-300 text-sm">
                              <Key className="h-4 w-4 mr-2 text-gray-400" />
                              S/N: {device.serialNumber}
                            </div>

                            {device.registrationNumber && (
                              <div className="flex items-center text-gray-300 text-sm">
                                <Database className="h-4 w-4 mr-2 text-gray-400" />
                                Reg: {device.registrationNumber}
                              </div>
                            )}

                            {device.type === 'cash_register' && device.verificationDate && (
                              <div className="flex items-center text-gray-300 text-sm">
                                <Clock className="h-4 w-4 mr-2 text-gray-400" />
                                Verifica: {format(new Date(device.verificationDate), 'dd/MM/yyyy')}
                              </div>
                            )}

                            {device.connectionType && (
                              <div className="flex items-center text-gray-300 text-sm">
                                <Wifi className="h-4 w-4 mr-2 text-gray-400" />
                                {device.connectionType.toUpperCase()}
                                {device.ipAddress && ` - ${device.ipAddress}`}
                                {device.port && `:${device.port}`}
                              </div>
                            )}
                          </div>

                          {verificationStatus?.isExpired && (
                            <div className="mt-4 p-3 bg-red-500/20 rounded-lg border border-red-500/30">
                              <div className="flex items-start">
                                <AlertTriangle className="h-5 w-5 text-red-400 mt-0.5" />
                                <div className="ml-2">
                                  <p className="text-red-300 text-sm">
                                    Verificazione periodica scaduta
                                  </p>
                                  <p className="text-red-400 text-xs mt-1">
                                    Contatta l'assistenza per rinnovare la verificazione
                                  </p>
                                </div>
                              </div>
                            </div>
                          )}

                          <div className="mt-4 flex justify-end space-x-2">
                            <button className="p-2 text-gray-400 hover:text-gray-300 rounded-lg hover:bg-white/5">
                              <Tool className="h-4 w-4" />
                            </button>
                            <button className="p-2 text-gray-400 hover:text-gray-300 rounded-lg hover:bg-white/5">
                              <Settings className="h-4 w-4" />
                            </button>
                            <button className="p-2 text-gray-400 hover:text-gray-300 rounded-lg hover:bg-white/5">
                              <Eye className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </>
          )}

          {activeTab === 'appointments' && (
            <div className="bg-white/10 backdrop-blur-lg rounded-xl shadow-xl overflow-hidden border border-white/20">
              {/* Appointments content */}
            </div>
          )}

          {activeTab === 'tickets' && (
            <div className="bg-white/10 backdrop-blur-lg rounded-xl shadow-xl overflow-hidden border border-white/20">
              {/* Tickets content */}
            </div>
          )}

          {activeTab === 'files' && (
            <div className="bg-white/10 backdrop-blur-lg rounded-xl shadow-xl overflow-hidden border border-white/20">
              <SharedFilesManager 
                client={client}
                isAdmin={false}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;