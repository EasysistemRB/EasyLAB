import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, ChevronLeft, Building, Mail, Phone, Globe, FileText, 
  AlertTriangle, Info, Scale, Lock, Key, UserCheck, Database,
  FileCheck, ShieldCheck, BookOpen, Server, HardDrive, Network,
  Bell, MessageSquare, Download, Upload, Smartphone
} from 'lucide-react';
import Logo from '../../components/Logo';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <Link to="/" className="flex items-center text-primary-600 hover:text-primary-700">
            <ChevronLeft className="h-5 w-5 mr-1" />
            <span>Torna alla Home</span>
          </Link>
          <Logo size="sm" withText={true} />
        </div>

        {/* Main Title */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Informazioni Legali</h1>
          <p className="text-lg text-gray-600">Termini, condizioni e informazioni sulla privacy di EasyLAB 25</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column */}
          <div className="space-y-8">
            {/* Privacy Policy Section */}
            <div className="bg-white shadow-lg rounded-2xl overflow-hidden">
              <div className="p-6 bg-gradient-to-r from-primary-600 to-primary-700 flex items-center">
                <Shield className="h-8 w-8 text-white mr-4" />
                <div>
                  <h2 className="text-2xl font-bold text-white">Privacy Policy</h2>
                  <p className="text-primary-100">Informativa sul trattamento dei dati personali</p>
                </div>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="flex items-start space-x-4">
                  <Lock className="h-6 w-6 text-primary-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Protezione dei Dati</h3>
                    <p className="text-gray-600">
                      La sicurezza dei tuoi dati è la nostra priorità. Utilizziamo tecnologie 
                      all'avanguardia e procedure rigorose per proteggere le tue informazioni.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Database className="h-6 w-6 text-primary-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Dati Raccolti</h3>
                    <ul className="list-disc pl-5 text-gray-600 space-y-2">
                      <li>Informazioni personali (nome, email, telefono)</li>
                      <li>Dati aziendali e fiscali</li>
                      <li>Informazioni sui dispositivi gestiti</li>
                      <li>Log di accesso e attività</li>
                    </ul>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <FileCheck className="h-6 w-6 text-primary-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Finalità del Trattamento</h3>
                    <ul className="list-disc pl-5 text-gray-600 space-y-2">
                      <li>Gestione e manutenzione del software</li>
                      <li>Assistenza tecnica e supporto</li>
                      <li>Fatturazione e contabilità</li>
                      <li>Comunicazioni di servizio</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Legal Requirements Section */}
            <div className="bg-white shadow-lg rounded-2xl overflow-hidden">
              <div className="p-6 bg-gradient-to-r from-secondary-600 to-secondary-700 flex items-center">
                <Scale className="h-8 w-8 text-white mr-4" />
                <div>
                  <h2 className="text-2xl font-bold text-white">Requisiti Legali</h2>
                  <p className="text-secondary-100">Conformità e obblighi normativi</p>
                </div>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="flex items-start space-x-4">
                  <ShieldCheck className="h-6 w-6 text-secondary-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Conformità GDPR</h3>
                    <p className="text-gray-600">
                      Il nostro software è pienamente conforme al Regolamento Generale sulla Protezione 
                      dei Dati (GDPR) e alle normative italiane sulla privacy.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <BookOpen className="h-6 w-6 text-secondary-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Base Giuridica</h3>
                    <ul className="list-disc pl-5 text-gray-600 space-y-2">
                      <li>Esecuzione del contratto</li>
                      <li>Obblighi legali</li>
                      <li>Consenso dell'interessato</li>
                      <li>Legittimo interesse</li>
                    </ul>
                  </div>
                </div>

                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r">
                  <div className="flex">
                    <AlertTriangle className="h-6 w-6 text-yellow-400" />
                    <div className="ml-3">
                      <h4 className="text-sm font-medium text-yellow-800">Importante</h4>
                      <p className="text-sm text-yellow-700 mt-1">
                        La mancata accettazione dei termini può limitare l'accesso ad alcune funzionalità 
                        del sistema.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            {/* Data Security Section */}
            <div className="bg-white shadow-lg rounded-2xl overflow-hidden">
              <div className="p-6 bg-gradient-to-r from-green-600 to-green-700 flex items-center">
                <Server className="h-8 w-8 text-white mr-4" />
                <div>
                  <h2 className="text-2xl font-bold text-white">Sicurezza dei Dati</h2>
                  <p className="text-green-100">Protezione e backup dei dati</p>
                </div>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="flex items-start space-x-4">
                  <HardDrive className="h-6 w-6 text-green-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Archiviazione</h3>
                    <p className="text-gray-600">
                      I dati sono archiviati in data center certificati con backup giornalieri 
                      e crittografia avanzata.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Network className="h-6 w-6 text-green-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Trasmissione</h3>
                    <p className="text-gray-600">
                      Tutte le comunicazioni sono protette da crittografia SSL/TLS per garantire 
                      la massima sicurezza.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Bell className="h-6 w-6 text-green-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Monitoraggio</h3>
                    <p className="text-gray-600">
                      Sistema di monitoraggio 24/7 per prevenire e rilevare eventuali anomalie 
                      o tentativi di accesso non autorizzati.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Communication Section */}
            <div className="bg-white shadow-lg rounded-2xl overflow-hidden">
              <div className="p-6 bg-gradient-to-r from-blue-600 to-blue-700 flex items-center">
                <MessageSquare className="h-8 w-8 text-white mr-4" />
                <div>
                  <h2 className="text-2xl font-bold text-white">Comunicazioni</h2>
                  <p className="text-blue-100">Gestione delle comunicazioni</p>
                </div>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="flex items-start space-x-4">
                  <Mail className="h-6 w-6 text-blue-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Email</h3>
                    <p className="text-gray-600">
                      Le comunicazioni email sono utilizzate per notifiche importanti, 
                      aggiornamenti e supporto tecnico.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Smartphone className="h-6 w-6 text-blue-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Notifiche Mobile</h3>
                    <p className="text-gray-600">
                      Le notifiche push sono utilizzate per avvisi in tempo reale 
                      e aggiornamenti critici.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Download className="h-6 w-6 text-blue-500 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Accesso ai Dati</h3>
                    <p className="text-gray-600">
                      Puoi richiedere una copia dei tuoi dati personali in qualsiasi momento 
                      attraverso l'apposita funzione nel pannello di controllo.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center justify-center space-x-2 mb-4">
            <a 
              href="mailto:privacy@easysistem.it" 
              className="text-primary-600 hover:text-primary-700 flex items-center"
            >
              <Mail className="h-5 w-5 mr-1" />
              privacy@easysistem.it
            </a>
            <span className="text-gray-300">|</span>
            <a 
              href="tel:+390818557973" 
              className="text-primary-600 hover:text-primary-700 flex items-center"
            >
              <Phone className="h-5 w-5 mr-1" />
              081 18557973
            </a>
            <span className="text-gray-300">|</span>
            <a 
              href="https://www.easysistem.it" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-primary-600 hover:text-primary-700 flex items-center"
            >
              <Globe className="h-5 w-5 mr-1" />
              www.easysistem.it
            </a>
          </div>
          
          <p className="text-sm text-gray-500">
            © 2025 EasySystem di Raffaele Bianchetti - Tutti i diritti riservati
          </p>
          <p className="text-sm text-gray-500 mt-1">
            P.IVA: 04118710617
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;