import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Laptop, Monitor, Printer, HardDrive, Wrench, MessageSquare, 
  Users, HeartPulse, Database, Headphones, Keyboard, Mouse, 
  Cpu, Smartphone, PhoneCall, MessageCircle, Mail, Globe,
  Building, Info, Shield, Lock, Key, Zap, Cloud, Server,
  Network, Wifi, Code, GitBranch, GitMerge, GitPullRequest
} from 'lucide-react';
import Logo from '../components/Logo';

const Splash: React.FC = () => {
  const [progress, setProgress] = useState(0);
  const [dataFlowText, setDataFlowText] = useState('');
  const navigate = useNavigate();

  // Modern tech-focused loading messages
  const dataFlowMessages = [
    'Inizializzazione ambiente...',
    'Connessione al cloud...',
    'Sincronizzazione database...',
    'Caricamento moduli...',
    'Verifica integrità...',
    'Ottimizzazione cache...',
    'Preparazione interfaccia...',
    'Sistema pronto!'
  ];

  useEffect(() => {
    // Progress and data flow animation
    let currentMessageIndex = 0;
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + 1;
        
        // Update data flow message
        if (newProgress % 12 === 0 && currentMessageIndex < dataFlowMessages.length) {
          setDataFlowText(dataFlowMessages[currentMessageIndex]);
          currentMessageIndex++;
        }
        
        if (newProgress >= 100) {
          clearInterval(progressInterval);
          setTimeout(() => {
            navigate('/login');
          }, 1500);
          return 100;
        }
        return newProgress;
      });
    }, 80);

    return () => {
      clearInterval(progressInterval);
    };
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 flex flex-col relative overflow-hidden">
      {/* Main content */}
      <div className="flex-1 flex flex-col items-center justify-center relative z-10 px-4">
        {/* Logo Section */}
        <div className="relative">
          <Logo size="lg" animated={true} withText={false} />
        </div>
        
        {/* Text Section */}
        <div className="mt-8 text-center">
          <h1 className="text-6xl font-bold text-white mb-2 relative">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-blue-600">
              Easy
            </span>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-secondary-400 to-secondary-600">
              LAB
            </span>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-accent-400 to-accent-600">
              25
            </span>
          </h1>
          <p className="text-gray-300 text-lg">
            Gestionale per laboratori tecnici
          </p>
        </div>

        {/* Progress Section */}
        <div className="w-full max-w-md mx-auto px-4 mt-8">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center text-blue-400">
              <Database className="h-4 w-4 mr-2 animate-pulse" />
              <span className="text-sm font-medium">{dataFlowText}</span>
            </div>
            <span className="text-sm font-medium text-blue-400">{progress}%</span>
          </div>
          <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 rounded-full transition-all duration-300 ease-out relative"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 bg-white opacity-20 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex-shrink-0 text-center py-6">
        <div className="flex items-center justify-center space-x-4 mb-2">
          <a 
            href="https://www.easysistem.it" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-blue-400 hover:text-blue-300 flex items-center transition-colors"
          >
            <Globe className="h-4 w-4 mr-1" />
            www.easysistem.it
          </a>
          <span className="text-gray-600">|</span>
          <a 
            href="mailto:assistenza@easysistem.it"
            className="text-blue-400 hover:text-blue-300 flex items-center transition-colors"
          >
            <Mail className="h-4 w-4 mr-1" />
            assistenza@easysistem.it
          </a>
        </div>
        <p className="text-sm text-gray-400">
          © 2025 EasySystem di Raffaele Bianchetti - Tutti i diritti riservati
        </p>
      </div>
    </div>
  );
};

export default Splash;