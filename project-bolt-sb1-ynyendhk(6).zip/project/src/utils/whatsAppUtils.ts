import axios from 'axios';
import { SystemSettings } from '../types';

// Interface for the WhatsApp Message template
interface WhatsAppMessage {
  messaging_product: 'whatsapp';
  recipient_type: 'individual';
  to: string;
  type: 'text' | 'template';
  text?: {
    preview_url: boolean;
    body: string;
  };
  template?: {
    name: string;
    language: {
      code: string;
    };
    components: any[];
  };
}

/**
 * Formats a phone number for WhatsApp API
 * @param phoneNumber Phone number to format
 * @returns Formatted phone number
 */
export const formatPhoneNumber = (phoneNumber: string): string => {
  // Remove any non-digit characters except the leading + sign
  let formatted = phoneNumber.replace(/[^\d+]/g, '');
  
  // Ensure it starts with a + sign
  if (!formatted.startsWith('+')) {
    formatted = `+${formatted}`;
  }
  
  return formatted;
};

/**
 * Sends a WhatsApp message using the WhatsApp Business API
 * @param settings The system settings containing WhatsApp credentials
 * @param phoneNumber The recipient's phone number
 * @param message The message to send
 * @returns Promise resolving to the API response
 */
export const sendWhatsAppMessage = async (
  settings: SystemSettings,
  phoneNumber: string,
  message: string
): Promise<any> => {
  // Validate required settings
  if (!settings.enableWhatsApp) {
    throw new Error('WhatsApp integration is not enabled');
  }
  
  if (!settings.whatsAppPhoneNumberId || !settings.whatsAppAccessToken) {
    throw new Error('WhatsApp credentials are not configured');
  }
  
  const formattedPhone = formatPhoneNumber(phoneNumber);
  
  // Prepare the request message
  const whatsappMessage: WhatsAppMessage = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: formattedPhone,
    type: 'text',
    text: {
      preview_url: false,
      body: message
    }
  };
  
  try {
    // Make API request to WhatsApp Business API
    const response = await axios.post(
      `https://graph.facebook.com/v17.0/${settings.whatsAppPhoneNumberId}/messages`,
      whatsappMessage,
      {
        headers: {
          'Authorization': `Bearer ${settings.whatsAppAccessToken}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    return response.data;
  } catch (error) {
    console.error('WhatsApp API Error:', error);
    
    // Extract error message from the API response if available
    if (axios.isAxiosError(error) && error.response) {
      throw new Error(`WhatsApp API error: ${error.response.data?.error?.message || 'Unknown error'}`);
    }
    
    throw error;
  }
};

/**
 * Validates WhatsApp API credentials
 * @param settings The system settings containing WhatsApp credentials
 * @returns Promise resolving to true if credentials are valid
 */
export const validateWhatsAppCredentials = async (settings: SystemSettings): Promise<boolean> => {
  // Validate required settings
  if (!settings.enableWhatsApp) {
    throw new Error('WhatsApp integration is not enabled');
  }
  
  if (!settings.whatsAppBusinessId || !settings.whatsAppPhoneNumberId || !settings.whatsAppAccessToken) {
    throw new Error('WhatsApp credentials are incomplete');
  }
  
  try {
    // Check if we can get business profile info (validates token)
    const response = await axios.get(
      `https://graph.facebook.com/v17.0/${settings.whatsAppPhoneNumberId}`,
      {
        headers: {
          'Authorization': `Bearer ${settings.whatsAppAccessToken}`
        }
      }
    );
    
    return true;
  } catch (error) {
    console.error('WhatsApp Credentials Validation Error:', error);
    
    // Extract error message from the API response if available
    if (axios.isAxiosError(error) && error.response) {
      throw new Error(`WhatsApp API error: ${error.response.data?.error?.message || 'Invalid credentials'}`);
    }
    
    throw error;
  }
};

/**
 * Creates a template for appointment confirmation
 * @param settings The system settings
 * @param appointmentDetails Details about the appointment
 * @returns Promise resolving to the template ID
 */
export const createAppointmentTemplate = async (
  settings: SystemSettings,
  templateName: string,
  language: string = 'it'
): Promise<string> => {
  // In a real implementation, this would create a WhatsApp message template via the API
  // For demo purposes, we'll just return a sample template name
  
  return 'appointment_confirmation';
};