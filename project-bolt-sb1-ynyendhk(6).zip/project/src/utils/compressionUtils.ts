import { compress as pako_deflate, decompress as pako_inflate } from 'pako';

/**
 * Compress data using DEFLATE algorithm
 * @param data Data to compress
 * @returns Compressed data as base64 string
 */
export const compress = async (data: string): Promise<string> => {
  try {
    const compressed = pako_deflate(data);
    return Buffer.from(compressed).toString('base64');
  } catch (error) {
    console.error('Compression error:', error);
    throw new Error('Failed to compress data');
  }
};

/**
 * Decompress DEFLATE compressed data
 * @param data Compressed data as base64 string
 * @returns Decompressed data
 */
export const decompress = async (data: string): Promise<string> => {
  try {
    const compressed = Buffer.from(data, 'base64');
    const decompressed = pako_inflate(compressed);
    return new TextDecoder().decode(decompressed);
  } catch (error) {
    console.error('Decompression error:', error);
    throw new Error('Failed to decompress data');
  }
};

/**
 * Calculate compression ratio
 * @param originalSize Original size in bytes
 * @param compressedSize Compressed size in bytes
 * @returns Compression ratio as percentage
 */
export const getCompressionRatio = (originalSize: number, compressedSize: number): number => {
  if (originalSize === 0) return 0;
  return ((originalSize - compressedSize) / originalSize) * 100;
};

/**
 * Estimate compressed size
 * @param data Data to estimate
 * @returns Estimated compressed size in bytes
 */
export const estimateCompressedSize = (data: string): number => {
  try {
    const compressed = pako_deflate(data);
    return compressed.length;
  } catch (error) {
    console.error('Size estimation error:', error);
    return 0;
  }
};