import localforage from 'localforage';
import { format } from 'date-fns';

// Initialize localforage instance
const cache = localforage.createInstance({
  name: 'easylab-cache'
});

// Cache configuration
const CACHE_CONFIG = {
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days in milliseconds
  maxSize: 50 * 1024 * 1024, // 50MB in bytes
  criticalSize: 45 * 1024 * 1024, // 45MB - trigger cleanup when reaching this size
  cleanupThreshold: 0.2, // Remove 20% of oldest items when cleanup is triggered
};

// Cache item interface
interface CacheItem {
  key: string;
  value: any;
  timestamp: number;
  size: number;
  type: 'data' | 'asset' | 'config';
}

// Cache statistics interface
interface CacheStats {
  totalItems: number;
  totalSize: number;
  oldestItem: string | null;
  newestItem: string | null;
  itemsByType: Record<string, number>;
  averageAge: number;
}

/**
 * Calculate the size of a value in bytes
 */
const calculateSize = (value: any): number => {
  try {
    const str = JSON.stringify(value);
    return new TextEncoder().encode(str).length;
  } catch (error) {
    console.warn('Error calculating cache item size:', error);
    return 0;
  }
};

/**
 * Store an item in the cache
 */
export const cacheSet = async (
  key: string,
  value: any,
  type: CacheItem['type'] = 'data'
): Promise<void> => {
  try {
    const size = calculateSize(value);
    const item: CacheItem = {
      key,
      value,
      timestamp: Date.now(),
      size,
      type
    };

    // Check if we need to clean up before adding new item
    const stats = await getCacheStats();
    if (stats.totalSize + size > CACHE_CONFIG.criticalSize) {
      await cleanupCache();
    }

    await cache.setItem(key, item);
  } catch (error) {
    console.error('Error setting cache item:', error);
    throw error;
  }
};

/**
 * Retrieve an item from the cache
 */
export const cacheGet = async <T>(key: string): Promise<T | null> => {
  try {
    const item = await cache.getItem<CacheItem>(key);
    
    if (!item) return null;

    // Check if item has expired
    if (Date.now() - item.timestamp > CACHE_CONFIG.maxAge) {
      await cache.removeItem(key);
      return null;
    }

    return item.value as T;
  } catch (error) {
    console.error('Error getting cache item:', error);
    return null;
  }
};

/**
 * Remove an item from the cache
 */
export const cacheRemove = async (key: string): Promise<void> => {
  try {
    await cache.removeItem(key);
  } catch (error) {
    console.error('Error removing cache item:', error);
    throw error;
  }
};

/**
 * Clear all items from the cache
 */
export const cacheClear = async (): Promise<void> => {
  try {
    await cache.clear();
  } catch (error) {
    console.error('Error clearing cache:', error);
    throw error;
  }
};

/**
 * Get cache statistics
 */
export const getCacheStats = async (): Promise<CacheStats> => {
  try {
    const keys = await cache.keys();
    const items: CacheItem[] = [];
    let totalSize = 0;
    const itemsByType: Record<string, number> = {};
    
    for (const key of keys) {
      const item = await cache.getItem<CacheItem>(key);
      if (item) {
        items.push(item);
        totalSize += item.size;
        itemsByType[item.type] = (itemsByType[item.type] || 0) + 1;
      }
    }

    // Handle empty cache case
    if (items.length === 0) {
      return {
        totalItems: 0,
        totalSize: 0,
        oldestItem: null,
        newestItem: null,
        itemsByType: {},
        averageAge: 0
      };
    }

    const timestamps = items.map(item => item.timestamp);
    const oldestTimestamp = Math.min(...timestamps);
    const newestTimestamp = Math.max(...timestamps);
    const averageAge = (Date.now() - (timestamps.reduce((a, b) => a + b, 0) / items.length));

    return {
      totalItems: items.length,
      totalSize,
      oldestItem: format(oldestTimestamp, 'dd/MM/yyyy HH:mm:ss'),
      newestItem: format(newestTimestamp, 'dd/MM/yyyy HH:mm:ss'),
      itemsByType,
      averageAge
    };
  } catch (error) {
    console.error('Error getting cache stats:', error);
    throw error;
  }
};

/**
 * Clean up old cache items
 */
export const cleanupCache = async (): Promise<void> => {
  try {
    const keys = await cache.keys();
    const items: CacheItem[] = [];
    
    // Get all items
    for (const key of keys) {
      const item = await cache.getItem<CacheItem>(key);
      if (item) {
        items.push(item);
      }
    }

    // Sort by timestamp (oldest first)
    items.sort((a, b) => a.timestamp - b.timestamp);

    // Calculate how many items to remove
    const itemsToRemove = Math.ceil(items.length * CACHE_CONFIG.cleanupThreshold);
    
    // Remove oldest items
    for (let i = 0; i < itemsToRemove; i++) {
      await cache.removeItem(items[i].key);
    }
  } catch (error) {
    console.error('Error cleaning up cache:', error);
    throw error;
  }
};

/**
 * Schedule automatic cache cleanup
 */
export const scheduleAutomaticCleanup = (): void => {
  // Run cleanup every day at 3 AM
  const runCleanup = () => {
    const now = new Date();
    if (now.getHours() === 3) {
      cleanupCache().catch(console.error);
    }
  };

  // Check every hour
  setInterval(runCleanup, 60 * 60 * 1000);
};

/**
 * Format cache size for display
 */
export const formatCacheSize = (bytes: number): string => {
  if (bytes === 0) return '0 B';
  
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};