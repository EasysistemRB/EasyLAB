import { format, isWeekend, isSameDay, isAfter, isBefore, parseISO, addDays } from 'date-fns';
import { it } from 'date-fns/locale';

/**
 * List of Italian holidays
 * Contains fixed and variable holidays
 */
export const ITALIAN_HOLIDAYS = [
  // Fixed holidays
  { month: 0, day: 1, description: "Capodanno" },               // New Year's Day
  { month: 0, day: 6, description: "Epifania" },                // Epiphany
  { month: 3, day: 25, description: "Festa della Liberazione" }, // Liberation Day
  { month: 4, day: 1, description: "Festa del Lavoro" },        // Labor Day
  { month: 5, day: 2, description: "Festa della Repubblica" },   // Republic Day
  { month: 7, day: 15, description: "Ferragosto" },              // Assumption Day
  { month: 10, day: 1, description: "Tutti i Santi" },          // All Saints' Day
  { month: 11, day: 8, description: "Immacolata Concezione" },   // Immaculate Conception
  { month: 11, day: 25, description: "Natale" },                // Christmas
  { month: 11, day: 26, description: "Santo Stefano" },         // St. Stephen's Day
];

// Variable holidays are calculated for each year (Easter, Easter Monday)
const getEasterHolidays = (year: number) => {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31) - 1;
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  
  const easterDate = new Date(year, month, day);
  const easterMondayDate = new Date(year, month, day + 1);
  
  return [
    { date: easterDate, description: "Pasqua" },
    { date: easterMondayDate, description: "Lunedì dell'Angelo" }
  ];
};

/**
 * Check if a date is an Italian holiday
 * @param date Date to check
 * @returns Boolean indicating if the date is a holiday and the holiday description
 */
export const isItalianHoliday = (date: Date): { isHoliday: boolean, description?: string } => {
  const month = date.getMonth();
  const day = date.getDate();
  const year = date.getFullYear();
  
  // Check fixed holidays
  for (const holiday of ITALIAN_HOLIDAYS) {
    if (month === holiday.month && day === holiday.day) {
      return { isHoliday: true, description: holiday.description };
    }
  }
  
  // Check Easter and Easter Monday
  const easterHolidays = getEasterHolidays(year);
  for (const holiday of easterHolidays) {
    if (isSameDay(date, holiday.date)) {
      return { isHoliday: true, description: holiday.description };
    }
  }
  
  return { isHoliday: false };
};

/**
 * Check if a date is a business day (not weekend and not holiday)
 * @param date Date to check
 * @returns Boolean indicating if the date is a business day
 */
export const isBusinessDay = (date: Date): boolean => {
  // Check if it's a weekend
  if (isWeekend(date)) {
    return false;
  }
  
  // Check if it's a holiday
  const { isHoliday } = isItalianHoliday(date);
  return !isHoliday;
};

/**
 * Format a date range for display
 * @param startDate Start date
 * @param endDate End date
 * @returns Formatted date range string
 */
export const formatDateRange = (startDate: Date, endDate: Date): string => {
  if (isSameDay(startDate, endDate)) {
    return format(startDate, 'd MMMM yyyy', { locale: it });
  }
  
  const startMonth = format(startDate, 'MMMM', { locale: it });
  const endMonth = format(endDate, 'MMMM', { locale: it });
  
  if (startMonth === endMonth) {
    return `${format(startDate, 'd', { locale: it })} - ${format(endDate, 'd MMMM yyyy', { locale: it })}`;
  }
  
  return `${format(startDate, 'd MMMM', { locale: it })} - ${format(endDate, 'd MMMM yyyy', { locale: it })}`;
};

/**
 * Get the status of an appointment reschedule with color and icon info
 * @param rescheduleCount Number of times the appointment has been rescheduled
 * @returns Object with status information
 */
export const getRescheduleStatus = (rescheduleCount: number) => {
  if (rescheduleCount === 0) {
    return {
      level: 0,
      color: 'bg-green-100 text-green-800 border-green-200',
      textColor: 'text-green-800',
      bgColor: 'bg-green-100',
      pulsing: false,
      label: 'Originale'
    };
  } else if (rescheduleCount === 1) {
    return {
      level: 1,
      color: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      textColor: 'text-yellow-800',
      bgColor: 'bg-yellow-100',
      pulsing: true,
      label: 'Riprogrammato (1)'
    };
  } else if (rescheduleCount === 2) {
    return {
      level: 2,
      color: 'bg-orange-100 text-orange-800 border-orange-200',
      textColor: 'text-orange-800',
      bgColor: 'bg-orange-100',
      pulsing: true,
      label: 'Riprogrammato (2)'
    };
  } else {
    return {
      level: 3,
      color: 'bg-red-100 text-red-800 border-red-200',
      textColor: 'text-red-800',
      bgColor: 'bg-red-100',
      pulsing: true,
      label: 'Riprogrammato (+3)'
    };
  }
};

/**
 * Generate business hours for a day (9:00 to 18:00)
 * @returns Array of hour numbers representing business hours
 */
export const getBusinessHours = (): number[] => {
  return Array.from({ length: 10 }, (_, i) => i + 9); // 9:00 - 18:00
};

/**
 * Format a time string to display format
 * @param time Time in HH:MM format
 * @returns Formatted time string
 */
export const formatTime = (time: string): string => {
  const [hours, minutes] = time.split(':');
  return `${hours}:${minutes}`;
};

// Reschedule reasons options for appointment rescheduling
export const RESCHEDULE_REASONS = [
  { id: 'client_request', label: 'Richiesta del cliente' },
  { id: 'staff_unavailable', label: 'Staff non disponibile' },
  { id: 'emergency', label: 'Emergenza' },
  { id: 'double_booking', label: 'Doppia prenotazione' },
  { id: 'weather', label: 'Maltempo' },
  { id: 'technical_issues', label: 'Problemi tecnici' },
  { id: 'other', label: 'Altro' }
];