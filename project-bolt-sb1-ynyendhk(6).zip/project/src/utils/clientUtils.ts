import { v4 as uuidv4 } from 'uuid';
import { Client, User } from '../types';

/**
 * Validates if a VAT number is already in use by another client
 * @param vatNumber The VAT number to check
 * @param clients Array of existing clients
 * @param currentClientId Optional current client ID to exclude from check (for updates)
 * @returns True if VAT number is unique, false if already exists
 */
export const isVatNumberUnique = (
  vatNumber: string,
  clients: Client[],
  currentClientId?: string
): boolean => {
  return !clients.some(client => 
    client.vatNumber === vatNumber && client.id !== currentClientId
  );
};

/**
 * Generates a unique client code with the specified prefix
 * @param existingCodes Array of existing client codes to check against
 * @returns A unique client code in the format EsLAB-XXXX
 */
export const generateClientCode = (existingCodes: string[] = []): string => {
  const prefix = 'EsLAB-';
  let code: string;
  let isUnique = false;
  
  while (!isUnique) {
    // Generate a random 4-digit number
    const randomNumber = Math.floor(1000 + Math.random() * 9000);
    code = `${prefix}${randomNumber}`;
    
    // Check if the code already exists
    isUnique = !existingCodes.includes(code);
  }
  
  return code!;
};

/**
 * Generate a random password with numbers, uppercase, lowercase, and special characters
 * @param length The length of the password to generate
 * @returns A randomly generated password
 */
export const generateSecurePassword = (length: number = 8): string => {
  const lowerChars = 'abcdefghijklmnopqrstuvwxyz';
  const upperChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const numbers = '0123456789';
  const specialChars = '!@#$%^&*()_+{}[]|:;<>,.?/~';
  
  const allChars = lowerChars + upperChars + numbers + specialChars;
  
  // Ensure at least one of each type
  let password = '';
  password += lowerChars.charAt(Math.floor(Math.random() * lowerChars.length));
  password += upperChars.charAt(Math.floor(Math.random() * upperChars.length));
  password += numbers.charAt(Math.floor(Math.random() * numbers.length));
  password += specialChars.charAt(Math.floor(Math.random() * specialChars.length));
  
  // Fill the rest with random characters
  for (let i = 4; i < length; i++) {
    password += allChars.charAt(Math.floor(Math.random() * allChars.length));
  }
  
  // Shuffle the password characters
  return password.split('').sort(() => 0.5 - Math.random()).join('');
};

/**
 * Generate client portal access credentials and link
 * @param client The client to generate credentials for
 * @param baseUrl The base URL for the client portal
 * @returns Object containing username, password, and portal link
 */
export const generateClientCredentials = (
  client: Client,
  baseUrl: string = 'https://portal.easysistem.it'
): { username: string; password: string; portalLink: string } => {
  // Generate username based on client code
  const username = client.clientCode.toLowerCase();
  
  // Generate a secure random password
  const password = generateSecurePassword(10);
  
  // Generate a unique access token
  const accessToken = uuidv4();
  
  // Create personalized portal link
  const portalLink = `${baseUrl}/access?token=${accessToken}&client=${client.id}`;
  
  return {
    username,
    password,
    portalLink
  };
};

/**
 * Create a user account for a client
 * @param client The client to create an account for
 * @returns A new User object
 */
export const createClientUser = (client: Client): User => {
  const { username } = generateClientCredentials(client);
  
  const user: User = {
    id: uuidv4(),
    username,
    role: 'user',
    name: client.name,
    email: client.email,
    createdAt: new Date().toISOString(),
    passwordExpiry: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days
    isActive: true,
    clientId: client.id
  };
  
  return user;
};

/**
 * Generate QR code data for client
 * @param client The client to generate QR code data for
 * @returns JSON string with client data for QR code
 */
export const generateClientQRData = (client: Client): string => {
  const qrData = {
    clientId: client.id,
    clientCode: client.clientCode,
    name: client.name,
    timestamp: new Date().toISOString()
  };
  
  return JSON.stringify(qrData);
};

/**
 * Generate email with access link for client
 * @param client The client object with portal access link
 * @param credentials Object containing username and password
 * @returns HTML email template string
 */
export const generateClientAccessEmail = (
  client: Client,
  credentials: { username: string; password: string }
): string => {
  if (!client.portalAccessLink) {
    throw new Error('Client does not have a portal access link');
  }
  
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eaeaea; border-radius: 5px;">
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #4338ca;">EasyLAB 25</h1>
        <p style="color: #666;">Gestionale per laboratori tecnici</p>
      </div>
      
      <div style="margin-bottom: 20px;">
        <h2 style="color: #333;">Accesso all'Area Riservata</h2>
        <p>Gentile ${client.name},</p>
        <p>di seguito trovi le credenziali e il link per accedere alla tua area riservata EasyLAB 25:</p>
      </div>
      
      <div style="background-color: #f9fafb; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
        <p><strong>Codice Cliente:</strong> ${client.clientCode}</p>
        <p><strong>Username:</strong> ${credentials.username}</p>
        <p><strong>Password:</strong> ${credentials.password}</p>
      </div>
      
      <div style="text-align: center; margin-bottom: 20px;">
        <a href="${client.portalAccessLink}" style="display: inline-block; background-color: #4338ca; color: white; text-decoration: none; padding: 10px 20px; border-radius: 5px; font-weight: bold;">
          Accedi all'Area Riservata
        </a>
      </div>
      
      <div style="font-size: 0.8rem; color: #666; margin-top: 20px; border-top: 1px solid #eaeaea; padding-top: 20px;">
        <p>Per assistenza, contattaci all'indirizzo email: assistenza@easysistem.it</p>
        <p>© 2025 EasySystem di Raffaele Bianchetti - Tutti i diritti riservati</p>
      </div>
    </div>
  `;
};