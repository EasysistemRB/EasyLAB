import { v4 as uuidv4 } from 'uuid';
import { format } from 'date-fns';
import { SystemSettings } from '../types';

export interface BackupOptions {
  type: 'full' | 'partial';
  components?: ('clients' | 'appointments' | 'tickets' | 'settings')[];
  compress?: boolean;
  encrypt?: boolean;
}

export interface BackupMetadata {
  id: string;
  timestamp: string;
  type: 'full' | 'partial';
  components: string[];
  size: number;
  checksum: string;
  version: string;
  compressed: boolean;
  encrypted: boolean;
}

export interface BackupStats {
  totalBackups: number;
  lastBackup: string | null;
  totalSize: number;
  averageSize: number;
  successRate: number;
}

// Create backup metadata
export const createBackupMetadata = (
  data: any,
  options: BackupOptions
): BackupMetadata => {
  const timestamp = new Date().toISOString();
  const size = new TextEncoder().encode(JSON.stringify(data)).length;
  
  return {
    id: uuidv4(),
    timestamp,
    type: options.type,
    components: options.components || ['clients', 'appointments', 'tickets', 'settings'],
    size,
    checksum: calculateChecksum(data),
    version: '1.0.0',
    compressed: options.compress || false,
    encrypted: options.encrypt || false
  };
};

// Calculate data checksum
export const calculateChecksum = (data: any): string => {
  const str = JSON.stringify(data);
  let hash = 0;
  
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  
  return Math.abs(hash).toString(16);
};

// Validate backup data
export const validateBackup = (data: any, metadata: BackupMetadata): boolean => {
  // Verify checksum
  const currentChecksum = calculateChecksum(data);
  if (currentChecksum !== metadata.checksum) {
    throw new Error('Backup validation failed: checksum mismatch');
  }
  
  // Verify required components
  const requiredComponents = ['clients', 'appointments', 'tickets', 'settings'];
  const missingComponents = requiredComponents.filter(
    comp => !metadata.components.includes(comp)
  );
  
  if (metadata.type === 'full' && missingComponents.length > 0) {
    throw new Error(`Backup validation failed: missing components: ${missingComponents.join(', ')}`);
  }
  
  return true;
};

// Generate backup filename
export const generateBackupFilename = (metadata: BackupMetadata): string => {
  const date = format(new Date(metadata.timestamp), 'yyyy-MM-dd_HHmmss');
  const type = metadata.type === 'full' ? 'full' : 'partial';
  const ext = metadata.compressed ? 'zip' : 'json';
  
  return `backup_${type}_${date}.${ext}`;
};

// Format backup size for display
export const formatBackupSize = (bytes: number): string => {
  if (bytes === 0) return '0 B';
  
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};

// Calculate backup statistics
export const calculateBackupStats = (backupHistory: any[]): BackupStats => {
  const totalBackups = backupHistory.length;
  const lastBackup = totalBackups > 0 ? backupHistory[0].timestamp : null;
  
  let totalSize = 0;
  let successCount = 0;
  
  backupHistory.forEach(backup => {
    totalSize += backup.size || 0;
    if (backup.status === 'success') {
      successCount++;
    }
  });
  
  const averageSize = totalBackups > 0 ? totalSize / totalBackups : 0;
  const successRate = totalBackups > 0 ? (successCount / totalBackups) * 100 : 0;
  
  return {
    totalBackups,
    lastBackup,
    totalSize,
    averageSize,
    successRate
  };
};