import { HelpCategory, HelpSection } from '../types';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

export const generateHelpContent = (): HelpCategory[] => {
  return [
    {
      id: 'getting-started',
      title: 'Introduzione',
      icon: 'Book',
      sections: [
        {
          id: 'overview',
          title: 'Panoramica del Sistema',
          content: 'EasyLAB 25 è un sistema gestionale avanzato progettato per laboratori tecnici. ' +
                  'Offre una suite completa di strumenti per la gestione di clienti, dispositivi, appuntamenti e ticket di assistenza.',
          examples: [
            'Gestione completa dell\'anagrafica clienti',
            'Monitoraggio dispositivi e manutenzioni',
            'Calendario appuntamenti integrato',
            'Sistema di ticketing avanzato'
          ],
          images: [
            'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80'
          ],
          shortcuts: [
            { key: '⌘ + K', description: 'Ricerca globale' },
            { key: '⌘ + N', description: 'Nuovo elemento' },
            { key: '⌘ + S', description: 'Salva modifiche' },
            { key: 'Esc', description: 'Chiudi/Annulla' }
          ],
          version: '1.0.0',
          date: '2025-03-22'
        }
      ]
    },
    {
      id: 'clients',
      title: 'Gestione Clienti',
      icon: 'Users',
      sections: [
        {
          id: 'client-management',
          title: 'Anagrafica Clienti',
          content: 'Gestione completa dell\'anagrafica clienti con supporto per sedi multiple, ' +
                  'dispositivi associati e documenti condivisi. Include funzionalità avanzate ' +
                  'come QR code per identificazione rapida e gestione accessi al portale clienti.',
          examples: [
            'Creazione e modifica schede cliente',
            'Gestione sedi e indirizzi multipli',
            'Tracking dispositivi e manutenzioni',
            'Condivisione documenti sicura'
          ],
          shortcuts: [
            { key: '⌘ + N', description: 'Nuovo cliente' },
            { key: '⌘ + E', description: 'Modifica cliente' },
            { key: '⌘ + F', description: 'Cerca cliente' },
            { key: '⌘ + D', description: 'Duplica cliente' }
          ],
          version: '1.0.0',
          date: '2025-03-22'
        },
        {
          id: 'device-management',
          title: 'Gestione Dispositivi',
          content: 'Sistema completo per la gestione dei dispositivi dei clienti, con particolare ' +
                  'focus sui registratori telematici. Include tracking delle verificazioni periodiche ' +
                  'e gestione delle manutenzioni programmate.',
          examples: [
            'Registrazione nuovi dispositivi',
            'Monitoraggio stato RT',
            'Gestione verificazioni periodiche',
            'Tracking interventi tecnici'
          ],
          shortcuts: [
            { key: '⌘ + R', description: 'Nuovo dispositivo' },
            { key: '⌘ + V', description: 'Nuova verificazione' },
            { key: '⌘ + M', description: 'Nuova manutenzione' }
          ],
          version: '1.0.0',
          date: '2025-03-22'
        }
      ]
    },
    {
      id: 'appointments',
      title: 'Gestione Appuntamenti',
      icon: 'Calendar',
      sections: [
        {
          id: 'calendar',
          title: 'Calendario Interattivo',
          content: 'Calendario avanzato con vista giornaliera, settimanale e mensile. ' +
                  'Supporta drag & drop per la pianificazione, notifiche automatiche ' +
                  'e integrazione con WhatsApp per le conferme.',
          examples: [
            'Pianificazione appuntamenti',
            'Gestione conflitti',
            'Notifiche automatiche',
            'Conferme via WhatsApp'
          ],
          shortcuts: [
            { key: '⌘ + T', description: 'Vai a oggi' },
            { key: '⌘ + D', description: 'Vista giorno' },
            { key: '⌘ + W', description: 'Vista settimana' },
            { key: '⌘ + M', description: 'Vista mese' }
          ],
          version: '1.0.0',
          date: '2025-03-22'
        },
        {
          id: 'appointment-types',
          title: 'Tipologie di Appuntamento',
          content: 'Gestione delle diverse tipologie di appuntamento con durate predefinite, ' +
                  'checklist e procedure standardizzate. Supporta la personalizzazione delle ' +
                  'tipologie in base alle esigenze specifiche.',
          examples: [
            'Configurazione tipologie',
            'Definizione durate',
            'Creazione checklist',
            'Personalizzazione workflow'
          ],
          version: '1.0.0',
          date: '2025-03-22'
        }
      ]
    },
    {
      id: 'tickets',
      title: 'Sistema Ticket',
      icon: 'TicketCheck',
      sections: [
        {
          id: 'ticket-management',
          title: 'Gestione Ticket',
          content: 'Sistema completo per la gestione delle richieste di assistenza. ' +
                  'Include prioritizzazione automatica, tracking dello stato, notifiche ' +
                  'in tempo reale e integrazione con il sistema di appuntamenti.',
          examples: [
            'Creazione ticket assistenza',
            'Assegnazione priorità',
            'Tracking stato e risoluzione',
            'Notifiche automatiche'
          ],
          shortcuts: [
            { key: '⌘ + T', description: 'Nuovo ticket' },
            { key: '⌘ + A', description: 'Assegna ticket' },
            { key: '⌘ + U', description: 'Aggiorna stato' }
          ],
          version: '1.0.0',
          date: '2025-03-22'
        },
        {
          id: 'ticket-analytics',
          title: 'Analisi e Statistiche',
          content: 'Strumenti avanzati per l\'analisi delle performance del servizio ' +
                  'di assistenza. Include metriche chiave, trend analysis e reporting ' +
                  'dettagliato.',
          examples: [
            'Dashboard analytics',
            'Report performance',
            'Analisi tempi risposta',
            'Trend risoluzione'
          ],
          version: '1.0.0',
          date: '2025-03-22'
        }
      ]
    },
    {
      id: 'settings',
      title: 'Impostazioni',
      icon: 'Settings',
      sections: [
        {
          id: 'system-settings',
          title: 'Configurazione Sistema',
          content: 'Gestione completa delle impostazioni di sistema, incluse le ' +
                  'configurazioni per backup, notifiche, integrazioni WhatsApp ' +
                  'e personalizzazione dell\'interfaccia.',
          examples: [
            'Configurazione backup',
            'Setup notifiche',
            'Integrazione WhatsApp',
            'Personalizzazione UI'
          ],
          shortcuts: [
            { key: '⌘ + ,', description: 'Apri impostazioni' },
            { key: '⌘ + B', description: 'Gestione backup' },
            { key: '⌘ + I', description: 'Informazioni sistema' }
          ],
          version: '1.0.0',
          date: '2025-03-22'
        },
        {
          id: 'user-management',
          title: 'Gestione Utenti',
          content: 'Gestione completa degli account utente, permessi e ruoli. ' +
                  'Include funzionalità per la gestione delle password, autenticazione ' +
                  'a due fattori e tracking delle attività.',
          examples: [
            'Creazione utenti',
            'Gestione permessi',
            'Reset password',
            'Log attività'
          ],
          version: '1.0.0',
          date: '2025-03-22'
        }
      ]
    },
    {
      id: 'developer',
      title: 'Informazioni Sviluppatore',
      icon: 'Code',
      sections: [
        {
          id: 'developer-info',
          title: 'Sviluppatore',
          content: `EasyLAB 25 è sviluppato da EasySystem di Raffaele Bianchetti

Contatti:
- Email: info@easysistem.it
- Telefono: +39 081 18557973
- Sito Web: www.easysistem.it

Sede Legale:
Via Bari 80
80026 Casoria (NA)
Italia

P.IVA: 04118710617

Stack Tecnologico:
- React 18 con TypeScript
- Tailwind CSS per lo styling
- Vite come build tool
- Supabase per database e autenticazione
- Integrazione WhatsApp Business API
- PWA per supporto offline
- WebSocket per aggiornamenti real-time`,
          examples: [
            'Sviluppo custom',
            'Integrazioni personalizzate',
            'Supporto tecnico dedicato',
            'Aggiornamenti continui'
          ],
          version: '1.0.0',
          date: '2025-03-22'
        }
      ]
    }
  ];
};

export const searchHelpContent = (categories: HelpCategory[], query: string): HelpCategory[] => {
  const searchTerm = query.toLowerCase();
  
  return categories
    .map(category => ({
      ...category,
      sections: category.sections.filter(section =>
        section.title.toLowerCase().includes(searchTerm) ||
        section.content.toLowerCase().includes(searchTerm) ||
        section.examples?.some(ex => ex.toLowerCase().includes(searchTerm))
      )
    }))
    .filter(category => category.sections.length > 0);
};

export const getLatestUpdates = (categories: HelpCategory[]): HelpSection[] => {
  return categories
    .flatMap(category => category.sections)
    .filter(section => section.date)
    .sort((a, b) => {
      if (a.date && b.date) {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
      return 0;
    })
    .slice(0, 5);
};

// Generate PDF documentation
export const generatePDFDocumentation = () => {
  // This would be implemented with a PDF generation library
  // For now, we'll redirect to the documentation site
  window.open('https://docs.easysistem.it', '_blank');
};