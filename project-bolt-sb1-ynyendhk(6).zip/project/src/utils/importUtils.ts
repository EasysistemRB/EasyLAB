import { read, utils } from 'xlsx';
import Papa from 'papaparse';
import * as pdfjsLib from 'pdfjs-dist';
import { Client, Device } from '../types';
import { v4 as uuidv4 } from 'uuid';

// Supported file types
export const SUPPORTED_FORMATS = [
  { ext: 'xlsx', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', label: 'Excel (XLSX)', icon: 'FileSpreadsheet' },
  { ext: 'xls', type: 'application/vnd.ms-excel', label: 'Excel 97-2003 (XLS)', icon: 'FileSpreadsheet' },
  { ext: 'csv', type: 'text/csv', label: 'CSV', icon: 'FileText' },
  { ext: 'xml', type: 'text/xml', label: 'XML', icon: 'FileCode' },
  { ext: 'txt', type: 'text/plain', label: 'TXT', icon: 'FileText' },
  { ext: 'dat', type: 'text/plain', label: 'DAT', icon: 'FileText' },
  { ext: 'pdf', type: 'application/pdf', label: 'PDF', icon: 'FilePdf' }
];

// Field mappings for import
export const FIELD_MAPPINGS = {
  clients: {
    name: ['name', 'nome', 'ragione sociale', 'cliente'],
    email: ['email', 'e-mail', 'posta elettronica'],
    phone: ['phone', 'telefono', 'tel', 'cellulare'],
    address: ['address', 'indirizzo', 'via'],
    city: ['city', 'città', 'citta', 'comune'],
    postalCode: ['postalcode', 'cap', 'codice postale'],
    vatNumber: ['vatnumber', 'piva', 'partita iva', 'p.iva'],
    fiscalCode: ['fiscalcode', 'codice fiscale', 'cf']
  },
  devices: {
    name: ['name', 'nome', 'dispositivo'],
    type: ['type', 'tipo', 'categoria'],
    brand: ['brand', 'marca', 'produttore'],
    model: ['model', 'modello'],
    serialNumber: ['serialnumber', 'sn', 'numero di serie'],
    registrationNumber: ['registrationnumber', 'numero registrazione', 'reg']
  }
};

// Detect file type and parse accordingly
export const parseFile = async (file: File): Promise<any[]> => {
  const extension = file.name.split('.').pop()?.toLowerCase();
  const buffer = await file.arrayBuffer();

  switch (extension) {
    case 'xlsx':
    case 'xls':
      const workbook = read(buffer);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      return utils.sheet_to_json(worksheet);

    case 'csv':
      return new Promise((resolve, reject) => {
        Papa.parse(file, {
          complete: (results) => resolve(results.data),
          error: (error) => reject(error),
          header: true
        });
      });

    case 'xml':
      const text = new TextDecoder().decode(buffer);
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(text, 'text/xml');
      return parseXMLToArray(xmlDoc);

    case 'txt':
    case 'dat':
      const content = new TextDecoder().decode(buffer);
      return parsePlainText(content);

    case 'pdf':
      return parsePDF(buffer);

    default:
      throw new Error('Formato file non supportato');
  }
};

// Helper function to parse XML to array
const parseXMLToArray = (xmlDoc: Document): any[] => {
  const result: any[] = [];
  const records = xmlDoc.getElementsByTagName('record');

  for (let i = 0; i < records.length; i++) {
    const record = records[i];
    const obj: any = {};
    
    for (const child of Array.from(record.children)) {
      obj[child.tagName.toLowerCase()] = child.textContent;
    }
    
    result.push(obj);
  }

  return result;
};

// Helper function to parse plain text (assuming tab or comma separated)
const parsePlainText = (content: string): any[] => {
  const lines = content.split('\n').filter(line => line.trim());
  if (lines.length === 0) return [];

  const separator = lines[0].includes('\t') ? '\t' : ',';
  const headers = lines[0].split(separator).map(h => h.trim().toLowerCase());

  return lines.slice(1).map(line => {
    const values = line.split(separator);
    const record: any = {};
    headers.forEach((header, index) => {
      record[header] = values[index]?.trim();
    });
    return record;
  });
};

// Helper function to parse PDF
const parsePDF = async (buffer: ArrayBuffer): Promise<any[]> => {
  const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
  const result: any[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const text = textContent.items.map((item: any) => item.str).join(' ');
    
    // Attempt to parse structured data from text
    // This is a simplified example - in reality, you'd need more sophisticated parsing
    const lines = text.split('\n').filter(line => line.trim());
    lines.forEach(line => {
      const parts = line.split(':').map(p => p.trim());
      if (parts.length === 2) {
        result.push({ [parts[0].toLowerCase()]: parts[1] });
      }
    });
  }

  return result;
};

// Map fields based on best guess
export const mapFields = (data: any[], type: 'clients' | 'devices'): string[] => {
  if (!data || data.length === 0) return [];

  const mappings = FIELD_MAPPINGS[type];
  const sampleRow = data[0];
  const headers = Object.keys(sampleRow);
  
  return headers.map(header => {
    const headerLower = header.toLowerCase();
    
    // Find matching field
    for (const [field, aliases] of Object.entries(mappings)) {
      if (aliases.includes(headerLower)) {
        return field;
      }
    }
    
    return header;
  });
};

// Validate and transform imported data
export const validateAndTransform = (
  data: any[],
  type: 'clients' | 'devices',
  fieldMapping: Record<string, string>
): { valid: any[], invalid: any[], errors: Record<string, string[]> } => {
  const valid: any[] = [];
  const invalid: any[] = [];
  const errors: Record<string, string[]> = {};

  data.forEach((row, index) => {
    const transformed = transformRow(row, fieldMapping, type);
    const validationErrors = validateRow(transformed, type);

    if (validationErrors.length > 0) {
      invalid.push(row);
      errors[index] = validationErrors;
    } else {
      valid.push(transformed);
    }
  });

  return { valid, invalid, errors };
};

// Transform a single row based on field mapping
const transformRow = (row: any, fieldMapping: Record<string, string>, type: 'clients' | 'devices'): any => {
  const transformed: any = {
    id: uuidv4(),
    createdAt: new Date().toISOString()
  };

  if (type === 'clients') {
    transformed.clientCode = `ESL-${Math.floor(1000 + Math.random() * 9000)}`;
    transformed.isInactive = false;
  }

  Object.entries(fieldMapping).forEach(([sourceField, targetField]) => {
    if (row[sourceField] !== undefined) {
      transformed[targetField] = row[sourceField];
    }
  });

  return transformed;
};

// Validate a single row
const validateRow = (row: any, type: 'clients' | 'devices'): string[] => {
  const errors: string[] = [];

  if (type === 'clients') {
    if (!row.name) {
      errors.push('Nome cliente mancante');
    }
    if (row.email && !/^\S+@\S+\.\S+$/.test(row.email)) {
      errors.push('Formato email non valido');
    }
    if (row.vatNumber && !/^\d{11}$/.test(row.vatNumber)) {
      errors.push('Formato partita IVA non valido');
    }
  } else {
    if (!row.name) {
      errors.push('Nome dispositivo mancante');
    }
    if (!row.serialNumber) {
      errors.push('Numero di serie mancante');
    }
  }

  return errors;
};

// Create import log entry
export const createImportLog = (
  fileName: string,
  type: 'clients' | 'devices',
  totalRecords: number,
  validRecords: number,
  invalidRecords: number,
  errors: Record<string, string[]>
): ImportLog => {
  return {
    id: uuidv4(),
    timestamp: new Date().toISOString(),
    fileName,
    type,
    totalRecords,
    validRecords,
    invalidRecords,
    errors,
    status: invalidRecords === 0 ? 'success' : 'partial'
  };
};

// Interface for import log
export interface ImportLog {
  id: string;
  timestamp: string;
  fileName: string;
  type: 'clients' | 'devices';
  totalRecords: number;
  validRecords: number;
  invalidRecords: number;
  errors: Record<string, string[]>;
  status: 'success' | 'partial' | 'failed';
}