import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { HelpCategory, HelpSection } from '../types';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

interface TOCItem {
  title: string;
  page: number;
  level: number;
}

export const generatePDF = async (categories: HelpCategory[]) => {
  // Create new PDF document
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const margin = 20;
  
  // Table of contents items
  const tocItems: TOCItem[] = [];
  let currentPage = 1;

  // Add cover page
  addCoverPage(doc);
  currentPage++;

  // Add table of contents placeholder
  const tocStartPage = currentPage;
  doc.addPage();
  currentPage++;

  // Add content pages
  categories.forEach((category, index) => {
    // Add category title
    doc.addPage();
    currentPage++;
    
    const categoryTitle = category.title;
    tocItems.push({ title: categoryTitle, page: currentPage, level: 1 });
    
    doc.setFontSize(24);
    doc.setTextColor(66, 56, 202); // primary-600
    doc.text(categoryTitle, margin, 40);

    // Add category sections
    let yPos = 60;
    category.sections.forEach((section) => {
      if (yPos > 250) {
        doc.addPage();
        currentPage++;
        yPos = 40;
      }

      tocItems.push({ title: section.title, page: currentPage, level: 2 });
      
      doc.setFontSize(16);
      doc.setTextColor(31, 41, 55); // gray-800
      doc.text(section.title, margin, yPos);
      yPos += 10;

      // Add content
      doc.setFontSize(12);
      doc.setTextColor(75, 85, 99); // gray-600
      const contentLines = doc.splitTextToSize(section.content, pageWidth - (margin * 2));
      contentLines.forEach((line: string) => {
        if (yPos > 250) {
          doc.addPage();
          currentPage++;
          yPos = 40;
        }
        doc.text(line, margin, yPos);
        yPos += 7;
      });

      // Add examples if available
      if (section.examples && section.examples.length > 0) {
        yPos += 10;
        doc.setFontSize(14);
        doc.setTextColor(31, 41, 55);
        doc.text('Esempi:', margin, yPos);
        yPos += 10;

        doc.setFontSize(12);
        doc.setTextColor(75, 85, 99);
        section.examples.forEach((example) => {
          if (yPos > 250) {
            doc.addPage();
            currentPage++;
            yPos = 40;
          }
          doc.text(`• ${example}`, margin + 5, yPos);
          yPos += 7;
        });
      }

      // Add shortcuts if available
      if (section.shortcuts && section.shortcuts.length > 0) {
        yPos += 10;
        doc.setFontSize(14);
        doc.setTextColor(31, 41, 55);
        doc.text('Scorciatoie:', margin, yPos);
        yPos += 10;

        const shortcutData = section.shortcuts.map(shortcut => [
          shortcut.key,
          shortcut.description
        ]);

        (doc as any).autoTable({
          startY: yPos,
          head: [['Tasto', 'Descrizione']],
          body: shortcutData,
          margin: { left: margin },
          theme: 'striped',
          headStyles: { fillColor: [66, 56, 202] },
          styles: { fontSize: 10 }
        });

        yPos = (doc as any).lastAutoTable.finalY + 10;
      }

      yPos += 20;
    });
  });

  // Generate table of contents
  doc.setPage(tocStartPage);
  generateTOC(doc, tocItems);

  // Add footer with page numbers
  const totalPages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    if (i > 1) { // Skip cover page
      doc.setFontSize(10);
      doc.setTextColor(156, 163, 175); // gray-400
      doc.text(
        `Pagina ${i} di ${totalPages}`,
        pageWidth / 2,
        doc.internal.pageSize.height - 10,
        { align: 'center' }
      );
    }
  }

  // Add developer info
  addDeveloperInfo(doc);

  // Save the PDF
  doc.save('EasyLAB-25-Documentazione.pdf');
};

const addCoverPage = (doc: jsPDF) => {
  const pageWidth = doc.internal.pageSize.width;
  const pageHeight = doc.internal.pageSize.height;

  // Add gradient background
  doc.setFillColor(66, 56, 202); // primary-600
  doc.rect(0, 0, pageWidth, pageHeight, 'F');

  // Add title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(36);
  doc.text('EasyLAB 25', pageWidth / 2, pageHeight / 3, { align: 'center' });
  
  doc.setFontSize(18);
  doc.text('Documentazione Completa', pageWidth / 2, pageHeight / 3 + 20, { align: 'center' });

  // Add version and date
  doc.setFontSize(12);
  doc.text(`Versione 1.0.0`, pageWidth / 2, pageHeight / 3 + 40, { align: 'center' });
  doc.text(
    `Generato il ${format(new Date(), 'dd MMMM yyyy', { locale: it })}`,
    pageWidth / 2,
    pageHeight / 3 + 55,
    { align: 'center' }
  );

  // Add company info at bottom
  doc.setFontSize(10);
  doc.text(
    'EasySystem di Raffaele Bianchetti',
    pageWidth / 2,
    pageHeight - 40,
    { align: 'center' }
  );
  doc.text(
    'Via Bari 80, 80026 Casoria (NA)',
    pageWidth / 2,
    pageHeight - 30,
    { align: 'center' }
  );
  doc.text(
    'www.easysistem.it',
    pageWidth / 2,
    pageHeight - 20,
    { align: 'center' }
  );
};

const generateTOC = (doc: jsPDF, items: TOCItem[]) => {
  const margin = 20;
  doc.setFontSize(24);
  doc.setTextColor(66, 56, 202);
  doc.text('Indice', margin, 40);

  let yPos = 60;
  items.forEach((item) => {
    if (yPos > 250) {
      doc.addPage();
      yPos = 40;
    }

    doc.setFontSize(12);
    doc.setTextColor(31, 41, 55);
    
    const indent = item.level === 1 ? 0 : 10;
    const prefix = item.level === 1 ? '•' : '-';
    doc.text(
      `${prefix} ${item.title}`,
      margin + indent,
      yPos
    );

    // Add page number
    doc.text(
      item.page.toString(),
      doc.internal.pageSize.width - margin,
      yPos,
      { align: 'right' }
    );

    // Add dotted line
    const titleWidth = doc.getTextWidth(`${prefix} ${item.title}`);
    const pageNumWidth = doc.getTextWidth(item.page.toString());
    const dotsWidth = doc.internal.pageSize.width - margin * 2 - titleWidth - pageNumWidth - indent;
    const dots = '.'.repeat(Math.floor(dotsWidth / doc.getTextWidth('.')));
    doc.setTextColor(156, 163, 175);
    doc.text(dots, margin + indent + titleWidth, yPos);

    yPos += 10;
  });
};

const addDeveloperInfo = (doc: jsPDF) => {
  doc.addPage();
  const margin = 20;
  let yPos = 40;

  doc.setFontSize(24);
  doc.setTextColor(66, 56, 202);
  doc.text('Informazioni Sviluppatore', margin, yPos);
  yPos += 20;

  doc.setFontSize(12);
  doc.setTextColor(31, 41, 55);

  const developerInfo = [
    ['Azienda', 'EasySystem di Raffaele Bianchetti'],
    ['Indirizzo', 'Via Bari 80, 80026 Casoria (NA)'],
    ['Email', 'info@easysistem.it'],
    ['Telefono', '+39 081 18557973'],
    ['Sito Web', 'www.easysistem.it'],
    ['P.IVA', '04118710617']
  ];

  (doc as any).autoTable({
    startY: yPos,
    head: [['Campo', 'Valore']],
    body: developerInfo,
    margin: { left: margin },
    theme: 'striped',
    headStyles: { fillColor: [66, 56, 202] },
    styles: { fontSize: 10 }
  });

  yPos = (doc as any).lastAutoTable.finalY + 20;

  // Add technical stack
  doc.setFontSize(16);
  doc.setTextColor(31, 41, 55);
  doc.text('Stack Tecnologico', margin, yPos);
  yPos += 10;

  const technologies = [
    'React 18',
    'TypeScript',
    'Tailwind CSS',
    'Vite',
    'Node.js'
  ];

  doc.setFontSize(12);
  doc.setTextColor(75, 85, 99);
  technologies.forEach(tech => {
    doc.text(`• ${tech}`, margin + 5, yPos);
    yPos += 7;
  });
};