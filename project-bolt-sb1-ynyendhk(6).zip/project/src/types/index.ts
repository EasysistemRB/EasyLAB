// Types for settings
export interface SystemSettings {
  companyName: string;
  companyLogo?: string;
  companyAddress: string;
  companyCity: string;
  companyPostalCode: string;
  companyPhone: string;
  companyEmail: string;
  companyWebsite: string;
  vatNumber: string;
  fiscalCode: string;
  defaultPasswordExpiry: number; // days
  enableWhatsApp: boolean;
  whatsAppApiKey?: string;
  whatsAppBusinessId?: string;
  whatsAppPhoneNumberId?: string;
  whatsAppAccessToken?: string;
  appointmentReminderHours?: number; // hours before appointment to send reminder
  backupFrequency: 'daily' | 'weekly' | 'monthly';
  backupTime: string;
  backupLocation: string;
  backupRetentionDays?: number;
  clientPortalUrl?: string; // Base URL for client portal
  mobileAppEnabled: boolean;
  mobileAppUrl?: string;
  mobileAppVersion?: string;
  mobileAppMinVersion?: string;
  mobileAppForceUpdate?: boolean;
  mobileAppApiKey?: string;
  mobileAppGpsTracking?: boolean;
  mobileAppOfflineMode?: boolean;
  mobileAppPhotoQuality?: 'low' | 'medium' | 'high';
  mobileAppMaxPhotoSize?: number; // MB
  mobileAppSyncInterval?: number; // minutes
  mobileAppPushNotifications?: boolean;
}

export interface Device {
  id: string;
  clientId: string;
  locationId: string;
  name: string;
  type?: string;
  brand: string;
  model: string;
  serialNumber: string;
  registrationNumber?: string;
  hasWarranty?: boolean;
  warrantyExpiry?: string;
  supportStatus: 'active' | 'suspended' | 'expired';
  notes?: string;
  cashRegisterType?: 'telemetria_epson' | 'custom';
  connectionType?: 'lan' | 'wifi' | 'rs232' | 'usb';
  ipAddress?: string;
  port?: string;
  comPort?: string;
  baudRate?: string;
  usbPort?: string;
  verificationDate?: string;
}

export interface HelpCategory {
  id: string;
  title: string;
  icon: string;
  sections: HelpSection[];
}

export interface HelpSection {
  id: string;
  title: string;
  content: string;
  examples?: string[];
  images?: string[];
  shortcuts?: { key: string; description: string }[];
  version?: string;
  date?: string;
}