import React from 'react';
import { FileSpreadsheet, FileText, FileCode, File as FilePdf, CheckCircle, AlertTriangle, XCircle, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { ImportLog as ImportLogType } from '../utils/importUtils';

interface ImportLogProps {
  logs: ImportLogType[];
}

const ImportLog: React.FC<ImportLogProps> = ({ logs }) => {
  const getFileIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'xlsx':
      case 'xls':
        return <FileSpreadsheet className="h-5 w-5 text-green-600" />;
      case 'csv':
      case 'txt':
      case 'dat':
        return <FileText className="h-5 w-5 text-blue-600" />;
      case 'xml':
        return <FileCode className="h-5 w-5 text-purple-600" />;
      case 'pdf':
        return <FilePdf className="h-5 w-5 text-red-600" />;
      default:
        return <FileText className="h-5 w-5 text-gray-600" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'partial':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-100 text-green-800';
      case 'partial':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">Registro Importazioni</h2>
      </div>

      <div className="divide-y divide-gray-200">
        {logs.length > 0 ? (
          logs.map((log) => (
            <div key={log.id} className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  {getFileIcon(log.fileName)}
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">{log.fileName}</h3>
                    <p className="text-xs text-gray-500">
                      {format(new Date(log.timestamp), 'PPpp', { locale: it })}
                    </p>
                    <div className="mt-2 flex items-center space-x-4">
                      <span className="text-xs text-gray-500">
                        Tipo: {log.type === 'clients' ? 'Clienti' : 'Dispositivi'}
                      </span>
                      <span className="text-xs text-gray-500">
                        Totale: {log.totalRecords}
                      </span>
                      <span className="text-xs text-green-600">
                        Validi: {log.validRecords}
                      </span>
                      {log.invalidRecords > 0 && (
                        <span className="text-xs text-red-600">
                          Non validi: {log.invalidRecords}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(log.status)}`}>
                    {getStatusIcon(log.status)}
                    <span className="ml-1">
                      {log.status === 'success' ? 'Completato' :
                       log.status === 'partial' ? 'Parziale' : 'Fallito'}
                    </span>
                  </span>
                </div>
              </div>

              {Object.keys(log.errors).length > 0 && (
                <div className="mt-4">
                  <details className="text-sm">
                    <summary className="text-red-600 cursor-pointer">
                      Mostra errori ({Object.keys(log.errors).length} record)
                    </summary>
                    <div className="mt-2 pl-4 text-red-600">
                      {Object.entries(log.errors).map(([index, errors]) => (
                        <div key={index} className="mb-2">
                          <p>Record #{parseInt(index) + 1}:</p>
                          <ul className="list-disc list-inside ml-4">
                            {errors.map((error, i) => (
                              <li key={i}>{error}</li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </details>
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="p-6 text-center text-gray-500">
            Nessuna importazione registrata
          </div>
        )}
      </div>
    </div>
  );
};

export default ImportLog;