import React, { useState } from 'react';
import { File, FilePlus, Trash2, Download, Eye, FileText, File as FilePdf, ImageIcon, Video, FileArchive, File as FileIcon, ExternalLink, Upload, Info, CheckCircle2 } from 'lucide-react';
import { Client, SharedFile } from '../types';
import LoadingSpinner from './LoadingSpinner';

interface SharedFilesManagerProps {
  client: Client;
  onAddFiles?: (files: SharedFile[]) => Promise<void>;
  onDeleteFile?: (fileId: string) => Promise<void>;
  isAdmin?: boolean;
}

const SharedFilesManager: React.FC<SharedFilesManagerProps> = ({
  client,
  onAddFiles,
  onDeleteFile,
  isAdmin = false
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  // Get file icon based on file type
  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) {
      return <FilePdf className="h-5 w-5 text-red-500" />;
    } else if (fileType.includes('image')) {
      return <ImageIcon className="h-5 w-5 text-green-500" />;
    } else if (fileType.includes('video')) {
      return <Video className="h-5 w-5 text-blue-500" />;
    } else if (fileType.includes('zip') || fileType.includes('rar') || fileType.includes('tar')) {
      return <FileArchive className="h-5 w-5 text-yellow-500" />;
    } else if (fileType.includes('text') || fileType.includes('doc') || fileType.includes('word')) {
      return <FileText className="h-5 w-5 text-indigo-500" />;
    } else {
      return <FileIcon className="h-5 w-5 text-gray-500" />;
    }
  };
  
  // Format file size to human readable format
  const formatFileSize = (size: number): string => {
    if (size < 1024) {
      return size + ' B';
    } else if (size < 1024 * 1024) {
      return (size / 1024).toFixed(1) + ' KB';
    } else if (size < 1024 * 1024 * 1024) {
      return (size / (1024 * 1024)).toFixed(1) + ' MB';
    } else {
      return (size / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
    }
  };
  
  // Handle drag events
  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      setSelectedFiles(files);
      setError(null);
    }
  };
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedFiles(e.target.files);
    setError(null);
  };
  
  // Handle file upload
  const handleUpload = async () => {
    if (!selectedFiles || selectedFiles.length === 0 || !onAddFiles) {
      setError('Nessun file selezionato');
      return;
    }
    
    setIsLoading(true);
    setUploadProgress(0);
    
    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 5;
        });
      }, 100);
      
      // Convert selected files to SharedFile objects
      const sharedFiles: SharedFile[] = Array.from(selectedFiles).map(file => ({
        id: Math.random().toString(36).substring(2, 11),
        name: file.name,
        type: file.type,
        size: file.size,
        url: URL.createObjectURL(file), // In a real app, this would be the URL from server
        uploadedAt: new Date().toISOString(),
        description: '',
        isPublic: true
      }));
      
      // Call the onAddFiles handler
      await onAddFiles(sharedFiles);
      
      // Complete the progress
      setUploadProgress(100);
      clearInterval(progressInterval);
      
      // Reset the file input
      setSelectedFiles(null);
      const fileInput = document.getElementById('file-upload') as HTMLInputElement;
      if (fileInput) {
        fileInput.value = '';
      }
    } catch (err) {
      setError('Errore durante il caricamento dei file');
      console.error('Error uploading files:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Handle file deletion
  const handleDeleteFile = async (fileId: string) => {
    if (!onDeleteFile) return;
    
    setIsLoading(true);
    
    try {
      await onDeleteFile(fileId);
    } catch (err) {
      setError('Errore durante l\'eliminazione del file');
      console.error('Error deleting file:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="px-6 py-4 bg-emerald-700 text-white">
        <h2 className="text-lg font-medium flex items-center">
          <File className="mr-2 h-5 w-5" />
          {isAdmin ? 'Gestione File Condivisi' : 'File Condivisi'}
        </h2>
      </div>
      
      <div className="p-6">
        {error && (
          <div className="mb-4 bg-red-50 border-l-4 border-red-400 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}
        
        {isAdmin && (
          <div className="mb-6">
            <div 
              className={`border-2 border-dashed rounded-lg transition-all duration-200 ${
                isDragging 
                  ? 'border-emerald-500 bg-emerald-50' 
                  : 'border-gray-300 hover:border-emerald-400'
              }`}
              onDragEnter={handleDragEnter}
              onDragLeave={handleDragLeave}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
            >
              <div className="p-6">
                <div className="text-center">
                  {/* Animated upload icon */}
                  <div className="relative mx-auto w-24 h-24 mb-4">
                    <div className="absolute inset-0 bg-emerald-100 rounded-full animate-ping opacity-75"></div>
                    <div className="relative flex items-center justify-center w-full h-full bg-emerald-50 rounded-full border-2 border-emerald-200">
                      <Upload className="h-12 w-12 text-emerald-500 animate-bounce" />
                    </div>
                  </div>
                  
                  <div className="mt-4 flex text-sm leading-6 text-gray-600 justify-center">
                    <label
                      htmlFor="file-upload"
                      className="relative cursor-pointer rounded-md bg-white font-semibold text-emerald-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-emerald-600 focus-within:ring-offset-2 hover:text-emerald-500"
                    >
                      <span>Carica file</span>
                      <input
                        id="file-upload"
                        name="file-upload"
                        type="file"
                        className="sr-only"
                        multiple
                        onChange={handleFileChange}
                      />
                    </label>
                    <p className="pl-1">o trascina i file qui</p>
                  </div>
                </div>
              </div>
            </div>

            {/* File Upload Guide */}
            <div className="mt-4 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg transform rotate-1 shadow-md">
              <div className="flex">
                <div className="flex-shrink-0">
                  <Info className="h-5 w-5 text-yellow-400" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-yellow-800">Guida al caricamento file</h4>
                  <div className="mt-2 text-sm text-yellow-700">
                    <p className="font-medium mb-2">File supportati:</p>
                    <ul className="list-disc list-inside space-y-1 ml-2">
                      <li>Immagini: PNG, JPG, GIF (max 5MB)</li>
                      <li>Documenti: PDF, DOC, DOCX (max 10MB)</li>
                      <li>Archivi: ZIP, RAR (max 50MB)</li>
                    </ul>
                    <p className="mt-2 font-medium mb-2">Consigli:</p>
                    <ul className="list-disc list-inside space-y-1 ml-2">
                      <li>Usa nomi file descrittivi</li>
                      <li>Comprimi le immagini grandi</li>
                      <li>Verifica i file prima del caricamento</li>
                    </ul>
                  </div>
                  <div className="mt-3 flex items-center text-sm text-yellow-800">
                    <CheckCircle2 className="h-4 w-4 mr-1" />
                    <span>Trascina più file contemporaneamente per un caricamento multiplo</span>
                  </div>
                </div>
              </div>
            </div>
              
              {selectedFiles && selectedFiles.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">
                    File selezionati ({selectedFiles.length})
                  </h4>
                  <ul className="space-y-2 max-h-48 overflow-y-auto">
                    {Array.from(selectedFiles).map((file, index) => (
                      <li key={index} className="text-sm text-gray-600 flex items-center">
                        {getFileIcon(file.type)}
                        <span className="ml-2">{file.name}</span>
                        <span className="ml-2 text-gray-400">({formatFileSize(file.size)})</span>
                      </li>
                    ))}
                  </ul>
                  
                  <div className="mt-4 flex justify-end">
                    <button
                      onClick={handleUpload}
                      disabled={isLoading}
                      className="btn btn-primary text-sm py-2"
                    >
                      {isLoading ? (
                        <>
                          <LoadingSpinner size="sm" color="white" />
                          <span className="ml-2">Caricamento...</span>
                        </>
                      ) : (
                        <>
                          <Upload className="h-4 w-4 mr-2" />
                          Carica
                        </>
                      )}
                    </button>
                  </div>
                  
                  {isLoading && (
                    <div className="mt-2">
                      <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-emerald-600 rounded-full" 
                          style={{ width: `${uploadProgress}%` }}
                        ></div>
                      </div>
                      <p className="text-xs text-right mt-1 text-gray-500">
                        {uploadProgress}%
                      </p>
                    </div>
                  )}
                </div>
              )}
          </div>
        )}
        
        {/* Shared Files List */}
        <div className="border border-gray-200 rounded-lg overflow-hidden">
          <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
            <h3 className="text-sm font-medium text-gray-700">
              {client.sharedFiles?.length || 0} File Condivisi
            </h3>
          </div>
          
          {client.sharedFiles?.length ? (
            <ul className="divide-y divide-gray-200">
              {client.sharedFiles.map((file) => (
                <li key={file.id} className="px-4 py-3 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      {getFileIcon(file.type)}
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">{file.name}</p>
                        <div className="flex items-center text-xs text-gray-500">
                          <span>{formatFileSize(file.size)}</span>
                          <span className="mx-1">•</span>
                          <span>{new Date(file.uploadedAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <button
                        className="p-1 text-indigo-600 hover:text-indigo-900 rounded-full hover:bg-gray-100"
                        title="Visualizza"
                      >
                        <Eye className="h-5 w-5" />
                      </button>
                      
                      <a
                        href={file.url}
                        download={file.name}
                        className="p-1 text-emerald-600 hover:text-emerald-900 rounded-full hover:bg-gray-100"
                        title="Scarica"
                      >
                        <Download className="h-5 w-5" />
                      </a>
                      
                      {isAdmin && (
                        <button
                          onClick={() => handleDeleteFile(file.id)}
                          className="p-1 text-red-600 hover:text-red-900 rounded-full hover:bg-gray-100"
                          title="Elimina"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center py-8">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
              </svg>
              <p className="mt-2 text-gray-500">
                {isAdmin ? 'Nessun file condiviso con questo cliente. Carica file per condividerli.' : 'Non ci sono file condivisi al momento.'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SharedFilesManager;