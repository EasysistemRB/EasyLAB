import React, { useState, useEffect } from 'react';
import { FileSpreadsheet, FileText, FileCode, File as FilePdf, AlertTriangle, CheckCircle, X, ArrowRight, Download, Upload, Save } from 'lucide-react';
import { parseFile, mapFields, validateAndTransform, createImportLog } from '../utils/importUtils';
import LoadingSpinner from './LoadingSpinner';

interface ImportPreviewProps {
  file: File;
  type: 'clients' | 'devices';
  onImport: (data: any[], log: any) => void;
  onCancel: () => void;
}

const ImportPreview: React.FC<ImportPreviewProps> = ({
  file,
  type,
  onImport,
  onCancel
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<any[]>([]);
  const [mappedFields, setMappedFields] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<any[]>([]);
  const [validation, setValidation] = useState<{
    valid: any[];
    invalid: any[];
    errors: Record<string, string[]>;
  } | null>(null);

  // Parse file on mount
  useEffect(() => {
    const loadFile = async () => {
      try {
        setLoading(true);
        const parsedData = await parseFile(file);
        setData(parsedData);
        
        // Auto-map fields
        const suggestedFields = mapFields(parsedData, type);
        const mapping: Record<string, string> = {};
        Object.keys(parsedData[0]).forEach((key, index) => {
          mapping[key] = suggestedFields[index];
        });
        setMappedFields(mapping);
        
        // Set preview data
        setPreview(parsedData.slice(0, 5));
        
        // Validate data
        const validationResult = validateAndTransform(parsedData, type, mapping);
        setValidation(validationResult);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Errore durante il caricamento del file');
      } finally {
        setLoading(false);
      }
    };

    loadFile();
  }, [file, type]);

  // Handle field mapping change
  const handleFieldChange = (originalField: string, newField: string) => {
    setMappedFields(prev => {
      const updated = { ...prev, [originalField]: newField };
      const validationResult = validateAndTransform(data, type, updated);
      setValidation(validationResult);
      return updated;
    });
  };

  // Handle import confirmation
  const handleConfirm = () => {
    if (!validation) return;

    const log = createImportLog(
      file.name,
      type,
      data.length,
      validation.valid.length,
      validation.invalid.length,
      validation.errors
    );

    onImport(validation.valid, log);
  };

  // Get file icon based on extension
  const getFileIcon = () => {
    const ext = file.name.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'xlsx':
      case 'xls':
        return <FileSpreadsheet className="h-8 w-8 text-green-600" />;
      case 'csv':
      case 'txt':
      case 'dat':
        return <FileText className="h-8 w-8 text-blue-600" />;
      case 'xml':
        return <FileCode className="h-8 w-8 text-purple-600" />;
      case 'pdf':
        return <FilePdf className="h-8 w-8 text-red-600" />;
      default:
        return <FileText className="h-8 w-8 text-gray-600" />;
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 max-w-4xl w-full mx-4">
          <div className="flex flex-col items-center">
            <LoadingSpinner size="lg" />
            <p className="mt-4 text-gray-600">Analisi del file in corso...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 max-w-4xl w-full mx-4">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-6 w-6 text-red-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-lg font-medium text-red-800">Errore durante l'importazione</h3>
              <p className="mt-2 text-sm text-red-600">{error}</p>
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <button
              onClick={onCancel}
              className="btn btn-secondary"
            >
              Chiudi
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full mx-4 max-h-[90vh] overflow-hidden">
        <div className="px-6 py-4 bg-primary-700 text-white flex items-center justify-between">
          <div className="flex items-center">
            {getFileIcon()}
            <h2 className="text-lg font-medium ml-3">
              Anteprima Importazione - {file.name}
            </h2>
          </div>
          <button
            onClick={onCancel}
            className="p-1 hover:bg-primary-600 rounded-full"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          {/* File Info */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500">Tipo di file</p>
                <p className="font-medium">{file.type || 'N/D'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Dimensione</p>
                <p className="font-medium">{(file.size / 1024).toFixed(2)} KB</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Record trovati</p>
                <p className="font-medium">{data.length}</p>
              </div>
            </div>
          </div>

          {/* Field Mapping */}
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-4">Mappatura Campi</h3>
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Campo nel file
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Mappa a
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Esempio
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {Object.keys(mappedFields).map((field) => (
                    <tr key={field}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {field}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <select
                          className="form-select text-sm"
                          value={mappedFields[field]}
                          onChange={(e) => handleFieldChange(field, e.target.value)}
                        >
                          <option value="">Non importare</option>
                          {type === 'clients' ? (
                            <>
                              <option value="name">Nome</option>
                              <option value="email">Email</option>
                              <option value="phone">Telefono</option>
                              <option value="address">Indirizzo</option>
                              <option value="city">Città</option>
                              <option value="postalCode">CAP</option>
                              <option value="vatNumber">Partita IVA</option>
                              <option value="fiscalCode">Codice Fiscale</option>
                            </>
                          ) : (
                            <>
                              <option value="name">Nome</option>
                              <option value="type">Tipo</option>
                              <option value="brand">Marca</option>
                              <option value="model">Modello</option>
                              <option value="serialNumber">Numero di Serie</option>
                              <option value="registrationNumber">Numero di Registrazione</option>
                            </>
                          )}
                        </select>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {preview[0]?.[field] || ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Validation Results */}
          {validation && (
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-4">Risultati Validazione</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 rounded-lg p-4">
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <p className="ml-2 text-green-700 font-medium">Record Validi</p>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-green-700">
                    {validation.valid.length}
                  </p>
                </div>

                <div className="bg-red-50 rounded-lg p-4">
                  <div className="flex items-center">
                    <AlertTriangle className="h-5 w-5 text-red-400" />
                    <p className="ml-2 text-red-700 font-medium">Record Non Validi</p>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-red-700">
                    {validation.invalid.length}
                  </p>
                </div>

                <div className="bg-blue-50 rounded-lg p-4">
                  <div className="flex items-center">
                    <ArrowRight className="h-5 w-5 text-blue-400" />
                    <p className="ml-2 text-blue-700 font-medium">Totale Record</p>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-blue-700">
                    {data.length}
                  </p>
                </div>
              </div>

              {/* Error Details */}
              {validation.invalid.length > 0 && (
                <div className="mt-4 bg-red-50 rounded-lg p-4">
                  <h4 className="font-medium text-red-800 mb-2">Dettaglio Errori</h4>
                  <div className="max-h-40 overflow-y-auto">
                    {Object.entries(validation.errors).map(([index, errors]) => (
                      <div key={index} className="mb-2 text-sm">
                        <p className="text-red-700">Record #{parseInt(index) + 1}:</p>
                        <ul className="list-disc list-inside ml-4">
                          {errors.map((error, i) => (
                            <li key={i} className="text-red-600">{error}</li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between">
          <button
            onClick={onCancel}
            className="btn btn-secondary flex items-center"
          >
            <X className="h-5 w-5 mr-2" />
            Annulla
          </button>

          <div className="flex space-x-3">
            <button
              onClick={handleConfirm}
              className="btn btn-primary flex items-center"
              disabled={!validation || validation.valid.length === 0}
            >
              <Upload className="h-5 w-5 mr-2" />
              Conferma e Importa
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImportPreview;