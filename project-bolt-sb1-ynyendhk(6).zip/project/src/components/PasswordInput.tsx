import React, { useState } from 'react';
import { Eye, EyeOff, Lock } from 'lucide-react';

interface PasswordInputProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  error?: string;
  showStrength?: boolean;
  className?: string;
  required?: boolean;
}

const PasswordInput: React.FC<PasswordInputProps> = ({
  value,
  onChange,
  placeholder = '••••••',
  error,
  showStrength = false,
  className = '',
  required = false
}) => {
  const [showPassword, setShowPassword] = useState(false);
  
  // Calculate password strength
  const getPasswordStrength = (password: string): {
    score: number;
    label: string;
    color: string;
  } => {
    let score = 0;
    
    // Length check
    if (password.length >= 8) score += 1;
    if (password.length >= 12) score += 1;
    
    // Character variety checks
    if (/[A-Z]/.test(password)) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    
    // Map score to label and color
    const strengthMap = [
      { threshold: 2, label: 'Debole', color: 'bg-red-500' },
      { threshold: 3, label: 'Media', color: 'bg-yellow-500' },
      { threshold: 4, label: 'Buona', color: 'bg-green-500' },
      { threshold: 6, label: 'Eccellente', color: 'bg-blue-500' }
    ];
    
    const strength = strengthMap.find(s => score <= s.threshold) || strengthMap[strengthMap.length - 1];
    
    return {
      score,
      label: strength.label,
      color: strength.color
    };
  };

  const strength = showStrength ? getPasswordStrength(value) : null;

  return (
    <div className="space-y-1">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Lock className="h-5 w-5 text-gray-400" />
        </div>
        
        <input
          type={showPassword ? 'text' : 'password'}
          value={value}
          onChange={onChange}
          className={`macos-input pl-10 pr-10 ${error ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : ''} ${className}`}
          placeholder={placeholder}
          required={required}
        />
        
        <div className="absolute inset-y-0 right-0 flex items-center">
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="p-2 text-gray-400 hover:text-gray-600 focus:outline-none"
          >
            {showPassword ? (
              <EyeOff className="h-5 w-5" />
            ) : (
              <Eye className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>

      {error && (
        <p className="text-sm text-red-600">{error}</p>
      )}

      {showStrength && value && (
        <div className="mt-2">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-medium text-gray-500">
              Sicurezza Password: {strength?.label}
            </span>
            <span className="text-xs text-gray-400">
              {Math.round((strength?.score || 0) * 16.67)}%
            </span>
          </div>
          <div className="h-1.5 w-full bg-gray-200 rounded-full overflow-hidden">
            <div 
              className={`h-full ${strength?.color} transition-all duration-300`}
              style={{ width: `${(strength?.score || 0) * 16.67}%` }}
            />
          </div>
          <div className="mt-1 text-xs text-gray-500 space-y-1">
            <p className={`flex items-center ${/[A-Z]/.test(value) ? 'text-green-600' : 'text-gray-400'}`}>
              <span className="h-1.5 w-1.5 rounded-full mr-2 bg-current" />
              Lettera maiuscola
            </p>
            <p className={`flex items-center ${/[a-z]/.test(value) ? 'text-green-600' : 'text-gray-400'}`}>
              <span className="h-1.5 w-1.5 rounded-full mr-2 bg-current" />
              Lettera minuscola
            </p>
            <p className={`flex items-center ${/[0-9]/.test(value) ? 'text-green-600' : 'text-gray-400'}`}>
              <span className="h-1.5 w-1.5 rounded-full mr-2 bg-current" />
              Numero
            </p>
            <p className={`flex items-center ${/[^A-Za-z0-9]/.test(value) ? 'text-green-600' : 'text-gray-400'}`}>
              <span className="h-1.5 w-1.5 rounded-full mr-2 bg-current" />
              Carattere speciale
            </p>
            <p className={`flex items-center ${value.length >= 8 ? 'text-green-600' : 'text-gray-400'}`}>
              <span className="h-1.5 w-1.5 rounded-full mr-2 bg-current" />
              Minimo 8 caratteri
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default PasswordInput;