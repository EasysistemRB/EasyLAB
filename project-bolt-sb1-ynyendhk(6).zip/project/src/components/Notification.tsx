import React from 'react';
import { X, Info, AlertTriangle, CheckCircle, AlertCircle } from 'lucide-react';
import { Notification as NotificationType } from '../types';

interface NotificationProps {
  notification: NotificationType;
  onClose?: () => void;
  onClick?: () => void;
}

const NotificationComponent: React.FC<NotificationProps> = ({ notification, onClose, onClick }) => {
  const { type, title, message, isRead } = notification;
  
  const typeClasses = {
    info: 'bg-blue-50 border-blue-400 text-blue-800',
    warning: 'bg-yellow-50 border-yellow-400 text-yellow-800',
    error: 'bg-red-50 border-red-400 text-red-800',
    success: 'bg-green-50 border-green-400 text-green-800',
  };

  const typeIcons = {
    info: <Info className="w-5 h-5 text-blue-500" />,
    warning: <AlertTriangle className="w-5 h-5 text-yellow-500" />,
    error: <AlertCircle className="w-5 h-5 text-red-500" />,
    success: <CheckCircle className="w-5 h-5 text-green-500" />,
  };

  const handleClick = () => {
    if (onClick) onClick();
  };

  return (
    <div 
      className={`border-l-4 p-4 shadow-sm mb-3 relative ${typeClasses[type]} ${!isRead ? 'font-medium' : ''}`}
      onClick={handleClick}
    >
      <div className="flex items-start">
        <div className="mr-3 mt-0.5">
          {typeIcons[type]}
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-medium">{title}</h3>
          <p className="text-sm mt-1">{message}</p>
          <p className="text-xs mt-1 opacity-75">
            {new Date(notification.createdAt).toLocaleString()}
          </p>
        </div>
        {onClose && (
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="rounded-full p-1 hover:bg-gray-200 transition-colors duration-150"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      {!isRead && (
        <div className="absolute top-2 right-2 w-2 h-2 bg-blue-500 rounded-full"></div>
      )}
    </div>
  );
};

export default NotificationComponent;