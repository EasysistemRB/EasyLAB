import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Calendar, TicketCheck, User, Menu, X, LogOut, 
  FileText, LayoutGrid, Bell
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Logo from './Logo';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import TopbarWidgets from './TopbarWidgets';
import NotificationCenter from './NotificationCenter';
import HelpSystem from './HelpSystem';

interface ClientLayoutProps {
  children: React.ReactNode;
}

const ClientLayout: React.FC<ClientLayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { logout, state } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = state;

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navigation = [
    { name: 'Dashboard', href: '/client', icon: LayoutGrid },
    { name: 'I Miei Appuntamenti', href: '/client/appointments', icon: Calendar },
    { name: 'I Miei Ticket', href: '/client/tickets', icon: TicketCheck },
    { name: 'Il Mio Profilo', href: '/client/profile', icon: User },
    { name: 'Documenti', href: '/client/documents', icon: FileText },
  ];

  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };

  const today = format(new Date(), 'EEEE d MMMM yyyy', { locale: it });

  return (
    <div className="h-screen flex overflow-hidden bg-gray-100">
      {/* Mobile sidebar */}
      <div
        className={`fixed inset-0 z-40 flex md:hidden ${sidebarOpen ? 'block' : 'hidden'}`}
        role="dialog"
        aria-modal="true"
      >
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75" aria-hidden="true" onClick={toggleSidebar}></div>
        
        <div className="relative flex-1 flex flex-col max-w-xs w-full bg-secondary-800 transition-all duration-300 ease-in-out">
          <div className="absolute top-0 right-0 -mr-12 pt-2">
            <button
              type="button"
              className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              onClick={toggleSidebar}
            >
              <span className="sr-only">Chiudi sidebar</span>
              <X className="h-6 w-6 text-white" aria-hidden="true" />
            </button>
          </div>
          
          <div className="pt-5 pb-4 flex flex-col h-full">
            <div className="flex-shrink-0 flex items-center px-4">
              <Logo size="md" withText={true} />
            </div>
            
            <div className="mt-5 flex-1 overflow-y-auto">
              <div className="px-4 py-3 text-sm font-medium text-secondary-200">
                Benvenuto, {user?.name || 'Cliente'}
              </div>
              <div className="px-4 py-1 text-xs text-secondary-300">
                {today}
              </div>
              <nav className="mt-3 px-2 space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                        isActive(item.href)
                          ? 'bg-secondary-900 text-white'
                          : 'text-secondary-100 hover:bg-secondary-700'
                      }`}
                      onClick={() => setSidebarOpen(false)}
                    >
                      <Icon
                        className={`mr-3 h-6 w-6 ${
                          isActive(item.href) ? 'text-secondary-300' : 'text-secondary-300'
                        }`}
                        aria-hidden="true"
                      />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </div>
            
            <div className="flex-shrink-0 flex border-t border-secondary-700 p-4">
              <button
                onClick={handleLogout}
                className="flex-shrink-0 group block w-full flex items-center text-secondary-200 hover:text-white"
              >
                <div className="flex items-center">
                  <div className="mr-3 h-9 w-9 rounded-full bg-secondary-700 flex items-center justify-center">
                    <LogOut className="h-5 w-5 text-secondary-300" aria-hidden="true" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium">Logout</p>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Desktop sidebar */}
      <div className="hidden md:flex md:flex-shrink-0">
        <div className="flex flex-col w-64">
          <div className="flex flex-col h-0 flex-1 bg-secondary-800">
            <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
              <div className="flex-shrink-0 flex items-center px-4">
                <Logo size="md" withText={true} />
              </div>
              <div className="mt-3 px-4 py-3 text-sm font-medium text-secondary-200">
                Benvenuto, {user?.name || 'Cliente'}
              </div>
              <div className="px-4 py-1 text-xs text-secondary-300">
                {today}
              </div>
              <nav className="mt-3 flex-1 px-2 space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                        isActive(item.href)
                          ? 'bg-secondary-900 text-white'
                          : 'text-secondary-100 hover:bg-secondary-700'
                      }`}
                    >
                      <Icon
                        className={`mr-3 h-6 w-6 ${
                          isActive(item.href) ? 'text-secondary-300' : 'text-secondary-300'
                        }`}
                        aria-hidden="true"
                      />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </div>
            <div className="flex-shrink-0 flex border-t border-secondary-700 p-4">
              <button
                onClick={handleLogout}
                className="flex-shrink-0 group block w-full flex items-center text-secondary-200 hover:text-white"
              >
                <div className="flex items-center">
                  <div className="mr-3 h-9 w-9 rounded-full bg-secondary-700 flex items-center justify-center">
                    <LogOut className="h-5 w-5 text-secondary-300" aria-hidden="true" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium">Logout</p>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow">
          <button
            type="button"
            className="px-4 border-r border-gray-200 text-gray-500 md:hidden"
            onClick={toggleSidebar}
          >
            <span className="sr-only">Open sidebar</span>
            <Menu className="h-6 w-6" aria-hidden="true" />
          </button>
          
          <div className="flex-1 px-4 flex items-center justify-between">
            <div className="flex-1 flex">
              <h1 className="text-lg font-medium text-gray-700 hidden md:block">
                EasyLAB 25 - Area Cliente
              </h1>
            </div>
            
            <div className="ml-4 flex items-center md:ml-6">
              <TopbarWidgets />
              
              <NotificationCenter />
              
              <HelpSystem />
              
              <div className="ml-3 relative">
                <div>
                  <button
                    type="button"
                    className="max-w-xs bg-white flex items-center text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary-500"
                    id="user-menu"
                    aria-expanded="false"
                    aria-haspopup="true"
                  >
                    <span className="sr-only">Open user menu</span>
                    <div className="h-8 w-8 rounded-full bg-secondary-600 flex items-center justify-center text-white">
                      {user?.name?.charAt(0) || 'C'}
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          {children}
        </main>
      </div>
    </div>
  );
};

export default ClientLayout;