import React from 'react';
import { Monitor, Cpu, Code, Terminal, Database } from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  animated?: boolean;
  withText?: boolean;
  version?: string; 
  centered?: boolean;
}

const Logo: React.FC<LogoProps> = ({ 
  size = 'md', 
  animated = false, 
  withText = true,
  version = '1.1.0',
  centered = false
}) => {
  const sizeClasses = {
    sm: 'text-xl',
    md: 'text-3xl',
    lg: 'text-6xl',
  };

  const logoSize = {
    sm: 20,
    md: 32,
    lg: 64,
  };

  return (
    <div className={`flex items-center ${withText ? 'space-x-6' : ''} ${centered ? 'flex-col text-center' : ''}`}>
      <div className={`rounded-lg p-4 bg-gradient-to-br from-primary-600 to-primary-700 text-white ${animated ? 'logo-animation' : ''} relative shadow-lg`}>
        {/* Main icon */}
        <Monitor size={logoSize[size]} className="stroke-white relative z-10" />
        
        {/* Decorative elements */}
        <div className="absolute -bottom-2 -right-2 bg-secondary-600 rounded-lg p-2 shadow-md">
          <Code size={logoSize[size] * 0.5} className="stroke-white" />
        </div>
        
        <div className="absolute -top-2 -right-2 bg-accent-600 rounded-lg p-2 shadow-md">
          <Cpu size={logoSize[size] * 0.4} className="stroke-white" />
        </div>
        
        <div className="absolute -bottom-2 -left-2 bg-green-600 rounded-lg p-2 shadow-md">
          <Database size={logoSize[size] * 0.4} className="stroke-white" />
        </div>
        
        {/* Background glow effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-purple-500/20 rounded-lg filter blur-xl"></div>
      </div>
      
      {withText && (
        <div className={`${centered ? 'mt-6 text-center' : ''}`}>
          <h1 className={`font-bold text-primary-800 ${sizeClasses[size]}`}>
            Easy<span className="text-secondary-600">LAB</span>
            <span className="text-accent-600"> 25</span>
          </h1>
          <p className="text-xs text-gray-500">v{version}</p>
        </div>
      )}
    </div>
  );
};

export default Logo;