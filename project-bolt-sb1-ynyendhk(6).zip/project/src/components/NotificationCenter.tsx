import React, { useState, useEffect } from 'react';
import { Bell, X, CheckCheck, Calendar, AlertCircle } from 'lucide-react';
import { useData } from '../context/DataContext';
import NotificationComponent from './Notification';

const NotificationCenter: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { state, markNotificationRead, deleteNotification, checkUpcomingAppointments } = useData();
  
  const { notifications } = state;
  const unreadCount = notifications.filter(n => !n.isRead).length;

  const toggleNotifications = () => {
    setIsOpen(!isOpen);
  };

  const handleClickNotification = (id: string) => {
    markNotificationRead(id);
  };

  const handleDeleteNotification = (id: string) => {
    deleteNotification(id);
  };

  const markAllAsRead = () => {
    notifications.forEach(notification => {
      if (!notification.isRead) {
        markNotificationRead(notification.id);
      }
    });
  };

  // Check for appointment notifications
  const handleCheckAppointments = async () => {
    setIsLoading(true);
    try {
      await checkUpcomingAppointments();
    } catch (error) {
      console.error("Error checking appointments:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Check for appointment notifications on mount
  useEffect(() => {
    checkUpcomingAppointments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="relative">
      <button
        onClick={toggleNotifications}
        className="relative rounded-full p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
      >
        <Bell className="h-6 w-6" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-accent-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-lg shadow-lg overflow-hidden z-10 border border-gray-200">
          <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">Notifiche</h3>
            <div className="flex space-x-2">
              <button 
                onClick={handleCheckAppointments}
                className="text-sm text-primary-600 hover:text-primary-800 flex items-center"
                title="Controlla appuntamenti in scadenza"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="h-4 w-4 rounded-full border-2 border-primary-600 border-t-transparent animate-spin mr-1"></span>
                ) : (
                  <Calendar className="h-4 w-4 mr-1" />
                )}
                <span className="hidden sm:inline">Controlla</span>
              </button>
              <button 
                onClick={markAllAsRead}
                className="text-sm text-primary-600 hover:text-primary-800 flex items-center"
                title="Segna tutte come lette"
              >
                <CheckCheck className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">Tutto letto</span>
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="rounded-full p-1 hover:bg-gray-200 text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>
          
          <div className="max-h-80 overflow-y-auto p-2">
            {notifications.length === 0 ? (
              <p className="text-center py-6 text-gray-500">Nessuna notifica</p>
            ) : (
              notifications
                .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                .map(notification => (
                  <NotificationComponent
                    key={notification.id}
                    notification={notification}
                    onClose={() => handleDeleteNotification(notification.id)}
                    onClick={() => handleClickNotification(notification.id)}
                  />
                ))
            )}
          </div>
          
          <div className="bg-gray-50 px-4 py-3 text-right text-xs text-gray-500 border-t border-gray-200">
            Totale: {notifications.length} notifiche
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationCenter;