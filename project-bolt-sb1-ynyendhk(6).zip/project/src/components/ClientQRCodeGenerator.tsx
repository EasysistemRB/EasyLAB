import React, { useState } from 'react';
import { QrCode, Download, Share2, Copy, CheckCircle } from 'lucide-react';
import { Client } from '../types';
import { generateClientQRData } from '../utils/clientUtils';
import { QRCodeSVG } from 'qrcode.react';

interface ClientQRCodeGeneratorProps {
  client: Client;
  size?: number;
  includeDetails?: boolean;
}

const ClientQRCodeGenerator: React.FC<ClientQRCodeGeneratorProps> = ({
  client,
  size = 200,
  includeDetails = true
}) => {
  const [copied, setCopied] = useState(false);
  
  // Generate the QR code data
  const qrCodeData = generateClientQRData(client);
  
  // Handle QR code download
  const handleDownload = () => {
    const canvas = document.getElementById('client-qrcode-canvas') as HTMLCanvasElement;
    if (!canvas) return;
    
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `${client.clientCode}-qrcode.png`;
    link.href = url;
    link.click();
  };
  
  // Copy client code to clipboard
  const copyClientCode = () => {
    navigator.clipboard.writeText(client.clientCode).then(
      () => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      },
      (err) => console.error('Could not copy text: ', err)
    );
  };

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="px-6 py-4 bg-blue-600 text-white">
        <h2 className="text-lg font-medium flex items-center">
          <QrCode className="mr-2 h-5 w-5" />
          QR Code Cliente
        </h2>
      </div>
      
      <div className="p-6">
        <div className="flex flex-col md:flex-row items-center">
          <div className="mb-6 md:mb-0 md:mr-8 flex flex-col items-center">
            <div className="bg-white p-3 rounded-lg border-2 border-blue-100 shadow-sm">
              <QRCodeSVG
                id="client-qrcode-canvas"
                value={qrCodeData}
                size={size}
                bgColor={"#ffffff"}
                fgColor={"#000000"}
                level={"H"}
                includeMargin={true}
              />
            </div>
            
            <div className="mt-4 flex space-x-2">
              <button
                onClick={handleDownload}
                className="p-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 flex items-center"
                title="Scarica QR Code"
              >
                <Download className="h-5 w-5" />
              </button>
              
              <button
                onClick={copyClientCode}
                className="p-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 flex items-center"
                title="Copia codice cliente"
              >
                {copied ? (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                ) : (
                  <Copy className="h-5 w-5" />
                )}
              </button>
              
              <button
                className="p-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 flex items-center"
                title="Condividi QR Code"
              >
                <Share2 className="h-5 w-5" />
              </button>
            </div>
          </div>
          
          {includeDetails && (
            <div className="border-t md:border-t-0 md:border-l border-gray-200 md:pl-8 pt-6 md:pt-0">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Informazioni Codice</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Codice Cliente</h4>
                  <p className="text-lg font-bold text-blue-700">{client.clientCode}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Nome Cliente</h4>
                  <p className="text-md">{client.name}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Utilizzo QR Code</h4>
                  <ul className="mt-2 text-sm text-gray-600 space-y-2">
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center text-xs mr-2 mt-0.5">1</span>
                      <span>Identificazione rapida del cliente durante gli appuntamenti</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center text-xs mr-2 mt-0.5">2</span>
                      <span>Accesso veloce alle informazioni del cliente da dispositivi mobili</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center text-xs mr-2 mt-0.5">3</span>
                      <span>Collegamento diretto ai dispositivi associati</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ClientQRCodeGenerator;