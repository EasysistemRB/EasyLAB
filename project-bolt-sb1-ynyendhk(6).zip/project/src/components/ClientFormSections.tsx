import React from 'react';
import { Building, Mail, Phone, MapPin, Globe, CreditCard, Shield, FileText, Store, UserCircle, Smartphone, Network, Wifi, Cloud, Monitor, Headphones, Mouse, Keyboard, Terminal, Package, Coffee, Layers, Folder, FileSearch, Trash2, RotateCw, Box, Briefcase, PieChart, Zap, MessageCircle, Info, Lock, Key, FileSpreadsheet, Database } from 'lucide-react';
import { Client } from '../types';
import PasswordInput from './PasswordInput';
import HelpPostIt from './HelpPostIt';

interface ClientFormSectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  helpText?: string;
}

export const ClientFormSection: React.FC<ClientFormSectionProps> = ({
  title,
  icon,
  children,
  helpText
}) => (
  <div className="macos-window mb-6">
    <div className="macos-window-header">
      <div className="flex items-center">
        {icon}
        <h2 className="text-lg font-medium text-gray-900 ml-2">{title}</h2>
      </div>
    </div>
    <div className="macos-window-content">
      {helpText && (
        <div className="mb-6">
          <HelpPostIt
            title="Suggerimento"
            content={helpText}
            color="blue"
            icon={<Info className="h-5 w-5 text-blue-700" />}
          />
        </div>
      )}
      {children}
    </div>
  </div>
);

interface FormInputProps {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  type?: string;
  icon?: React.ReactNode;
  required?: boolean;
  error?: string;
  placeholder?: string;
  options?: { value: string; label: string }[];
  helpText?: string;
}

export const FormInput: React.FC<FormInputProps> = ({
  label,
  name,
  value,
  onChange,
  type = 'text',
  icon,
  required = false,
  error,
  placeholder,
  options,
  helpText
}) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-gray-700">
      {label} {required && <span className="text-red-500">*</span>}
    </label>
    <div className="mt-1 relative">
      {icon && (
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          {icon}
        </div>
      )}
      {type === 'select' ? (
        <select
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          className={`macos-input ${icon ? 'pl-10' : ''} ${error ? 'border-red-300' : ''}`}
          required={required}
        >
          <option value="">{placeholder || 'Seleziona...'}</option>
          {options?.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      ) : type === 'password' ? (
        <PasswordInput
          value={value}
          onChange={onChange}
          error={error}
          required={required}
          showStrength={true}
          className={icon ? 'pl-10' : ''}
        />
      ) : (
        <input
          type={type}
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          className={`macos-input ${icon ? 'pl-10' : ''} ${error ? 'border-red-300' : ''}`}
          placeholder={placeholder}
          required={required}
        />
      )}
    </div>
    {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
    {helpText && <p className="mt-1 text-xs text-gray-500">{helpText}</p>}
  </div>
);

export const BasicInfoSection: React.FC<{
  formData: Partial<Client>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  errors: Record<string, string>;
}> = ({ formData, onChange, errors }) => (
  <ClientFormSection 
    title="Informazioni Base" 
    icon={<Building className="h-5 w-5 text-gray-500" />}
    helpText="Inserisci le informazioni principali del cliente. Assicurati di compilare tutti i campi obbligatori contrassegnati con *."
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <FormInput
        label="Ragione Sociale"
        name="name"
        value={formData.name || ''}
        onChange={onChange}
        icon={<Building className="h-5 w-5 text-gray-400" />}
        required
        error={errors.name}
      />
      
      <FormInput
        label="Nome Negozio/Insegna"
        name="storeName"
        value={formData.storeName || ''}
        onChange={onChange}
        icon={<Store className="h-5 w-5 text-gray-400" />}
      />
      
      <FormInput
        label="Email"
        name="email"
        type="email"
        value={formData.email || ''}
        onChange={onChange}
        icon={<Mail className="h-5 w-5 text-gray-400" />}
        error={errors.email}
      />
      
      <div className="bg-green-50 p-4 rounded-lg border border-green-200">
        <FormInput
          label="Cellulare"
          name="mobile"
          type="tel"
          value={formData.mobile || ''}
          onChange={onChange}
          icon={<Smartphone className="h-5 w-5 text-green-500" />}
          placeholder="+39 123 456 7890"
          error={errors.mobile}
          helpText="Numero utilizzato per le comunicazioni via WhatsApp"
        />
      </div>
      
      <FormInput
        label="Telefono Fisso"
        name="phone"
        type="tel"
        value={formData.phone || ''}
        onChange={onChange}
        icon={<Phone className="h-5 w-5 text-gray-400" />}
      />
      
      <FormInput
        label="Sito Web"
        name="website"
        type="url"
        value={formData.website || ''}
        onChange={onChange}
        icon={<Globe className="h-5 w-5 text-gray-400" />}
        placeholder="https://www.example.com"
      />
    </div>
  </ClientFormSection>
);

export const AddressSection: React.FC<{
  formData: Partial<Client>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  errors: Record<string, string>;
}> = ({ formData, onChange, errors }) => (
  <ClientFormSection 
    title="Indirizzo" 
    icon={<MapPin className="h-5 w-5 text-gray-500" />}
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="md:col-span-2">
        <FormInput
          label="Indirizzo"
          name="address"
          value={formData.address || ''}
          onChange={onChange}
          icon={<MapPin className="h-5 w-5 text-gray-400" />}
        />
      </div>
      
      <FormInput
        label="Città"
        name="city"
        value={formData.city || ''}
        onChange={onChange}
        icon={<Building className="h-5 w-5 text-gray-400" />}
      />
      
      <FormInput
        label="CAP"
        name="postalCode"
        value={formData.postalCode || ''}
        onChange={onChange}
        icon={<MapPin className="h-5 w-5 text-gray-400" />}
      />
    </div>
  </ClientFormSection>
);

export const FiscalSection: React.FC<{
  formData: Partial<Client>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  errors: Record<string, string>;
}> = ({ formData, onChange, errors }) => (
  <ClientFormSection 
    title="Informazioni Fiscali" 
    icon={<FileText className="h-5 w-5 text-gray-500" />}
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <FormInput
        label="Partita IVA"
        name="vatNumber"
        value={formData.vatNumber || ''}
        onChange={onChange}
        icon={<CreditCard className="h-5 w-5 text-gray-400" />}
        error={errors.vatNumber}
      />
      
      <FormInput
        label="Codice Fiscale"
        name="fiscalCode"
        value={formData.fiscalCode || ''}
        onChange={onChange}
        icon={<Shield className="h-5 w-5 text-gray-400" />}
        error={errors.fiscalCode}
      />

      {/* New Fields */}
      <FormInput
        label="Codice Univoco"
        name="sdiCode"
        value={formData.sdiCode || ''}
        onChange={onChange}
        icon={<Key className="h-5 w-5 text-gray-400" />}
        error={errors.sdiCode}
        helpText="Codice destinatario per fatturazione elettronica"
      />

      <FormInput
        label="PEC"
        name="pec"
        type="email"
        value={formData.pec || ''}
        onChange={onChange}
        icon={<Mail className="h-5 w-5 text-gray-400" />}
        error={errors.pec}
        helpText="Indirizzo PEC per comunicazioni ufficiali"
      />
      
      <FormInput
        label="Banca"
        name="bankName"
        value={formData.bankName || ''}
        onChange={onChange}
        icon={<Building className="h-5 w-5 text-gray-400" />}
      />
      
      <FormInput
        label="IBAN"
        name="bankIBAN"
        value={formData.bankIBAN || ''}
        onChange={onChange}
        icon={<CreditCard className="h-5 w-5 text-gray-400" />}
        error={errors.bankIBAN}
      />
    </div>
  </ClientFormSection>
);

export const CategorySection: React.FC<{
  formData: Partial<Client>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}> = ({ formData, onChange }) => (
  <ClientFormSection 
    title="Categoria e Tipo" 
    icon={<Folder className="h-5 w-5 text-gray-500" />}
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <FormInput
        label="Categoria"
        name="category"
        type="select"
        value={formData.category || ''}
        onChange={onChange}
        icon={<Briefcase className="h-5 w-5 text-gray-400" />}
        options={[
          { value: 'business', label: 'Azienda' },
          { value: 'retail', label: 'Negozio' },
          { value: 'professional', label: 'Libero Professionista' },
          { value: 'private', label: 'Privato' }
        ]}
      />
      
      <FormInput
        label="Tipo"
        name="type"
        type="select"
        value={formData.type || ''}
        onChange={onChange}
        icon={<UserCircle className="h-5 w-5 text-gray-400" />}
        options={[
          { value: 'standard', label: 'Standard' },
          { value: 'premium', label: 'Premium' },
          { value: 'vip', label: 'VIP' }
        ]}
      />
    </div>
  </ClientFormSection>
);

export const CommunicationSection: React.FC<{
  formData: Partial<Client>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}> = ({ formData, onChange }) => (
  <ClientFormSection 
    title="Comunicazioni" 
    icon={<MessageCircle className="h-5 w-5 text-gray-500" />}
    helpText="Configura le preferenze di comunicazione per questo cliente. L'attivazione di WhatsApp richiede un numero di cellulare valido."
  >
    <div className="space-y-4">
      <div className="flex items-center">
        <input
          type="checkbox"
          id="enableWhatsApp"
          name="enableWhatsApp"
          checked={formData.enableWhatsApp || false}
          onChange={(e) => onChange({
            target: {
              name: e.target.name,
              value: e.target.checked
            }
          } as any)}
          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
        />
        <label htmlFor="enableWhatsApp" className="ml-2 block text-sm text-gray-900">
          Abilita comunicazioni WhatsApp
        </label>
      </div>

      <div className="flex items-center">
        <input
          type="checkbox"
          id="enableEmailNotifications"
          name="enableEmailNotifications"
          checked={formData.enableEmailNotifications || false}
          onChange={(e) => onChange({
            target: {
              name: e.target.name,
              value: e.target.checked
            }
          } as any)}
          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
        />
        <label htmlFor="enableEmailNotifications" className="ml-2 block text-sm text-gray-900">
          Abilita notifiche email
        </label>
      </div>

      <div className="flex items-center">
        <input
          type="checkbox"
          id="enableSMS"
          name="enableSMS"
          checked={formData.enableSMS || false}
          onChange={(e) => onChange({
            target: {
              name: e.target.name,
              value: e.target.checked
            }
          } as any)}
          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
        />
        <label htmlFor="enableSMS" className="ml-2 block text-sm text-gray-900">
          Abilita notifiche SMS
        </label>
      </div>
    </div>
  </ClientFormSection>
);