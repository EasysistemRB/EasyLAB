import React, { useState } from 'react';
import { Client } from '../types';
import ClientCard from './ClientCard';
import { Search, Filter, Plus, Download, Upload, Grid, List } from 'lucide-react';
import LoadingSpinner from './LoadingSpinner';

interface ClientCardGridProps {
  clients: Client[];
  isLoading?: boolean;
  onDelete?: (id: string) => void;
  onShare?: (client: Client) => void;
  onExport?: (client: Client) => void;
  onAdd?: () => void;
  onImport?: () => void;
  onExportAll?: () => void;
}

const ClientCardGrid: React.FC<ClientCardGridProps> = ({
  clients,
  isLoading = false,
  onDelete,
  onShare,
  onExport,
  onAdd,
  onImport,
  onExportAll
}) => {
  const [search, setSearch] = useState('');
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [filters, setFilters] = useState({
    status: 'all',
    type: 'all',
    hasDevices: 'all'
  });

  // Filter clients
  const filteredClients = clients.filter(client => {
    // Search filter
    if (search) {
      const searchLower = search.toLowerCase();
      const matchesSearch = 
        client.name.toLowerCase().includes(searchLower) ||
        client.clientCode.toLowerCase().includes(searchLower) ||
        client.email?.toLowerCase().includes(searchLower) ||
        client.phone?.toLowerCase().includes(searchLower);
      
      if (!matchesSearch) return false;
    }

    // Status filter
    if (filters.status !== 'all') {
      if (filters.status === 'active' && client.isInactive) return false;
      if (filters.status === 'inactive' && !client.isInactive) return false;
    }

    // Type filter
    if (filters.type !== 'all' && client.type !== filters.type) return false;

    // Devices filter
    if (filters.hasDevices !== 'all') {
      const hasDevices = (client.devices?.length || 0) > 0;
      if (filters.hasDevices === 'yes' && !hasDevices) return false;
      if (filters.hasDevices === 'no' && hasDevices) return false;
    }

    return true;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Cerca clienti..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="macos-input pl-10"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-2 bg-white rounded-lg shadow-sm p-1">
            <button
              onClick={() => setView('grid')}
              className={`p-1.5 rounded ${view === 'grid' ? 'bg-primary-100 text-primary-600' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <Grid className="h-5 w-5" />
            </button>
            <button
              onClick={() => setView('list')}
              className={`p-1.5 rounded ${view === 'list' ? 'bg-primary-100 text-primary-600' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <List className="h-5 w-5" />
            </button>
          </div>

          <select
            value={filters.status}
            onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
            className="macos-input py-1.5"
          >
            <option value="all">Tutti gli stati</option>
            <option value="active">Attivi</option>
            <option value="inactive">Inattivi</option>
          </select>

          <select
            value={filters.hasDevices}
            onChange={(e) => setFilters(prev => ({ ...prev, hasDevices: e.target.value }))}
            className="macos-input py-1.5"
          >
            <option value="all">Tutti i dispositivi</option>
            <option value="yes">Con dispositivi</option>
            <option value="no">Senza dispositivi</option>
          </select>

          <div className="flex items-center space-x-2">
            {onImport && (
              <button onClick={onImport} className="macos-button flex items-center">
                <Upload className="h-4 w-4 mr-1" />
                Importa
              </button>
            )}
            
            {onExportAll && (
              <button onClick={onExportAll} className="macos-button flex items-center">
                <Download className="h-4 w-4 mr-1" />
                Esporta
              </button>
            )}
            
            {onAdd && (
              <button onClick={onAdd} className="macos-button-primary flex items-center">
                <Plus className="h-4 w-4 mr-1" />
                Nuovo Cliente
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Results count */}
      <div className="text-sm text-gray-500">
        {filteredClients.length} clienti trovati
      </div>

      {/* Grid/List View */}
      {filteredClients.length > 0 ? (
        <div className={view === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
          {filteredClients.map(client => (
            <ClientCard
              key={client.id}
              client={client}
              onDelete={onDelete}
              onShare={onShare}
              onExport={onExport}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-500">Nessun cliente trovato</p>
          {onAdd && (
            <button
              onClick={onAdd}
              className="mt-4 macos-button-primary"
            >
              Aggiungi il primo cliente
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default ClientCardGrid;