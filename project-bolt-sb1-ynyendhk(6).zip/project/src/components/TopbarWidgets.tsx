import React, { useState, useEffect } from 'react';
import { Clock, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

const TopbarWidgets: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center space-x-6 px-4 text-gray-600">
      {/* Date */}
      <div className="hidden md:flex items-center">
        <Calendar className="h-5 w-5 mr-2" />
        <span className="text-sm font-medium">
          {format(currentTime, 'EEEE d MMMM yyyy', { locale: it })}
        </span>
      </div>

      {/* Time */}
      <div className="flex items-center">
        <Clock className="h-5 w-5 mr-2" />
        <span className="text-sm font-medium">
          {format(currentTime, 'HH:mm:ss')}
        </span>
      </div>
    </div>
  );
};

export default TopbarWidgets;