import React from 'react';
import { 
  Calendar, Clock, User, Building, Phone, Mail, MapPin,
  MessageSquare, Laptop, Video, Globe, Users, FileText,
  CreditCard, Info, AlertTriangle, Smartphone
} from 'lucide-react';
import { Appointment } from '../types';
import HelpPostIt from './HelpPostIt';

interface AppointmentFormSectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  helpText?: string;
}

export const AppointmentFormSection: React.FC<AppointmentFormSectionProps> = ({
  title,
  icon,
  children,
  helpText
}) => (
  <div className="macos-window mb-6">
    <div className="macos-window-header">
      <div className="flex items-center">
        {icon}
        <h2 className="text-lg font-medium text-gray-900 ml-2">{title}</h2>
      </div>
    </div>
    <div className="macos-window-content">
      {helpText && (
        <div className="mb-6">
          <HelpPostIt
            title="Suggerimento"
            content={helpText}
            color="blue"
            icon={<Info className="h-5 w-5 text-blue-700" />}
          />
        </div>
      )}
      {children}
    </div>
  </div>
);

interface FormInputProps {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  type?: string;
  icon?: React.ReactNode;
  required?: boolean;
  error?: string;
  placeholder?: string;
  options?: { value: string; label: string }[];
  helpText?: string;
  disabled?: boolean;
}

export const FormInput: React.FC<FormInputProps> = ({
  label,
  name,
  value,
  onChange,
  type = 'text',
  icon,
  required = false,
  error,
  placeholder,
  options,
  helpText,
  disabled = false
}) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-gray-700">
      {label} {required && <span className="text-red-500">*</span>}
    </label>
    <div className="mt-1 relative">
      {icon && (
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          {icon}
        </div>
      )}
      {type === 'select' ? (
        <select
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          disabled={disabled}
          className={`macos-input ${icon ? 'pl-10' : ''} ${error ? 'border-red-300' : ''}`}
          required={required}
        >
          <option value="">{placeholder || 'Seleziona...'}</option>
          {options?.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      ) : type === 'textarea' ? (
        <textarea
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          disabled={disabled}
          className={`macos-input ${icon ? 'pl-10' : ''} ${error ? 'border-red-300' : ''}`}
          placeholder={placeholder}
          required={required}
          rows={3}
        />
      ) : (
        <input
          type={type}
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          disabled={disabled}
          className={`macos-input ${icon ? 'pl-10' : ''} ${error ? 'border-red-300' : ''}`}
          placeholder={placeholder}
          required={required}
        />
      )}
    </div>
    {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
    {helpText && <p className="mt-1 text-xs text-gray-500">{helpText}</p>}
  </div>
);

export const BasicInfoSection: React.FC<{
  formData: Partial<Appointment>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  errors: Record<string, string>;
  clients: any[];
  devices: any[];
}> = ({ formData, onChange, errors, clients, devices }) => (
  <AppointmentFormSection 
    title="Informazioni Base" 
    icon={<FileText className="h-5 w-5 text-gray-500" />}
    helpText="Inserisci le informazioni principali dell'appuntamento. Assicurati di compilare tutti i campi obbligatori contrassegnati con *."
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <FormInput
        label="Cliente"
        name="clientId"
        type="select"
        value={formData.clientId || ''}
        onChange={onChange}
        icon={<User className="h-5 w-5 text-gray-400" />}
        required
        error={errors.clientId}
        options={clients.map(client => ({
          value: client.id,
          label: `${client.name} (${client.clientCode})`
        }))}
      />
      
      <FormInput
        label="Dispositivo"
        name="deviceId"
        type="select"
        value={formData.deviceId || ''}
        onChange={onChange}
        icon={<Laptop className="h-5 w-5 text-gray-400" />}
        error={errors.deviceId}
        disabled={!formData.clientId || devices.length === 0}
        options={devices.map(device => ({
          value: device.id,
          label: `${device.name} (${device.brand} ${device.model})`
        }))}
      />
      
      <div className="md:col-span-2">
        <FormInput
          label="Titolo"
          name="title"
          value={formData.title || ''}
          onChange={onChange}
          icon={<FileText className="h-5 w-5 text-gray-400" />}
          required
          error={errors.title}
          placeholder="Es. Manutenzione Registratore di Cassa"
        />
      </div>
      
      <div className="md:col-span-2">
        <FormInput
          label="Descrizione"
          name="description"
          type="textarea"
          value={formData.description || ''}
          onChange={onChange}
          icon={<MessageSquare className="h-5 w-5 text-gray-400" />}
          placeholder="Inserisci una descrizione dettagliata..."
        />
      </div>
    </div>
  </AppointmentFormSection>
);

export const DateTimeSection: React.FC<{
  formData: Partial<Appointment>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  errors: Record<string, string>;
}> = ({ formData, onChange, errors }) => (
  <AppointmentFormSection 
    title="Data e Orario" 
    icon={<Calendar className="h-5 w-5 text-gray-500" />}
    helpText="Seleziona data e orario dell'appuntamento. Gli appuntamenti possono essere programmati solo nei giorni lavorativi tra le 9:00 e le 18:00."
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <FormInput
        label="Data"
        name="date"
        type="date"
        value={formData.date || ''}
        onChange={onChange}
        icon={<Calendar className="h-5 w-5 text-gray-400" />}
        required
        error={errors.date}
      />
      
      <div className="grid grid-cols-2 gap-4">
        <FormInput
          label="Ora Inizio"
          name="startTime"
          type="time"
          value={formData.startTime || ''}
          onChange={onChange}
          icon={<Clock className="h-5 w-5 text-gray-400" />}
          required
          error={errors.startTime}
        />
        
        <FormInput
          label="Ora Fine"
          name="endTime"
          type="time"
          value={formData.endTime || ''}
          onChange={onChange}
          icon={<Clock className="h-5 w-5 text-gray-400" />}
          required
          error={errors.endTime}
        />
      </div>
    </div>
  </AppointmentFormSection>
);

export const ContactSection: React.FC<{
  formData: Partial<Appointment>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  errors: Record<string, string>;
}> = ({ formData, onChange, errors }) => (
  <AppointmentFormSection 
    title="Contatti" 
    icon={<Users className="h-5 w-5 text-gray-500" />}
    helpText="Inserisci i dettagli di contatto per l'appuntamento. Il numero di cellulare verrà utilizzato per inviare promemoria via WhatsApp."
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <FormInput
        label="Referente"
        name="referent"
        value={formData.referent || ''}
        onChange={onChange}
        icon={<User className="h-5 w-5 text-gray-400" />}
        placeholder="Nome della persona di riferimento"
      />
      
      <div className="bg-green-50 p-4 rounded-lg border border-green-200">
        <FormInput
          label="Cellulare"
          name="referentPhone"
          type="tel"
          value={formData.referentPhone || ''}
          onChange={onChange}
          icon={<Smartphone className="h-5 w-5 text-green-500" />}
          error={errors.referentPhone}
          placeholder="+39 123 456 7890"
          helpText="Numero per comunicazioni WhatsApp"
        />
      </div>
      
      <FormInput
        label="Email"
        name="referentEmail"
        type="email"
        value={formData.referentEmail || ''}
        onChange={onChange}
        icon={<Mail className="h-5 w-5 text-gray-400" />}
        error={errors.referentEmail}
        placeholder="email@esempio.it"
      />
    </div>
  </AppointmentFormSection>
);

export const NotesSection: React.FC<{
  formData: Partial<Appointment>;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
}> = ({ formData, onChange }) => (
  <AppointmentFormSection 
    title="Note Aggiuntive" 
    icon={<Info className="h-5 w-5 text-gray-500" />}
  >
    <FormInput
      label="Note"
      name="notes"
      type="textarea"
      value={formData.notes || ''}
      onChange={onChange}
      placeholder="Inserisci eventuali note o informazioni aggiuntive..."
    />
  </AppointmentFormSection>
);