import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Building, Mail, Phone, MapPin, Globe, CreditCard, 
  Shield, FileText, ChevronRight, MessageCircle as WhatsApp,
  Laptop, Printer, Clock, AlertTriangle, CheckCircle,
  BarChart2, Calendar, TicketCheck, Share2, QrCode,
  Key, Download, Eye, Settings, Archive, Trash2
} from 'lucide-react';
import { Client, Device } from '../types';
import { format, addDays } from 'date-fns';
import { it } from 'date-fns/locale';

interface ClientCardProps {
  client: Client;
  onDelete?: (id: string) => void;
  onShare?: (client: Client) => void;
  onExport?: (client: Client) => void;
  showActions?: boolean;
}

const ClientCard: React.FC<ClientCardProps> = ({
  client,
  onDelete,
  onShare,
  onExport,
  showActions = true
}) => {
  const navigate = useNavigate();
  const [showDetails, setShowDetails] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  // Get device statistics
  const deviceStats = {
    total: client.devices?.length || 0,
    active: client.devices?.filter(d => d.supportStatus === 'active').length || 0,
    needsAttention: client.devices?.filter(d => {
      if (d.type === 'cash_register' && d.verificationDate) {
        const verificationDate = new Date(d.verificationDate);
        const expiryDate = addDays(verificationDate, 360);
        const today = new Date();
        const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        return daysUntilExpiry <= 30;
      }
      return false;
    }).length || 0
  };

  // Get device type counts
  const deviceTypeCounts = client.devices?.reduce((acc, device) => {
    acc[device.type] = (acc[device.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  // Get client status badge
  const getStatusBadge = () => {
    if (client.isInactive) {
      return (
        <span className="absolute top-3 right-3 px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">
          Inattivo
        </span>
      );
    }
    
    if (deviceStats.needsAttention > 0) {
      return (
        <span className="absolute top-3 right-3 px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full flex items-center">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Richiede Attenzione
        </span>
      );
    }

    return (
      <span className="absolute top-3 right-3 px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full flex items-center">
        <CheckCircle className="h-3 w-3 mr-1" />
        Attivo
      </span>
    );
  };

  return (
    <div 
      className="macos-card relative group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Status Badge */}
      {getStatusBadge()}

      {/* Client Info */}
      <div className="flex items-start space-x-4">
        <div className="flex-shrink-0 h-12 w-12 rounded-full bg-gradient-to-br from-primary-500 to-primary-600 flex items-center justify-center text-white text-lg font-semibold">
          {client.name.charAt(0)}
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-semibold text-gray-900 truncate">
            {client.name}
          </h3>
          <p className="text-sm text-gray-500 flex items-center">
            <Building className="h-4 w-4 mr-1" />
            {client.clientCode}
          </p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="mt-4 grid grid-cols-3 gap-4">
        <div className="text-center">
          <div className="text-2xl font-semibold text-primary-600">
            {deviceStats.total}
          </div>
          <div className="text-xs text-gray-500">Dispositivi</div>
        </div>
        
        <div className="text-center">
          <div className="text-2xl font-semibold text-green-600">
            {deviceStats.active}
          </div>
          <div className="text-xs text-gray-500">Attivi</div>
        </div>
        
        <div className="text-center">
          <div className="text-2xl font-semibold text-yellow-600">
            {deviceStats.needsAttention}
          </div>
          <div className="text-xs text-gray-500">Da Verificare</div>
        </div>
      </div>

      {/* Device Types */}
      <div className="mt-4 flex flex-wrap gap-2">
        {Object.entries(deviceTypeCounts).map(([type, count]) => {
          let Icon;
          switch (type) {
            case 'cash_register':
              Icon = CreditCard;
              break;
            case 'printer':
              Icon = Printer;
              break;
            default:
              Icon = Laptop;
          }
          
          return (
            <div 
              key={type}
              className="px-2 py-1 bg-gray-100 rounded-full text-xs font-medium text-gray-700 flex items-center"
            >
              <Icon className="h-3 w-3 mr-1" />
              {count} {type.replace('_', ' ')}
            </div>
          );
        })}
      </div>

      {/* Contact Info */}
      <div className="mt-4 space-y-2">
        {client.email && (
          <a 
            href={`mailto:${client.email}`}
            className="text-sm text-gray-600 hover:text-primary-600 flex items-center"
          >
            <Mail className="h-4 w-4 mr-2" />
            {client.email}
          </a>
        )}
        
        {client.phone && (
          <a 
            href={`tel:${client.phone}`}
            className="text-sm text-gray-600 hover:text-primary-600 flex items-center"
          >
            <Phone className="h-4 w-4 mr-2" />
            {client.phone}
          </a>
        )}
        
        {client.address && (
          <p className="text-sm text-gray-600 flex items-start">
            <MapPin className="h-4 w-4 mr-2 mt-1" />
            <span>{client.address}<br />{client.city} {client.postalCode}</span>
          </p>
        )}
      </div>

      {/* Fiscal Info */}
      {showDetails && (
        <div className="mt-4 pt-4 border-t border-gray-200 space-y-2">
          {client.vatNumber && (
            <p className="text-sm text-gray-600 flex items-center">
              <CreditCard className="h-4 w-4 mr-2" />
              P.IVA: {client.vatNumber}
            </p>
          )}
          
          {client.fiscalCode && (
            <p className="text-sm text-gray-600 flex items-center">
              <Shield className="h-4 w-4 mr-2" />
              C.F.: {client.fiscalCode}
            </p>
          )}
          
          {client.website && (
            <a 
              href={client.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-gray-600 hover:text-primary-600 flex items-center"
            >
              <Globe className="h-4 w-4 mr-2" />
              {client.website}
            </a>
          )}
        </div>
      )}

      {/* Action Buttons */}
      {showActions && (
        <div className={`mt-4 pt-4 border-t border-gray-200 flex items-center justify-between transition-opacity duration-200 ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}>
          <div className="flex space-x-2">
            <button
              onClick={() => navigate(`/admin/clients/${client.id}`)}
              className="macos-button flex items-center"
              title="Visualizza dettagli"
            >
              <Eye className="h-4 w-4" />
            </button>
            
            <button
              onClick={() => navigate(`/admin/clients/${client.id}/edit`)}
              className="macos-button flex items-center"
              title="Modifica"
            >
              <Settings className="h-4 w-4" />
            </button>
            
            {client.phone && (
              <button
                className="macos-button flex items-center text-green-600 hover:text-green-700"
                title="WhatsApp"
              >
                <WhatsApp className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="flex space-x-2">
            <button
              onClick={() => onShare?.(client)}
              className="macos-button flex items-center"
              title="Condividi"
            >
              <Share2 className="h-4 w-4" />
            </button>
            
            <button
              onClick={() => onExport?.(client)}
              className="macos-button flex items-center"
              title="Esporta"
            >
              <Download className="h-4 w-4" />
            </button>
            
            {onDelete && (
              <button
                onClick={() => onDelete(client.id)}
                className="macos-button text-red-600 hover:text-red-700 flex items-center"
                title="Elimina"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Toggle Details */}
      <button
        onClick={() => setShowDetails(!showDetails)}
        className="absolute bottom-2 right-2 p-1 text-gray-400 hover:text-gray-600"
      >
        <ChevronRight className={`h-4 w-4 transform transition-transform ${showDetails ? 'rotate-90' : ''}`} />
      </button>
    </div>
  );
};

export default ClientCard;