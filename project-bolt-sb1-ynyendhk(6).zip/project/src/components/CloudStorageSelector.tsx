import React, { useState } from 'react';
import { CloudProvider, getCloudStorageIcon } from '../utils/cloudUtils';
import { Cloud, Check, X, Settings, Link, Key } from 'lucide-react';
import LoadingSpinner from './LoadingSpinner';

interface CloudStorageSelectorProps {
  onSelect: (provider: CloudProvider, config: any) => void;
  onCancel: () => void;
}

const CloudStorageSelector: React.FC<CloudStorageSelectorProps> = ({
  onSelect,
  onCancel
}) => {
  const [selectedProvider, setSelectedProvider] = useState<CloudProvider | null>(null);
  const [credentials, setCredentials] = useState<Record<string, string>>({});
  const [isConfiguring, setIsConfiguring] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const providers = [
    { id: CloudProvider.GoogleDrive, name: 'Google Drive' },
    { id: CloudProvider.OneDrive, name: 'OneDrive' },
    { id: CloudProvider.iCloud, name: 'iCloud' },
    { id: CloudProvider.S3, name: 'Amazon S3' },
    { id: CloudProvider.Azure, name: 'Azure Blob Storage' }
  ];

  const handleProviderSelect = (provider: CloudProvider) => {
    setSelectedProvider(provider);
    setError(null);
  };

  const handleCredentialChange = (key: string, value: string) => {
    setCredentials(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSubmit = async () => {
    setIsConfiguring(true);
    setError(null);

    try {
      // Validate credentials
      if (!selectedProvider) {
        throw new Error('Seleziona un provider');
      }

      // Call onSelect with provider and credentials
      onSelect(selectedProvider, credentials);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Errore durante la configurazione');
    } finally {
      setIsConfiguring(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-xl overflow-hidden">
      <div className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <h3 className="text-lg font-medium flex items-center">
          <Cloud className="h-5 w-5 mr-2" />
          Seleziona Cloud Storage
        </h3>
      </div>

      <div className="p-6">
        {!selectedProvider ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {providers.map(provider => (
              <button
                key={provider.id}
                onClick={() => handleProviderSelect(provider.id)}
                className="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <div className="flex flex-col items-center">
                  <img 
                    src={getCloudStorageIcon(provider.id)} 
                    alt={provider.name}
                    className="h-12 w-12 mb-2"
                  />
                  <span className="text-sm font-medium text-gray-900">{provider.name}</span>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <img 
                  src={getCloudStorageIcon(selectedProvider)} 
                  alt={providers.find(p => p.id === selectedProvider)?.name}
                  className="h-8 w-8 mr-2"
                />
                <h4 className="text-lg font-medium text-gray-900">
                  {providers.find(p => p.id === selectedProvider)?.name}
                </h4>
              </div>
              <button
                onClick={() => setSelectedProvider(null)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4">
              {selectedProvider === CloudProvider.GoogleDrive && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Client ID
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <Key className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                        value={credentials.clientId || ''}
                        onChange={e => handleCredentialChange('clientId', e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Client Secret
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <Key className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="password"
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                        value={credentials.clientSecret || ''}
                        onChange={e => handleCredentialChange('clientSecret', e.target.value)}
                      />
                    </div>
                  </div>
                </>
              )}

              {selectedProvider === CloudProvider.S3 && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Access Key ID
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <Key className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                        value={credentials.accessKeyId || ''}
                        onChange={e => handleCredentialChange('accessKeyId', e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Secret Access Key
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <Key className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="password"
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                        value={credentials.secretAccessKey || ''}
                        onChange={e => handleCredentialChange('secretAccessKey', e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Bucket Name
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <Cloud className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                        value={credentials.bucket || ''}
                        onChange={e => handleCredentialChange('bucket', e.target.value)}
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Add similar credential fields for other providers */}
            </div>

            {error && (
              <div className="rounded-md bg-red-50 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <X className="h-5 w-5 text-red-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">{error}</h3>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end space-x-3">
              <button
                onClick={onCancel}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Annulla
              </button>
              <button
                onClick={handleSubmit}
                disabled={isConfiguring}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {isConfiguring ? (
                  <LoadingSpinner size="sm" color="white" />
                ) : (
                  'Configura'
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CloudStorageSelector;