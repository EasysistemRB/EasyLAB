import React from 'react';
import { Info, X } from 'lucide-react';

interface HelpPostItProps {
  title: string;
  content: string;
  color?: 'yellow' | 'blue' | 'green' | 'pink';
  onClose?: () => void;
  icon?: React.ReactNode;
}

const HelpPostIt: React.FC<HelpPostItProps> = ({
  title,
  content,
  color = 'yellow',
  onClose,
  icon
}) => {
  const colorClasses = {
    yellow: 'bg-yellow-100 border-yellow-200 shadow-yellow-500/10',
    blue: 'bg-blue-100 border-blue-200 shadow-blue-500/10',
    green: 'bg-green-100 border-green-200 shadow-green-500/10',
    pink: 'bg-pink-100 border-pink-200 shadow-pink-500/10'
  };

  const textColors = {
    yellow: 'text-yellow-800',
    blue: 'text-blue-800',
    green: 'text-green-800',
    pink: 'text-pink-800'
  };

  return (
    <div 
      className={`relative p-4 rounded-lg border ${colorClasses[color]} transform rotate-1 shadow-lg transition-transform hover:rotate-0 hover:scale-105`}
      style={{
        backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,0.03) 10px, rgba(0,0,0,0.03) 20px)'
      }}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center">
          {icon || <Info className={`h-5 w-5 ${textColors[color]} mr-2`} />}
          <h3 className={`font-medium ${textColors[color]}`}>{title}</h3>
        </div>
        {onClose && (
          <button 
            onClick={onClose}
            className={`p-1 rounded-full hover:bg-white/50 ${textColors[color]}`}
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      <div className={`mt-2 text-sm ${textColors[color]}`}>
        {content}
      </div>
      
      {/* Decorative tape */}
      <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-12 h-3 bg-white/50 rounded-sm rotate-3" />
    </div>
  );
};

export default HelpPostIt;