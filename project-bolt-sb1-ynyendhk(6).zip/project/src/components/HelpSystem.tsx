import React, { useState, useEffect, useMemo } from 'react';
import * as Icons from 'lucide-react';
import { generateHelpContent, searchHelpContent, getLatestUpdates } from '../utils/helpUtils';
import { HelpCategory, HelpSection } from '../types';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

const HelpSystem: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showHelpButton, setShowHelpButton] = useState(true);
  const [buttonPulse, setButtonPulse] = useState(false);
  const [categories, setCategories] = useState<HelpCategory[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>([]);
  const [showWhatsNew, setShowWhatsNew] = useState(true);
  
  // DnD sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor)
  );
  
  // Generate help content on mount
  useEffect(() => {
    setCategories(generateHelpContent());
    
    // Load favorites and recently viewed from localStorage
    const savedFavorites = localStorage.getItem('helpFavorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
    
    const savedRecent = localStorage.getItem('helpRecent');
    if (savedRecent) {
      setRecentlyViewed(JSON.parse(savedRecent));
    }
  }, []);

  // Pulse animation effect
  useEffect(() => {
    const interval = setInterval(() => {
      setButtonPulse(true);
      setTimeout(() => setButtonPulse(false), 2000);
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  // Filter categories based on search
  const filteredCategories = useMemo(() => {
    return searchQuery ? searchHelpContent(categories, searchQuery) : categories;
  }, [categories, searchQuery]);

  // Get latest updates for the "What's New" section
  const latestUpdates = useMemo(() => {
    return getLatestUpdates(categories);
  }, [categories]);

  // Dynamic icon component
  const DynamicIcon = ({ name }: { name: string }) => {
    const IconComponent = (Icons as any)[name] || Icons.HelpCircle;
    return <IconComponent className="h-5 w-5" />;
  };

  // Track viewed sections
  const trackView = (sectionId: string) => {
    setRecentlyViewed(prev => {
      const newRecent = [sectionId, ...prev.filter(id => id !== sectionId)].slice(0, 5);
      localStorage.setItem('helpRecent', JSON.stringify(newRecent));
      return newRecent;
    });
  };

  // Toggle favorite
  const toggleFavorite = (sectionId: string) => {
    setFavorites(prev => {
      const newFavorites = prev.includes(sectionId)
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId];
      localStorage.setItem('helpFavorites', JSON.stringify(newFavorites));
      return newFavorites;
    });
  };

  // Sortable section component
  const SortableSection = ({ section }: { section: HelpSection }) => {
    const {
      attributes,
      listeners,
      setNodeRef,
      transform,
      transition,
    } = useSortable({ id: section.id });

    const style = {
      transform: CSS.Transform.toString(transform),
      transition,
    };

    return (
      <div
        ref={setNodeRef}
        style={style}
        {...attributes}
        {...listeners}
        className="bg-white rounded-lg border border-gray-200 p-4 mb-4 hover:shadow-lg transition-shadow"
      >
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-medium">{section.title}</h3>
          {section.version && (
            <span className="text-xs bg-primary-100 text-primary-800 px-2 py-1 rounded-full">
              v{section.version}
            </span>
          )}
        </div>
        
        <p className="text-gray-600 mb-4 whitespace-pre-wrap">{section.content}</p>

        {section.examples && (
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Esempi:</h4>
            <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
              {section.examples.map((example, index) => (
                <li key={index}>{example}</li>
              ))}
            </ul>
          </div>
        )}

        {section.shortcuts && (
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Scorciatoie:</h4>
            <div className="grid grid-cols-2 gap-2">
              {section.shortcuts.map((shortcut, index) => (
                <div key={index} className="flex items-center text-sm">
                  <kbd className="px-2 py-1 bg-gray-100 rounded text-gray-800 font-mono text-xs">
                    {shortcut.key}
                  </kbd>
                  <span className="ml-2 text-gray-600">{shortcut.description}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {section.images && (
          <div className="grid grid-cols-2 gap-4 mt-4">
            {section.images.map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`Example ${index + 1}`}
                className="rounded-lg shadow-sm"
              />
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Help Button */}
      {showHelpButton && (
        <button
          onClick={() => setIsOpen(true)}
          className={`relative p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 ${
            buttonPulse ? 'animate-pulse' : ''
          }`}
          title="Aiuto"
        >
          <Icons.HelpCircle className="h-6 w-6" />
          <span className="absolute top-0 right-0 h-2 w-2 bg-primary-500 rounded-full"></span>
        </button>
      )}

      {/* Help Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black bg-opacity-75 transition-opacity"></div>

          <div className="fixed inset-y-0 right-0 pl-10 max-w-full flex">
            <div className="w-screen max-w-2xl">
              <div className="h-full flex flex-col bg-white shadow-xl">
                {/* Header */}
                <div className="px-6 py-4 bg-gradient-to-r from-primary-600 to-primary-700 text-white flex justify-between items-center">
                  <div className="flex items-center">
                    <Icons.Book className="h-6 w-6 mr-2" />
                    <h2 className="text-lg font-medium">Guida EasyLAB 25</h2>
                  </div>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="text-white hover:text-gray-200 focus:outline-none"
                  >
                    <Icons.X className="h-6 w-6" />
                  </button>
                </div>

                {/* Search */}
                <div className="px-6 py-4 border-b border-gray-200">
                  <div className="relative">
                    <Icons.Search className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Cerca nella guida..."
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>

                {/* What's New Section */}
                {showWhatsNew && !searchQuery && (
                  <div className="px-6 py-4 border-b border-gray-200 bg-blue-50">
                    <h3 className="text-lg font-medium text-blue-900 mb-3 flex items-center">
                      <Icons.Zap className="h-5 w-5 mr-2" />
                      Novità
                    </h3>
                    <div className="space-y-3">
                      {latestUpdates.map((update, index) => (
                        <div key={index} className="bg-white p-3 rounded-lg border border-blue-100">
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm font-medium text-blue-900">{update.title}</h4>
                            {update.version && (
                              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                                v{update.version}
                              </span>
                            )}
                          </div>
                          {update.date && (
                            <p className="text-xs text-blue-600 mt-1">
                              {new Date(update.date).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Content */}
                <div className="flex-1 overflow-y-auto">
                  <div className="px-6 py-4">
                    <DndContext 
                      sensors={sensors}
                      collisionDetection={closestCenter}
                    >
                      {filteredCategories.map(category => (
                        <div key={category.id} className="mb-6">
                          <button
                            onClick={() => setActiveCategory(
                              activeCategory === category.id ? null : category.id
                            )}
                            className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <div className="flex items-center">
                              <DynamicIcon name={category.icon} />
                              <span className="ml-2 font-medium">{category.title}</span>
                            </div>
                            {activeCategory === category.id ? (
                              <Icons.ChevronDown className="h-5 w-5 text-gray-400" />
                            ) : (
                              <Icons.ChevronRight className="h-5 w-5 text-gray-400" />
                            )}
                          </button>

                          {activeCategory === category.id && (
                            <div className="mt-4 ml-4">
                              <SortableContext 
                                items={category.sections.map(s => s.id)}
                                strategy={verticalListSortingStrategy}
                              >
                                {category.sections.map(section => (
                                  <SortableSection key={section.id} section={section} />
                                ))}
                              </SortableContext>
                            </div>
                          )}
                        </div>
                      ))}
                    </DndContext>
                  </div>
                </div>

                {/* Footer */}
                <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-gray-500">
                      <Icons.Info className="h-4 w-4 mr-1" />
                      <span>Versione 1.0.0</span>
                    </div>
                    <button
                      onClick={() => window.open('https://docs.easysistem.it', '_blank')}
                      className="text-primary-600 hover:text-primary-700 text-sm font-medium"
                    >
                      Documentazione Completa
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default HelpSystem;