import React, { useState } from 'react';
import { Check, Plus, RefreshCw, Palette, Sun, Moon, Save } from 'lucide-react';
import { Theme, useTheme } from '../context/ThemeContext';
import { ChromePicker } from 'react-color';

const ThemeSelector: React.FC = () => {
  const { state, setTheme, addTheme, resetTheme, previewTheme, applyTheme } = useTheme();
  const [showCustomizer, setShowCustomizer] = useState(false);
  const [customTheme, setCustomTheme] = useState<Theme>({
    id: 'custom',
    name: 'Custom Theme',
    colors: { ...state.currentTheme.colors },
    isDark: false
  });
  const [activeColor, setActiveColor] = useState<keyof Theme['colors'] | null>(null);

  const handleColorChange = (color: string, key: keyof Theme['colors']) => {
    const newTheme = {
      ...customTheme,
      colors: {
        ...customTheme.colors,
        [key]: color
      }
    };
    setCustomTheme(newTheme);
    previewTheme(newTheme);
  };

  const saveCustomTheme = () => {
    const newTheme: Theme = {
      ...customTheme,
      id: `custom-${Date.now()}`,
      name: `Custom Theme ${state.availableThemes.length + 1}`
    };
    addTheme(newTheme);
    setShowCustomizer(false);
  };

  const handleThemeSelect = (theme: Theme) => {
    previewTheme(theme);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setShowCustomizer(true)}
        className="macos-button flex items-center"
        title="Personalizza tema"
      >
        <Palette className="h-5 w-5" />
      </button>

      {showCustomizer && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-medium text-gray-900 flex items-center">
                  <Palette className="h-5 w-5 mr-2" />
                  Temi e Colori
                </h2>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={resetTheme}
                    className="macos-button flex items-center"
                    title="Ripristina tema predefinito"
                  >
                    <RefreshCw className="h-4 w-4 mr-1" />
                    Reset
                  </button>
                  <button
                    onClick={() => setShowCustomizer(false)}
                    className="macos-button"
                  >
                    Chiudi
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-4">Temi Predefiniti</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {state.availableThemes.map((theme) => (
                      <button
                        key={theme.id}
                        onClick={() => handleThemeSelect(theme)}
                        className={`p-4 rounded-lg border transition-all duration-200 ${
                          state.currentTheme.id === theme.id
                            ? 'border-primary-500 bg-primary-50'
                            : 'border-gray-200 hover:border-primary-200 hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-sm font-medium">{theme.name}</span>
                          {state.currentTheme.id === theme.id && (
                            <Check className="h-4 w-4 text-primary-600" />
                          )}
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          {Object.entries(theme.colors).slice(0, 3).map(([key, color]) => (
                            <div
                              key={key}
                              className="h-6 rounded"
                              style={{ backgroundColor: color }}
                            />
                          ))}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-4">Personalizza</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Nome Tema
                      </label>
                      <input
                        type="text"
                        value={customTheme.name}
                        onChange={(e) => setCustomTheme(prev => ({ ...prev, name: e.target.value }))}
                        className="macos-input"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      {Object.entries(customTheme.colors).map(([key, value]) => (
                        <div key={key}>
                          <label className="block text-sm font-medium text-gray-700 mb-1 capitalize">
                            {key}
                          </label>
                          <div 
                            className="h-10 rounded cursor-pointer border relative"
                            style={{ backgroundColor: value }}
                            onClick={() => setActiveColor(key as keyof Theme['colors'])}
                          >
                            {activeColor === key && (
                              <div className="absolute top-full left-0 mt-2 z-10">
                                <ChromePicker
                                  color={value}
                                  onChange={(color) => handleColorChange(color.hex, key as keyof Theme['colors'])}
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center mt-2">
                      <input
                        type="checkbox"
                        id="darkMode"
                        checked={customTheme.isDark}
                        onChange={(e) => setCustomTheme(prev => ({ ...prev, isDark: e.target.checked }))}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      />
                      <label htmlFor="darkMode" className="ml-2 text-sm text-gray-700 flex items-center">
                        {customTheme.isDark ? (
                          <Moon className="h-4 w-4 mr-1" />
                        ) : (
                          <Sun className="h-4 w-4 mr-1" />
                        )}
                        Tema Scuro
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => {
                    previewTheme(state.currentTheme);
                    setShowCustomizer(false);
                  }}
                  className="macos-button"
                >
                  Annulla
                </button>
                <button
                  onClick={saveCustomTheme}
                  className="macos-button"
                >
                  Salva come Nuovo
                </button>
                <button
                  onClick={() => {
                    applyTheme();
                    setShowCustomizer(false);
                  }}
                  className="macos-button-primary flex items-center"
                >
                  <Save className="h-4 w-4 mr-1" />
                  Applica Tema
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ThemeSelector;