import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Calendar, Users, TicketCheck, Settings, LayoutGrid, Info, Menu, X, LogOut, Search, Bell, RefreshCw, ChevronDown, Wrench, ChevronLeft, ChevronRight, BarChart2, FileText,
  FileCheck, Store, Briefcase, UserCircle, Home, CreditCard, Globe, Database,
  MessageCircle, Shield, Info as InfoIcon
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { useTheme } from '../context/ThemeContext';
import Logo from './Logo';
import NotificationCenter from './NotificationCenter';
import LoadingSpinner from './LoadingSpinner';
import TopbarWidgets from './TopbarWidgets';
import HelpSystem from './HelpSystem';
import ThemeSelector from './ThemeSelector';

interface AdminLayoutProps {
  children: React.ReactNode;
}

interface MenuItem {
  id: string;
  title: string;
  icon: React.ElementType;
  path?: string;
  badge?: number | string;
  items?: MenuItem[];
}

const menuItems: MenuItem[] = [
  {
    id: 'dashboard',
    title: 'Dashboard',
    icon: LayoutGrid,
    path: '/admin'
  },
  {
    id: 'clients',
    title: 'Clienti',
    icon: Users,
    items: [
      { id: 'clients-list', title: 'Elenco Clienti', icon: FileText, path: '/admin/clients' },
      { id: 'clients-new', title: 'Nuovo Cliente', icon: UserCircle, path: '/admin/clients/new' },
      { id: 'clients-devices', title: 'Dispositivi', icon: CreditCard, path: '/admin/clients/devices' }
    ]
  },
  {
    id: 'appointments',
    title: 'Appuntamenti',
    icon: Calendar,
    items: [
      { id: 'calendar', title: 'Calendario', icon: Calendar, path: '/admin/appointments/calendar' },
      { id: 'appointments-list', title: 'Elenco', icon: FileText, path: '/admin/appointments' },
      { id: 'appointment-types', title: 'Tipologie', icon: FileCheck, path: '/admin/appointments/types' }
    ]
  },
  {
    id: 'tickets',
    title: 'Assistenza',
    icon: TicketCheck,
    items: [
      { id: 'tickets-list', title: 'Ticket', icon: MessageCircle, path: '/admin/tickets' },
      { id: 'tickets-stats', title: 'Statistiche', icon: BarChart2, path: '/admin/tickets/stats' }
    ]
  },
  {
    id: 'settings',
    title: 'Impostazioni',
    icon: Settings,
    items: [
      { id: 'system-settings', title: 'Sistema', icon: Settings, path: '/admin/settings' },
      { id: 'utility', title: 'Utility', icon: Wrench, path: '/admin/settings/utility' },
      { id: 'legal-info', title: 'Info Legali', icon: Shield, path: '/admin/settings/legal' }
    ]
  }
];

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const { logout } = useAuth();
  const { state } = useData();
  const { state: themeState } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();

  // Toggle menu item expansion
  const toggleExpand = (itemId: string) => {
    setExpandedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  // Check if a menu item is active
  const isActive = (path?: string) => {
    if (!path) return false;
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  // Render menu item
  const renderMenuItem = (item: MenuItem, level: number = 0) => {
    const isItemActive = isActive(item.path);
    const isExpanded = expandedItems.includes(item.id);
    const hasSubItems = item.items && item.items.length > 0;
    const Icon = item.icon;
    
    return (
      <div key={item.id} className={`${level > 0 ? 'ml-4' : ''}`}>
        <button
          onClick={() => {
            if (hasSubItems) {
              toggleExpand(item.id);
            } else if (item.path) {
              navigate(item.path);
            }
          }}
          className={`w-full flex items-center justify-between p-2 rounded-lg transition-all duration-200 ${
            isItemActive 
              ? 'bg-primary-100 text-primary-900' 
              : 'hover:bg-gray-100 text-gray-700'
          } ${sidebarCollapsed && level === 0 ? 'justify-center' : ''}`}
        >
          <div className="flex items-center min-w-0">
            <div className={`flex-shrink-0 ${isItemActive ? 'text-primary-600' : 'text-gray-400'}`}>
              <Icon className="h-6 w-6" />
            </div>
            {(!sidebarCollapsed || level > 0) && (
              <span className="ml-3 text-sm font-medium truncate">{item.title}</span>
            )}
          </div>
          {hasSubItems && !sidebarCollapsed && (
            <ChevronRight className={`h-4 w-4 transition-transform duration-200 ${
              isExpanded ? 'transform rotate-90' : ''
            }`} />
          )}
        </button>
        
        {hasSubItems && isExpanded && !sidebarCollapsed && (
          <div className="mt-1 space-y-1">
            {item.items.map(subItem => renderMenuItem(subItem, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="h-screen flex overflow-hidden bg-[#f5f5f7]">
      {/* Mobile sidebar */}
      <div
        className={`fixed inset-0 z-40 lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`}
        role="dialog"
        aria-modal="true"
      >
        <div 
          className="fixed inset-0 bg-gray-600/75 backdrop-blur-sm"
          aria-hidden="true"
          onClick={() => setSidebarOpen(false)}
        ></div>

        <div className="relative flex-1 flex flex-col w-full max-w-xs bg-white/90 backdrop-blur-xl">
          <div className="absolute top-0 right-0 -mr-12 pt-2">
            <button
              className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              onClick={() => setSidebarOpen(false)}
            >
              <span className="sr-only">Close sidebar</span>
              <X className="h-6 w-6 text-white" />
            </button>
          </div>

          <div className="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
            <div className="flex-shrink-0 flex items-center px-4">
              <Logo size="sm" />
            </div>
            <nav className="mt-5 px-2 space-y-1">
              {menuItems.map(item => renderMenuItem(item))}
            </nav>
          </div>
        </div>
      </div>

      {/* Desktop sidebar */}
      <div className={`hidden lg:flex lg:flex-shrink-0 transition-all duration-300 ${
        sidebarCollapsed ? 'lg:w-20' : 'lg:w-64'
      }`}>
        <div className="flex flex-col">
          <div className="flex-1 flex flex-col min-h-0 bg-white/90 backdrop-blur-xl border-r border-white/20">
            <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
              <div className="flex-shrink-0 flex items-center px-4">
                <Logo size="sm" withText={!sidebarCollapsed} />
              </div>
              <nav className="mt-5 flex-1 px-2 space-y-1">
                {menuItems.map(item => renderMenuItem(item))}
              </nav>
              
              {/* Collapse button */}
              <div className="p-4 flex justify-center">
                <button
                  onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                  className="p-2 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {sidebarCollapsed ? (
                    <ChevronRight className="h-5 w-5" />
                  ) : (
                    <ChevronLeft className="h-5 w-5" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-auto focus:outline-none">
        {/* Top bar */}
        <div className="sticky top-0 z-10 flex-shrink-0 h-16 bg-white/90 backdrop-blur-xl border-b border-white/20">
          <div className="flex items-center justify-between px-4 h-full">
            <div className="flex items-center flex-1">
              <button
                className="lg:hidden -ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-900"
                onClick={() => setSidebarOpen(true)}
              >
                <span className="sr-only">Open sidebar</span>
                <Menu className="h-6 w-6" />
              </button>

              <div className="flex-1 px-4 flex justify-between">
                <div className="flex-1 flex">
                  <div className="w-full flex md:ml-0">
                    <div className="relative w-full">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="global-search"
                        className="macos-input pl-10 pr-3 py-2"
                        placeholder="Cerca..."
                        type="search"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="ml-4 flex items-center md:ml-6 space-x-4">
              <TopbarWidgets />
              <NotificationCenter />
              <HelpSystem />
              <ThemeSelector />
            </div>
          </div>
        </div>

        {/* Main content */}
        <main className="flex-1 relative">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              {children}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;