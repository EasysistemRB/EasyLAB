import React, { useState } from 'react';
import { 
  Key, Mail, User, Copy, CheckCircle, AlertTriangle,
  QrCode, Link, ExternalLink, RefreshCw, Lock, Shield,
  Globe, Send, MessageCircle as WhatsApp
} from 'lucide-react';
import { Client } from '../types';
import { 
  generateClientCredentials, 
  generateSecurePassword 
} from '../utils/clientUtils';
import { QRCodeSVG } from 'qrcode.react';
import LoadingSpinner from './LoadingSpinner';

interface ClientCredentialsGeneratorProps {
  client: Client;
  onSave: (updatedClient: Client) => Promise<void>;
  baseUrl?: string;
}

const ClientCredentialsGenerator: React.FC<ClientCredentialsGeneratorProps> = ({
  client,
  onSave,
  baseUrl = 'https://portal.easysistem.it'
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [credentials, setCredentials] = useState<{
    username: string;
    password: string;
    portalLink: string;
  } | null>(null);
  const [copied, setCopied] = useState<{
    username: boolean;
    password: boolean;
    link: boolean;
  }>({
    username: false,
    password: false,
    link: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isSendingWhatsApp, setIsSendingWhatsApp] = useState(false);

  // Generate new credentials
  const handleGenerateCredentials = () => {
    setIsGenerating(true);
    setError(null);
    
    try {
      const newCredentials = generateClientCredentials(client, baseUrl);
      setCredentials(newCredentials);
      setSuccess('Credenziali generate con successo');
      
      // Reset copy states
      setCopied({
        username: false,
        password: false,
        link: false
      });
    } catch (err) {
      setError('Errore durante la generazione delle credenziali');
      console.error('Error generating credentials:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Save credentials to client
  const handleSaveCredentials = async () => {
    if (!credentials) return;
    
    setIsSaving(true);
    setError(null);
    
    try {
      const updatedClient: Client = {
        ...client,
        accountCreated: true,
        accountUsername: credentials.username,
        portalAccessLink: credentials.portalLink,
        accountCreatedAt: new Date().toISOString(),
        accountExpiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days
        accountStatus: 'active'
      };
      
      await onSave(updatedClient);
      setSuccess('Credenziali salvate con successo');
    } catch (err) {
      setError('Errore durante il salvataggio delle credenziali');
      console.error('Error saving credentials:', err);
    } finally {
      setIsSaving(false);
    }
  };

  // Send credentials via WhatsApp
  const handleSendWhatsApp = async () => {
    if (!credentials || !client.phone) return;
    
    setIsSendingWhatsApp(true);
    
    try {
      const message = `
Gentile ${client.name},

Ecco le tue credenziali di accesso all'area riservata:

Username: ${credentials.username}
Password: ${credentials.password}

Puoi accedere al portale qui:
${credentials.portalLink}

Per assistenza, non esitare a contattarci.

Cordiali saluti,
EasySystem
`;

      // In a real app, this would call your WhatsApp API
      console.log('Sending WhatsApp message:', message);
      
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      
      setSuccess('Credenziali inviate via WhatsApp');
    } catch (err) {
      setError('Errore durante l\'invio del messaggio WhatsApp');
      console.error('Error sending WhatsApp message:', err);
    } finally {
      setIsSendingWhatsApp(false);
    }
  };

  // Copy text to clipboard
  const copyToClipboard = (text: string, field: 'username' | 'password' | 'link') => {
    navigator.clipboard.writeText(text).then(
      () => {
        setCopied({ ...copied, [field]: true });
        
        // Reset after 2 seconds
        setTimeout(() => {
          setCopied({ ...copied, [field]: false });
        }, 2000);
      },
      () => {
        setError('Impossibile copiare negli appunti');
      }
    );
  };

  // Generate new password only
  const regeneratePassword = () => {
    if (!credentials) return;
    
    const newPassword = generateSecurePassword(10);
    setCredentials({
      ...credentials,
      password: newPassword
    });
    
    // Reset password copied state
    setCopied({ ...copied, password: false });
  };

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="px-6 py-4 bg-indigo-700 text-white flex items-center justify-between">
        <h2 className="text-lg font-medium flex items-center">
          <Key className="mr-2 h-5 w-5" />
          Gestione Accesso Area Riservata
        </h2>
      </div>
      
      <div className="p-6">
        {/* Status messages */}
        {error && (
          <div className="mb-4 bg-red-50 border-l-4 border-red-400 p-4">
            <div className="flex">
              <AlertTriangle className="h-5 w-5 text-red-400" />
              <p className="ml-3 text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}
        
        {success && (
          <div className="mb-4 bg-green-50 border-l-4 border-green-400 p-4">
            <div className="flex">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <p className="ml-3 text-sm text-green-700">{success}</p>
            </div>
          </div>
        )}
        
        {/* Client info */}
        <div className="mb-6">
          <div className="p-4 bg-indigo-50 rounded-lg">
            <h3 className="text-md font-medium text-indigo-800 mb-2">Informazioni Cliente</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Codice Cliente</p>
                <p className="font-medium text-indigo-700">{client.clientCode}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Ragione Sociale</p>
                <p className="font-medium">{client.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium">{client.email || 'Non specificata'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Stato Account</p>
                <p className="font-medium">
                  {client.accountCreated ? (
                    <span className="text-green-600">Account Attivo</span>
                  ) : (
                    <span className="text-yellow-600">Account Non Creato</span>
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Credentials section */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-900">Credenziali di Accesso</h3>
            <button
              onClick={handleGenerateCredentials}
              disabled={isGenerating}
              className="btn bg-indigo-600 text-white hover:bg-indigo-700 flex items-center"
            >
              {isGenerating ? (
                <LoadingSpinner size="sm" color="white" />
              ) : (
                <>
                  <Key className="h-4 w-4 mr-2" />
                  {client.accountCreated ? 'Rigenera Credenziali' : 'Genera Credenziali'}
                </>
              )}
            </button>
          </div>
          
          {credentials ? (
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
              {/* Username */}
              <div className="mb-4">
                <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                  <User className="h-4 w-4 text-gray-500 mr-1" />
                  Username
                </label>
                <div className="relative">
                  <input
                    type="text"
                    className="input pr-10"
                    value={credentials.username}
                    readOnly
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    onClick={() => copyToClipboard(credentials.username, 'username')}
                  >
                    {copied.username ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <Copy className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                    )}
                  </button>
                </div>
              </div>
              
              {/* Password */}
              <div className="mb-4">
                <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                  <Key className="h-4 w-4 text-gray-500 mr-1" />
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    className="input pr-24"
                    value={credentials.password}
                    readOnly
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center space-x-2">
                    <button
                      type="button"
                      className="p-1 rounded-full hover:bg-gray-200"
                      onClick={() => setShowPassword(!showPassword)}
                      title={showPassword ? "Nascondi password" : "Mostra password"}
                    >
                      {showPassword ? (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-gray-500">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" />
                        </svg>
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-gray-500">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                          <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        </svg>
                      )}
                    </button>
                    <button
                      type="button"
                      className="p-1 rounded-full hover:bg-gray-200"
                      onClick={regeneratePassword}
                      title="Rigenera password"
                    >
                      <RefreshCw className="h-5 w-5 text-gray-500" />
                    </button>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(credentials.password, 'password')}
                      title="Copia password"
                    >
                      {copied.password ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <Copy className="h-5 w-5 text-gray-500 hover:text-gray-700" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Portal Link */}
              <div className="mb-4">
                <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
                  <Link className="h-4 w-4 text-gray-500 mr-1" />
                  Link di Accesso Personalizzato
                </label>
                <div className="relative">
                  <input
                    type="text"
                    className="input pr-10"
                    value={credentials.portalLink}
                    readOnly
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center space-x-2">
                    <button
                      type="button"
                      onClick={() => window.open(credentials.portalLink, '_blank')}
                      title="Apri link"
                    >
                      <ExternalLink className="h-5 w-5 text-indigo-500 hover:text-indigo-700" />
                    </button>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(credentials.portalLink, 'link')}
                      title="Copia link"
                    >
                      {copied.link ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <Copy className="h-5 w-5 text-gray-500 hover:text-gray-700" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
              
              {/* QR Code */}
              <div className="mt-4 flex items-center">
                <div className="mr-6">
                  <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                    <QrCode className="h-4 w-4 mr-2" />
                    QR Code di Accesso
                  </h4>
                  <div className="bg-white p-2 rounded border border-gray-200 inline-block">
                    <QRCodeSVG
                      value={JSON.stringify({
                        clientId: client.id,
                        clientCode: client.clientCode,
                        username: credentials.username,
                        accessLink: credentials.portalLink
                      })}
                      size={120}
                      bgColor={"#ffffff"}
                      fgColor={"#4338CA"}
                      level={"H"}
                      includeMargin={false}
                    />
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                    <Mail className="h-4 w-4 mr-2" />
                    Invia Credenziali
                  </h4>
                  <div className="space-y-2">
                    <button 
                      className="btn bg-indigo-100 text-indigo-800 hover:bg-indigo-200 flex items-center w-full"
                      disabled={!client.email}
                      title={!client.email ? "Email cliente non specificata" : "Invia email con credenziali"}
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Invia via Email
                    </button>
                    <button 
                      className="btn bg-green-100 text-green-800 hover:bg-green-200 flex items-center w-full"
                      disabled={!client.phone || isSendingWhatsApp}
                      onClick={handleSendWhatsApp}
                      title={!client.phone ? "Telefono cliente non specificato" : "Invia WhatsApp con credenziali"}
                    >
                      {isSendingWhatsApp ? (
                        <LoadingSpinner size="sm" color="green" />
                      ) : (
                        <>
                          <WhatsApp className="h-4 w-4 mr-2" />
                          Invia via WhatsApp
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    {client.email ? 
                      `L'email sarà inviata a ${client.email}` : 
                      "Email cliente non specificata"
                    }
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 text-center">
              <QrCode className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500 mb-4">
                {client.accountCreated ?
                  "Le credenziali di accesso per questo cliente sono già state generate. Puoi rigenerarle se necessario." :
                  "Nessuna credenziale generata per questo cliente. Clicca sul pulsante per generare le credenziali di accesso."
                }
              </p>
            </div>
          )}
        </div>
        
        {/* Save action */}
        {credentials && (
          <div className="flex justify-end">
            <button
              onClick={handleSaveCredentials}
              disabled={isSaving}
              className="btn btn-primary"
            >
              {isSaving ? (
                <LoadingSpinner size="sm" color="white" />
              ) : (
                <>
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Salva Credenziali
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientCredentialsGenerator;