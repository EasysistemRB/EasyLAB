import React, { createContext, useContext, useReducer, useEffect } from 'react';

export interface Theme {
  id: string;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
    border: string;
  };
  isDark: boolean;
}

interface ThemeState {
  currentTheme: Theme;
  availableThemes: Theme[];
  isCustom: boolean;
  pendingTheme: Theme | null;
}

type ThemeAction = 
  | { type: 'SET_THEME'; payload: Theme }
  | { type: 'ADD_THEME'; payload: Theme }
  | { type: 'RESET_THEME' }
  | { type: 'SET_PENDING_THEME'; payload: Theme | null }
  | { type: 'APPLY_PENDING_THEME' };

const defaultTheme: Theme = {
  id: 'default',
  name: 'Default Light',
  colors: {
    primary: '#4338ca',
    secondary: '#0d9488',
    accent: '#f43f5e',
    background: '#f5f5f7',
    text: '#1f2937',
    border: 'rgba(255, 255, 255, 0.2)'
  },
  isDark: false
};

const predefinedThemes: Theme[] = [
  defaultTheme,
  {
    id: 'dark',
    name: 'Default Dark',
    colors: {
      primary: '#818cf8',
      secondary: '#2dd4bf',
      accent: '#fb7185',
      background: '#1a1a1a',
      text: '#f3f4f6',
      border: 'rgba(255, 255, 255, 0.1)'
    },
    isDark: true
  },
  {
    id: 'blue',
    name: 'Ocean Blue',
    colors: {
      primary: '#0ea5e9',
      secondary: '#06b6d4',
      accent: '#6366f1',
      background: '#f0f9ff',
      text: '#0f172a',
      border: 'rgba(14, 165, 233, 0.2)'
    },
    isDark: false
  },
  {
    id: 'green',
    name: 'Forest',
    colors: {
      primary: '#059669',
      secondary: '#10b981',
      accent: '#84cc16',
      background: '#f0fdf4',
      text: '#064e3b',
      border: 'rgba(5, 150, 105, 0.2)'
    },
    isDark: false
  }
];

const initialState: ThemeState = {
  currentTheme: defaultTheme,
  availableThemes: predefinedThemes,
  isCustom: false,
  pendingTheme: null
};

const themeReducer = (state: ThemeState, action: ThemeAction): ThemeState => {
  switch (action.type) {
    case 'SET_THEME':
      return {
        ...state,
        currentTheme: action.payload,
        isCustom: !state.availableThemes.some(theme => theme.id === action.payload.id)
      };
    case 'ADD_THEME':
      return {
        ...state,
        availableThemes: [...state.availableThemes, action.payload]
      };
    case 'RESET_THEME':
      return {
        ...state,
        currentTheme: defaultTheme,
        isCustom: false,
        pendingTheme: null
      };
    case 'SET_PENDING_THEME':
      return {
        ...state,
        pendingTheme: action.payload
      };
    case 'APPLY_PENDING_THEME':
      return state.pendingTheme ? {
        ...state,
        currentTheme: state.pendingTheme,
        isCustom: !state.availableThemes.some(theme => theme.id === state.pendingTheme?.id),
        pendingTheme: null
      } : state;
    default:
      return state;
  }
};

interface ThemeContextProps {
  state: ThemeState;
  setTheme: (theme: Theme) => void;
  addTheme: (theme: Theme) => void;
  resetTheme: () => void;
  previewTheme: (theme: Theme | null) => void;
  applyTheme: () => void;
}

const ThemeContext = createContext<ThemeContextProps | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(themeReducer, initialState);

  const setTheme = (theme: Theme) => {
    dispatch({ type: 'SET_THEME', payload: theme });
  };

  const addTheme = (theme: Theme) => {
    dispatch({ type: 'ADD_THEME', payload: theme });
    setTheme(theme);
  };

  const resetTheme = () => {
    dispatch({ type: 'RESET_THEME' });
  };

  const previewTheme = (theme: Theme | null) => {
    dispatch({ type: 'SET_PENDING_THEME', payload: theme });
    if (theme) {
      applyThemeToDOM(theme);
    } else {
      applyThemeToDOM(state.currentTheme);
    }
  };

  const applyTheme = () => {
    dispatch({ type: 'APPLY_PENDING_THEME' });
  };

  const applyThemeToDOM = (theme: Theme) => {
    // Apply theme colors to CSS variables
    const root = document.documentElement;
    Object.entries(theme.colors).forEach(([key, value]) => {
      root.style.setProperty(`--theme-${key}`, value);
    });

    // Apply dark mode class if needed
    if (theme.isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  // Load saved theme on mount
  useEffect(() => {
    const savedThemeId = localStorage.getItem('theme-preference');
    if (savedThemeId) {
      const savedTheme = state.availableThemes.find(theme => theme.id === savedThemeId);
      if (savedTheme) {
        setTheme(savedTheme);
        applyThemeToDOM(savedTheme);
      }
    }
  }, []);

  // Apply theme when it changes
  useEffect(() => {
    applyThemeToDOM(state.currentTheme);
    localStorage.setItem('theme-preference', state.currentTheme.id);
  }, [state.currentTheme]);

  return (
    <ThemeContext.Provider value={{ state, setTheme, addTheme, resetTheme, previewTheme, applyTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};