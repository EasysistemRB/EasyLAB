import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { User, AuthState } from '../types';
import { v4 as uuidv4 } from 'uuid';
import LoadingSpinner from '../components/LoadingSpinner';

// Initial state for auth context
const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,
};

// Action types
type AuthAction =
  | { type: 'LOGIN_SUCCESS'; payload: User }
  | { type: 'LOGIN_FAILURE'; payload: string }
  | { type: 'LOGOUT' }
  | { type: 'SET_LOADING'; payload: boolean };

// Auth reducer
const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'LOGIN_SUCCESS':
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      };
    case 'LOGIN_FAILURE':
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: action.payload,
      };
    case 'LOGOUT':
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      };
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };
    default:
      return state;
  }
};

// Auth context
interface AuthContextProps {
  state: AuthState;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  register: (userData: Partial<User>) => Promise<void>;
  forgotPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

// Sample users for demo
const sampleUsers: User[] = [
  {
    id: '1',
    username: 'admin',
    role: 'admin',
    name: 'Amministratore',
    email: 'admin@easysistem.it',
    createdAt: new Date().toISOString(),
    isActive: true,
  },
  {
    id: '2',
    username: 'ESL-001',
    role: 'user',
    name: 'Cliente Demo',
    email: 'cliente@esempio.it',
    createdAt: new Date().toISOString(),
    passwordExpiry: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
    isActive: true,
  },
];

// Auth provider component
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // Check for existing session on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const session = localStorage.getItem('easylab_session');
        if (session) {
          const user = JSON.parse(session) as User;
          dispatch({ type: 'LOGIN_SUCCESS', payload: user });
        }
      } catch (error) {
        console.error('Error checking auth:', error);
      } finally {
        dispatch({ type: 'SET_LOADING', payload: false });
      }
    };

    checkAuth();
  }, []);

  // Login function
  const login = async (username: string, password: string) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      const user = sampleUsers.find((u) => u.username === username);
      
      if (user && password === '123456') { // Simple password check for demo
        localStorage.setItem('easylab_session', JSON.stringify(user));
        dispatch({ type: 'LOGIN_SUCCESS', payload: user });
      } else {
        throw new Error('Credenziali non valide');
      }
    } catch (error) {
      dispatch({ type: 'LOGIN_FAILURE', payload: error instanceof Error ? error.message : 'Errore durante il login' });
      throw error;
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('easylab_session');
    dispatch({ type: 'LOGOUT' });
  };

  // Register function
  const register = async (userData: Partial<User>) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      const newUser: User = {
        id: uuidv4(),
        username: `ESL-${Math.floor(1000 + Math.random() * 9000)}`,
        role: 'user',
        name: userData.name || 'Utente',
        email: userData.email || '',
        createdAt: new Date().toISOString(),
        passwordExpiry: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days
        isActive: true,
      };
      
      // In a real app, save to database. For demo, we'll just simulate success
      console.log('Nuovo utente registrato:', newUser);
      
      dispatch({ type: 'SET_LOADING', payload: false });
    } catch (error) {
      dispatch({ type: 'LOGIN_FAILURE', payload: 'Errore durante la registrazione' });
      throw error;
    }
  };

  // Forgot password function
  const forgotPassword = async (email: string) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      // In a real app, send reset email. For demo, we'll just simulate success
      console.log('Richiesta recupero password per:', email);
      
      dispatch({ type: 'SET_LOADING', payload: false });
    } catch (error) {
      dispatch({ type: 'LOGIN_FAILURE', payload: 'Errore durante il recupero password' });
      throw error;
    }
  };

  // Only render children once initial auth check is complete
  if (state.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" text="Caricamento..." />
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ state, login, logout, register, forgotPassword }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};