import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { Client, Appointment, Ticket, Notification, SystemSettings } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { addDays, formatDistanceToNow, isAfter, isBefore, startOfDay } from 'date-fns';
import { it } from 'date-fns/locale';

// Data state interface
interface DataState {
  clients: Client[];
  appointments: Appointment[];
  tickets: Ticket[];
  notifications: Notification[];
  settings: SystemSettings;
  isLoading: boolean;
  error: string | null;
  lastSynced: string | null;
}

// Initial state
const initialState: DataState = {
  clients: [],
  appointments: [],
  tickets: [],
  notifications: [],
  settings: {
    companyName: 'EasySystem di Raffaele Bianchetti',
    companyAddress: 'Via Grotta dell\'Olmo 51',
    companyCity: 'Giugliano in Campania (NA)',
    companyPostalCode: '80014',
    companyPhone: '123456789',
    companyEmail: 'info@easysistem.it',
    companyWebsite: 'www.easysistem.it',
    vatNumber: '04118710617',
    fiscalCode: '04118710617',
    defaultPasswordExpiry: 90,
    enableWhatsApp: false,
    whatsAppApiKey: '',
    whatsAppBusinessId: '',
    whatsAppPhoneNumberId: '',
    whatsAppAccessToken: '',
    appointmentReminderHours: 24,
    backupFrequency: 'daily',
    backupTime: '02:00',
    backupLocation: 'local',
  },
  isLoading: false,
  error: null,
  lastSynced: null,
};

// Action types
type DataAction =
  | { type: 'SET_CLIENTS'; payload: Client[] }
  | { type: 'ADD_CLIENT'; payload: Client }
  | { type: 'UPDATE_CLIENT'; payload: Client }
  | { type: 'DELETE_CLIENT'; payload: string }
  | { type: 'SET_APPOINTMENTS'; payload: Appointment[] }
  | { type: 'ADD_APPOINTMENT'; payload: Appointment }
  | { type: 'UPDATE_APPOINTMENT'; payload: Appointment }
  | { type: 'DELETE_APPOINTMENT'; payload: string }
  | { type: 'SET_TICKETS'; payload: Ticket[] }
  | { type: 'ADD_TICKET'; payload: Ticket }
  | { type: 'UPDATE_TICKET'; payload: Ticket }
  | { type: 'DELETE_TICKET'; payload: string }
  | { type: 'SET_NOTIFICATIONS'; payload: Notification[] }
  | { type: 'ADD_NOTIFICATION'; payload: Notification }
  | { type: 'UPDATE_NOTIFICATION'; payload: Notification }
  | { type: 'MARK_NOTIFICATION_READ'; payload: string }
  | { type: 'DELETE_NOTIFICATION'; payload: string }
  | { type: 'UPDATE_SETTINGS'; payload: Partial<SystemSettings> }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_LAST_SYNCED'; payload: string };

// Data reducer
const dataReducer = (state: DataState, action: DataAction): DataState => {
  switch (action.type) {
    case 'SET_CLIENTS':
      return { ...state, clients: action.payload };
    case 'ADD_CLIENT':
      return { ...state, clients: [...state.clients, action.payload] };
    case 'UPDATE_CLIENT':
      return {
        ...state,
        clients: state.clients.map((client) =>
          client.id === action.payload.id ? action.payload : client
        ),
      };
    case 'DELETE_CLIENT':
      return {
        ...state,
        clients: state.clients.filter((client) => client.id !== action.payload),
      };
    case 'SET_APPOINTMENTS':
      return { ...state, appointments: action.payload };
    case 'ADD_APPOINTMENT':
      return { ...state, appointments: [...state.appointments, action.payload] };
    case 'UPDATE_APPOINTMENT':
      return {
        ...state,
        appointments: state.appointments.map((appointment) =>
          appointment.id === action.payload.id ? action.payload : appointment
        ),
      };
    case 'DELETE_APPOINTMENT':
      return {
        ...state,
        appointments: state.appointments.filter((appointment) => appointment.id !== action.payload),
      };
    case 'SET_TICKETS':
      return { ...state, tickets: action.payload };
    case 'ADD_TICKET':
      return { ...state, tickets: [...state.tickets, action.payload] };
    case 'UPDATE_TICKET':
      return {
        ...state,
        tickets: state.tickets.map((ticket) =>
          ticket.id === action.payload.id ? action.payload : ticket
        ),
      };
    case 'DELETE_TICKET':
      return {
        ...state,
        tickets: state.tickets.filter((ticket) => ticket.id !== action.payload),
      };
    case 'SET_NOTIFICATIONS':
      return { ...state, notifications: action.payload };
    case 'ADD_NOTIFICATION':
      return { ...state, notifications: [...state.notifications, action.payload] };
    case 'UPDATE_NOTIFICATION':
      return {
        ...state,
        notifications: state.notifications.map((notification) =>
          notification.id === action.payload.id ? action.payload : notification
        ),
      };
    case 'MARK_NOTIFICATION_READ':
      return {
        ...state,
        notifications: state.notifications.map((notification) =>
          notification.id === action.payload ? { ...notification, isRead: true } : notification
        ),
      };
    case 'DELETE_NOTIFICATION':
      return {
        ...state,
        notifications: state.notifications.filter((notification) => notification.id !== action.payload),
      };
    case 'UPDATE_SETTINGS':
      return {
        ...state,
        settings: { ...state.settings, ...action.payload },
      };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'SET_LAST_SYNCED':
      return { ...state, lastSynced: action.payload };
    default:
      return state;
  }
};

// Data context
interface DataContextProps {
  state: DataState;
  addClient: (client: Omit<Client, 'id' | 'createdAt' | 'updatedAt' | 'clientCode'>) => Promise<Client>;
  updateClient: (client: Client) => Promise<Client>;
  deleteClient: (id: string) => Promise<void>;
  addAppointment: (appointment: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Appointment>;
  updateAppointment: (appointment: Appointment) => Promise<Appointment>;
  deleteAppointment: (id: string) => Promise<void>;
  addTicket: (ticket: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt' | 'ticketNumber' | 'messages'>) => Promise<Ticket>;
  updateTicket: (ticket: Ticket) => Promise<Ticket>;
  deleteTicket: (id: string) => Promise<void>;
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => Promise<Notification>;
  markNotificationRead: (id: string) => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  updateSettings: (settings: Partial<SystemSettings>) => Promise<void>;
  syncData: () => Promise<void>;
  backupData: () => Promise<void>;
  restoreData: (backupData: string) => Promise<void>;
  exportData: (type: 'clients' | 'appointments' | 'tickets' | 'all') => Promise<string>;
  sendWhatsAppMessage: (phoneNumber: string, message: string) => Promise<boolean>;
  checkUpcomingAppointments: () => Promise<void>;
}

const DataContext = createContext<DataContextProps | undefined>(undefined);

// Local storage keys
const STORAGE_KEYS = {
  CLIENTS: 'easylab_clients',
  APPOINTMENTS: 'easylab_appointments',
  TICKETS: 'easylab_tickets',
  NOTIFICATIONS: 'easylab_notifications',
  SETTINGS: 'easylab_settings',
  LAST_SYNCED: 'easylab_last_synced',
};

// Data provider component
const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(dataReducer, initialState);

  // Load data from localStorage on mount
  useEffect(() => {
    const loadData = () => {
      try {
        dispatch({ type: 'SET_LOADING', payload: true });
        
        // Load clients
        const clientsData = localStorage.getItem(STORAGE_KEYS.CLIENTS);
        if (clientsData) {
          dispatch({ type: 'SET_CLIENTS', payload: JSON.parse(clientsData) });
        }
        
        // Load appointments
        const appointmentsData = localStorage.getItem(STORAGE_KEYS.APPOINTMENTS);
        if (appointmentsData) {
          dispatch({ type: 'SET_APPOINTMENTS', payload: JSON.parse(appointmentsData) });
        }
        
        // Load tickets
        const ticketsData = localStorage.getItem(STORAGE_KEYS.TICKETS);
        if (ticketsData) {
          dispatch({ type: 'SET_TICKETS', payload: JSON.parse(ticketsData) });
        }
        
        // Load notifications
        const notificationsData = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
        if (notificationsData) {
          dispatch({ type: 'SET_NOTIFICATIONS', payload: JSON.parse(notificationsData) });
        }
        
        // Load settings
        const settingsData = localStorage.getItem(STORAGE_KEYS.SETTINGS);
        if (settingsData) {
          dispatch({ type: 'UPDATE_SETTINGS', payload: JSON.parse(settingsData) });
        }
        
        // Load last synced time
        const lastSyncedData = localStorage.getItem(STORAGE_KEYS.LAST_SYNCED);
        if (lastSyncedData) {
          dispatch({ type: 'SET_LAST_SYNCED', payload: lastSyncedData });
        }
        
        dispatch({ type: 'SET_LOADING', payload: false });
      } catch (error) {
        dispatch({ type: 'SET_ERROR', payload: 'Errore durante il caricamento dei dati' });
        dispatch({ type: 'SET_LOADING', payload: false });
      }
    };
    
    loadData();
  }, []);

  // Save data to localStorage when state changes
  useEffect(() => {
    const saveData = () => {
      try {
        localStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(state.clients));
        localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(state.appointments));
        localStorage.setItem(STORAGE_KEYS.TICKETS, JSON.stringify(state.tickets));
        localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(state.notifications));
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(state.settings));
      } catch (error) {
        dispatch({ type: 'SET_ERROR', payload: 'Errore durante il salvataggio dei dati' });
      }
    };
    
    if (!state.isLoading) {
      saveData();
    }
  }, [state.clients, state.appointments, state.tickets, state.notifications, state.settings, state.isLoading]);

  // Check for upcoming appointments and create notifications
  useEffect(() => {
    const checkInterval = setInterval(() => {
      checkUpcomingAppointments();
    }, 60000); // Check every minute
    
    return () => clearInterval(checkInterval);
  }, [state.appointments, state.settings.appointmentReminderHours]);

  // Generate client code
  const generateClientCode = (): string => {
    const lastClient = state.clients.length > 0 
      ? state.clients.sort((a, b) => {
          const numA = parseInt(a.clientCode.replace('ESL-', ''));
          const numB = parseInt(b.clientCode.replace('ESL-', ''));
          return numB - numA;
        })[0]
      : null;
    
    let newNumber = 1;
    if (lastClient) {
      const lastNumber = parseInt(lastClient.clientCode.replace('ESL-', ''));
      newNumber = lastNumber + 1;
    }
    
    return `ESL-${String(newNumber).padStart(4, '0')}`;
  };

  // Generate ticket number
  const generateTicketNumber = (): string => {
    const date = new Date();
    const year = date.getFullYear().toString().slice(2);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    
    const lastTicket = state.tickets.length > 0 
      ? state.tickets.filter(t => t.ticketNumber.startsWith(`TK${year}${month}`))
          .sort((a, b) => b.ticketNumber.localeCompare(a.ticketNumber))[0]
      : null;
    
    let newNumber = 1;
    if (lastTicket) {
      const lastNumber = parseInt(lastTicket.ticketNumber.slice(6));
      newNumber = lastNumber + 1;
    }
    
    return `TK${year}${month}${String(newNumber).padStart(4, '0')}`;
  };

  // Client functions
  const addClient = async (clientData: Omit<Client, 'id' | 'createdAt' | 'updatedAt' | 'clientCode'>): Promise<Client> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const now = new Date().toISOString();
      const newClient: Client = {
        ...clientData,
        id: uuidv4(),
        clientCode: generateClientCode(),
        createdAt: now,
        updatedAt: now,
        locations: clientData.locations || [],
        devices: clientData.devices || [],
      };
      
      dispatch({ type: 'ADD_CLIENT', payload: newClient });
      dispatch({ type: 'SET_LOADING', payload: false });
      
      // Add notification for new client
      addNotification({
        userId: '1', // Admin ID
        title: 'Nuovo cliente',
        message: `È stato registrato un nuovo cliente: ${newClient.name}`,
        type: 'info',
        isRead: false,
        link: `/clients/${newClient.id}`,
      });
      
      return newClient;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiunta del cliente' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  const updateClient = async (client: Client): Promise<Client> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const updatedClient: Client = {
        ...client,
        updatedAt: new Date().toISOString(),
      };
      
      dispatch({ type: 'UPDATE_CLIENT', payload: updatedClient });
      dispatch({ type: 'SET_LOADING', payload: false });
      
      return updatedClient;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiornamento del cliente' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  const deleteClient = async (id: string): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      dispatch({ type: 'DELETE_CLIENT', payload: id });
      
      // Also delete related appointments and tickets
      state.appointments
        .filter(appointment => appointment.clientId === id)
        .forEach(appointment => {
          dispatch({ type: 'DELETE_APPOINTMENT', payload: appointment.id });
        });
      
      state.tickets
        .filter(ticket => ticket.clientId === id)
        .forEach(ticket => {
          dispatch({ type: 'DELETE_TICKET', payload: ticket.id });
        });
      
      dispatch({ type: 'SET_LOADING', payload: false });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'eliminazione del cliente' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  // Appointment functions
  const addAppointment = async (appointmentData: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>): Promise<Appointment> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const now = new Date().toISOString();
      const newAppointment: Appointment = {
        ...appointmentData,
        id: uuidv4(),
        createdAt: now,
        updatedAt: now,
      };
      
      dispatch({ type: 'ADD_APPOINTMENT', payload: newAppointment });
      dispatch({ type: 'SET_LOADING', payload: false });
      
      // Add notification for new appointment
      const client = state.clients.find(c => c.id === appointmentData.clientId);
      if (client) {
        addNotification({
          userId: '1', // Admin ID
          title: 'Nuovo appuntamento',
          message: `È stato programmato un nuovo appuntamento con ${client.name} per il ${new Date(appointmentData.date).toLocaleDateString()}`,
          type: 'info',
          isRead: false,
          link: `/appointments/${newAppointment.id}`,
        });
      }
      
      return newAppointment;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiunta dell\'appuntamento' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  const updateAppointment = async (appointment: Appointment): Promise<Appointment> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const updatedAppointment: Appointment = {
        ...appointment,
        updatedAt: new Date().toISOString(),
      };
      
      dispatch({ type: 'UPDATE_APPOINTMENT', payload: updatedAppointment });
      dispatch({ type: 'SET_LOADING', payload: false });
      
      return updatedAppointment;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiornamento dell\'appuntamento' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  const deleteAppointment = async (id: string): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      dispatch({ type: 'DELETE_APPOINTMENT', payload: id });
      dispatch({ type: 'SET_LOADING', payload: false });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'eliminazione dell\'appuntamento' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  // Ticket functions
  const addTicket = async (ticketData: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt' | 'ticketNumber' | 'messages'>): Promise<Ticket> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const now = new Date().toISOString();
      const newTicket: Ticket = {
        ...ticketData,
        id: uuidv4(),
        ticketNumber: generateTicketNumber(),
        createdAt: now,
        updatedAt: now,
        messages: [],
      };
      
      dispatch({ type: 'ADD_TICKET', payload: newTicket });
      dispatch({ type: 'SET_LOADING', payload: false });
      
      // Add notification for new ticket
      const client = state.clients.find(c => c.id === ticketData.clientId);
      if (client) {
        addNotification({
          userId: '1', // Admin ID
          title: 'Nuovo ticket',
          message: `È stato aperto un nuovo ticket da ${client.name}: ${newTicket.title}`,
          type: 'warning',
          isRead: false,
          link: `/tickets/${newTicket.id}`,
        });
      }
      
      return newTicket;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiunta del ticket' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  const updateTicket = async (ticket: Ticket): Promise<Ticket> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const updatedTicket: Ticket = {
        ...ticket,
        updatedAt: new Date().toISOString(),
      };
      
      dispatch({ type: 'UPDATE_TICKET', payload: updatedTicket });
      dispatch({ type: 'SET_LOADING', payload: false });
      
      return updatedTicket;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiornamento del ticket' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  const deleteTicket = async (id: string): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      dispatch({ type: 'DELETE_TICKET', payload: id });
      dispatch({ type: 'SET_LOADING', payload: false });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'eliminazione del ticket' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  // Notification functions
  const addNotification = async (notificationData: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification> => {
    try {
      const newNotification: Notification = {
        ...notificationData,
        id: uuidv4(),
        createdAt: new Date().toISOString(),
      };
      
      dispatch({ type: 'ADD_NOTIFICATION', payload: newNotification });
      
      return newNotification;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiunta della notifica' });
      throw error;
    }
  };

  const markNotificationRead = async (id: string): Promise<void> => {
    try {
      dispatch({ type: 'MARK_NOTIFICATION_READ', payload: id });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiornamento della notifica' });
      throw error;
    }
  };

  const deleteNotification = async (id: string): Promise<void> => {
    try {
      dispatch({ type: 'DELETE_NOTIFICATION', payload: id });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'eliminazione della notifica' });
      throw error;
    }
  };

  // Settings functions
  const updateSettings = async (settings: Partial<SystemSettings>): Promise<void> => {
    try {
      dispatch({ type: 'UPDATE_SETTINGS', payload: settings });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'aggiornamento delle impostazioni' });
      throw error;
    }
  };

  // Check for upcoming appointments and create notifications
  const checkUpcomingAppointments = async (): Promise<void> => {
    try {
      if (!state.settings.appointmentReminderHours) return;
      
      const now = new Date();
      const reminderWindow = addDays(now, 1); // Check appointments within the next day
      
      // Get upcoming appointments that haven't been notified yet
      const upcomingAppointments = state.appointments.filter(appointment => {
        const appointmentDate = new Date(appointment.date);
        const appointmentTime = appointment.startTime.split(':');
        appointmentDate.setHours(
          parseInt(appointmentTime[0], 10),
          parseInt(appointmentTime[1], 10),
          0,
          0
        );
        
        // Check if appointment is in the future but within reminder window
        const isUpcoming = isAfter(appointmentDate, now) && isBefore(appointmentDate, reminderWindow);
        
        // Check if we need to send a reminder (based on hours before appointment)
        const hoursUntilAppointment = (appointmentDate.getTime() - now.getTime()) / (1000 * 60 * 60);
        const shouldRemind = hoursUntilAppointment <= state.settings.appointmentReminderHours && 
                              hoursUntilAppointment > (state.settings.appointmentReminderHours - 1);
        
        return isUpcoming && shouldRemind && appointment.status === 'scheduled';
      });
      
      // Create notifications for each upcoming appointment
      for (const appointment of upcomingAppointments) {
        const client = state.clients.find(c => c.id === appointment.clientId);
        const clientName = client ? client.name : 'Cliente';
        const appointmentDate = new Date(appointment.date);
        const appointmentTime = appointment.startTime;
        
        const timeUntilAppointment = formatDistanceToNow(appointmentDate, { locale: it, addSuffix: true });
        
        // Create notification for admin
        await addNotification({
          userId: '1', // Admin ID
          title: 'Appuntamento in scadenza',
          message: `Appuntamento con ${clientName} ${timeUntilAppointment} - ${appointmentDate.toLocaleDateString()} alle ${appointmentTime}`,
          type: 'warning',
          isRead: false,
          link: `/admin/appointments/${appointment.id}`,
        });
        
        // If the appointment has a client, create a notification for them as well
        if (client) {
          await addNotification({
            userId: client.id,
            title: 'Promemoria appuntamento',
            message: `Hai un appuntamento programmato ${timeUntilAppointment} - ${appointmentDate.toLocaleDateString()} alle ${appointmentTime}`,
            type: 'info',
            isRead: false,
            link: `/client/appointments/${appointment.id}`,
          });
        }
      }
    } catch (error) {
      console.error('Error checking upcoming appointments:', error);
    }
  };

  // WhatsApp integration
  const sendWhatsAppMessage = async (phoneNumber: string, message: string): Promise<boolean> => {
    try {
      // Check if WhatsApp integration is enabled
      if (!state.settings.enableWhatsApp || 
          !state.settings.whatsAppBusinessId || 
          !state.settings.whatsAppPhoneNumberId || 
          !state.settings.whatsAppAccessToken) {
        throw new Error('WhatsApp integration is not properly configured');
      }
      
      // For demo purposes, we'll just pretend it works
      console.log(`Sending WhatsApp message to ${phoneNumber}: ${message}`);
      
      // Add a notification about the sent message
      await addNotification({
        userId: '1', // Admin ID
        title: 'Messaggio WhatsApp inviato',
        message: `Messaggio inviato con successo al numero ${phoneNumber}`,
        type: 'success',
        isRead: false,
      });
      
      return true;
    } catch (error) {
      console.error('Error sending WhatsApp message:', error);
      
      // Add a notification about the failed message
      await addNotification({
        userId: '1', // Admin ID
        title: 'Errore invio WhatsApp',
        message: `Impossibile inviare il messaggio WhatsApp: ${error instanceof Error ? error.message : 'Errore sconosciuto'}`,
        type: 'error',
        isRead: false,
      });
      
      return false;
    }
  };

  // Sync functions
  const syncData = async (): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // In a real application, this would sync with a server
      // For demo purposes, we'll just update the last synced time
      
      const now = new Date().toISOString();
      dispatch({ type: 'SET_LAST_SYNCED', payload: now });
      localStorage.setItem(STORAGE_KEYS.LAST_SYNCED, now);
      
      dispatch({ type: 'SET_LOADING', payload: false });
      
      // Add notification for sync
      addNotification({
        userId: '1', // Admin ID
        title: 'Sincronizzazione completata',
        message: 'I dati sono stati sincronizzati con successo',
        type: 'success',
        isRead: false,
      });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante la sincronizzazione dei dati' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  // Backup functions
  const backupData = async (): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const backupData = {
        clients: state.clients,
        appointments: state.appointments,
        tickets: state.tickets,
        notifications: state.notifications,
        settings: state.settings,
        version: '1.0.0',
        timestamp: new Date().toISOString(),
      };
      
      const backupString = JSON.stringify(backupData);
      
      // In a real application, this would save to a file or server
      // For demo purposes, we'll just log to console
      console.log('Backup data:', backupString);
      
      dispatch({ type: 'SET_LOADING', payload: false });
      
      // Add notification for backup
      addNotification({
        userId: '1', // Admin ID
        title: 'Backup completato',
        message: 'Il backup dei dati è stato completato con successo',
        type: 'success',
        isRead: false,
      });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante il backup dei dati' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  // Restore functions
  const restoreData = async (backupData: string): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const parsedData = JSON.parse(backupData);
      
      if (parsedData.clients) {
        dispatch({ type: 'SET_CLIENTS', payload: parsedData.clients });
      }
      
      if (parsedData.appointments) {
        dispatch({ type: 'SET_APPOINTMENTS', payload: parsedData.appointments });
      }
      
      if (parsedData.tickets) {
        dispatch({ type: 'SET_TICKETS', payload: parsedData.tickets });
      }
      
      if (parsedData.notifications) {
        dispatch({ type: 'SET_NOTIFICATIONS', payload: parsedData.notifications });
      }
      
      if (parsedData.settings) {
        dispatch({ type: 'UPDATE_SETTINGS', payload: parsedData.settings });
      }
      
      dispatch({ type: 'SET_LOADING', payload: false });
      
      // Add notification for restore
      addNotification({
        userId: '1', // Admin ID
        title: 'Ripristino completato',
        message: 'I dati sono stati ripristinati con successo',
        type: 'success',
        isRead: false,
      });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante il ripristino dei dati' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  // Export functions
  const exportData = async (type: 'clients' | 'appointments' | 'tickets' | 'all'): Promise<string> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      let exportData: any = {};
      
      switch (type) {
        case 'clients':
          exportData = { clients: state.clients };
          break;
        case 'appointments':
          exportData = { appointments: state.appointments };
          break;
        case 'tickets':
          exportData = { tickets: state.tickets };
          break;
        case 'all':
          exportData = {
            clients: state.clients,
            appointments: state.appointments,
            tickets: state.tickets,
          };
          break;
      }
      
      const exportString = JSON.stringify(exportData, null, 2);
      
      dispatch({ type: 'SET_LOADING', payload: false });
      
      return exportString;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Errore durante l\'esportazione dei dati' });
      dispatch({ type: 'SET_LOADING', payload: false });
      throw error;
    }
  };

  return (
    <DataContext.Provider
      value={{
        state,
        addClient,
        updateClient,
        deleteClient,
        addAppointment,
        updateAppointment,
        deleteAppointment,
        addTicket,
        updateTicket,
        deleteTicket,
        addNotification,
        markNotificationRead,
        deleteNotification,
        updateSettings,
        syncData,
        backupData,
        restoreData,
        exportData,
        sendWhatsAppMessage,
        checkUpcomingAppointments,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

// Custom hook to use data context
const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export { DataProvider, useData };