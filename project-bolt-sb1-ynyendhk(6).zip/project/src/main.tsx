import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { ThemeProvider } from './context/ThemeContext';

// Layouts
import AdminLayout from './components/AdminLayout';
import ClientLayout from './components/ClientLayout';

// Auth Pages
import Login from './pages/Login';
import Register from './pages/Register';
import PrivacyPolicy from './pages/legal/PrivacyPolicy';

// Protected Route Component
import ProtectedRoute from './components/ProtectedRoute';

// Admin Pages
import AdminDashboard from './pages/admin/Dashboard';
import SystemSettings from './pages/admin/settings/SystemSettings';
import UtilityDashboard from './pages/admin/settings/UtilityDashboard';
import LegalInfo from './pages/admin/settings/LegalInfo';
import ClientList from './pages/admin/clients/ClientList';
import ClientDetail from './pages/admin/clients/ClientDetail';
import ClientForm from './pages/admin/clients/ClientForm';
import DeviceForm from './pages/admin/clients/DeviceForm';
import AppointmentList from './pages/admin/appointments/AppointmentList';
import AppointmentForm from './pages/admin/appointments/AppointmentForm';
import Calendar from './pages/admin/appointments/Calendar';
import AppointmentTypes from './pages/admin/appointments/AppointmentTypes';
import TicketList from './pages/admin/tickets/TicketList';
import TicketDetail from './pages/admin/tickets/TicketDetail';
import TicketForm from './pages/admin/tickets/TicketForm';
import TicketStats from './pages/admin/tickets/TicketStats';

// Client Pages
import ClientDashboard from './pages/client/Dashboard';

import './index.css';

const App = () => {
  return (
    <Router>
      <AuthProvider>
        <DataProvider>
          <ThemeProvider>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Navigate to="/login" replace />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/privacy" element={<PrivacyPolicy />} />

              {/* Admin Routes */}
              <Route path="/admin" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <AdminDashboard />
                  </AdminLayout>
                </ProtectedRoute>
              } />

              {/* Admin - Clients */}
              <Route path="/admin/clients" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <ClientList />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/clients/new" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <ClientForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/clients/:id" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <ClientDetail />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/clients/:id/edit" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <ClientForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/clients/:id/devices/new" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <DeviceForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/clients/:id/devices/:deviceId/edit" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <DeviceForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />

              {/* Admin - Appointments */}
              <Route path="/admin/appointments" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <AppointmentList />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/appointments/calendar" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <Calendar />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/appointments/types" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <AppointmentTypes />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/appointments/new" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <AppointmentForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/appointments/:id" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <AppointmentForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/appointments/:id/edit" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <AppointmentForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />

              {/* Admin - Tickets */}
              <Route path="/admin/tickets" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <TicketList />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/tickets/stats" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <TicketStats />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/tickets/new" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <TicketForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/tickets/:id" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <TicketDetail />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/tickets/:id/edit" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <TicketForm />
                  </AdminLayout>
                </ProtectedRoute>
              } />

              {/* Admin - Settings */}
              <Route path="/admin/settings" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <SystemSettings />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/settings/utility" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <UtilityDashboard />
                  </AdminLayout>
                </ProtectedRoute>
              } />
              <Route path="/admin/settings/legal" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminLayout>
                    <LegalInfo />
                  </AdminLayout>
                </ProtectedRoute>
              } />

              {/* Client Routes */}
              <Route path="/client" element={
                <ProtectedRoute requiredRole="user">
                  <ClientLayout>
                    <ClientDashboard />
                  </ClientLayout>
                </ProtectedRoute>
              } />
              <Route path="/client/appointments" element={
                <ProtectedRoute requiredRole="user">
                  <ClientLayout>
                    <AppointmentList />
                  </ClientLayout>
                </ProtectedRoute>
              } />
              <Route path="/client/tickets" element={
                <ProtectedRoute requiredRole="user">
                  <ClientLayout>
                    <TicketList />
                  </ClientLayout>
                </ProtectedRoute>
              } />

              {/* Catch all route - redirect to login */}
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          </ThemeProvider>
        </DataProvider>
      </AuthProvider>
    </Router>
  );
};

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);