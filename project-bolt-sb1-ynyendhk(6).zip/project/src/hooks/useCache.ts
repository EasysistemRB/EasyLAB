import { useState, useCallback } from 'react';
import { 
  cacheSet, 
  cacheGet, 
  cacheRemove, 
  cacheClear, 
  getCacheStats,
  cleanupCache,
  CacheStats 
} from '../utils/cacheUtils';

export const useCache = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<CacheStats | null>(null);

  const refreshStats = useCallback(async () => {
    try {
      const newStats = await getCacheStats();
      setStats(newStats);
    } catch (err) {
      console.error('Error refreshing cache stats:', err);
    }
  }, []);

  const clearCache = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      await cacheClear();
      await refreshStats();
    } catch (err) {
      setError('Error clearing cache');
      console.error('Error clearing cache:', err);
    } finally {
      setIsLoading(false);
    }
  }, [refreshStats]);

  const cleanCache = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      await cleanupCache();
      await refreshStats();
    } catch (err) {
      setError('Error cleaning cache');
      console.error('Error cleaning cache:', err);
    } finally {
      setIsLoading(false);
    }
  }, [refreshStats]);

  return {
    isLoading,
    error,
    stats,
    refreshStats,
    clearCache,
    cleanCache,
    cacheSet,
    cacheGet,
    cacheRemove
  };
};