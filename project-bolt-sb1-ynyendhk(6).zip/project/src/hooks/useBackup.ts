import { useState, useCallback } from 'react';
import { useData } from '../context/DataContext';
import { 
  BackupOptions, 
  BackupMetadata, 
  createBackupMetadata, 
  validateBackup,
  calculateChecksum,
  generateBackupFilename
} from '../utils/backupUtils';

export const useBackup = () => {
  const { state } = useData();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  // Create a new backup
  const createBackup = useCallback(async (options: BackupOptions) => {
    setIsLoading(true);
    setError(null);
    setProgress(0);

    try {
      // Prepare data for backup
      const backupData = {
        clients: options.type === 'full' || options.components?.includes('clients') 
          ? state.clients 
          : [],
        appointments: options.type === 'full' || options.components?.includes('appointments')
          ? state.appointments
          : [],
        tickets: options.type === 'full' || options.components?.includes('tickets')
          ? state.tickets
          : [],
        settings: options.type === 'full' || options.components?.includes('settings')
          ? state.settings
          : null
      };

      setProgress(25);

      // Create backup metadata
      const metadata = createBackupMetadata(backupData, options);

      setProgress(50);

      // Validate backup
      validateBackup(backupData, metadata);

      setProgress(75);

      // Store backup in localStorage
      const backupKey = `backup_${metadata.id}`;
      const backup = { metadata, data: backupData };
      localStorage.setItem(backupKey, JSON.stringify(backup));

      // Update backup history
      const historyKey = 'backup_history';
      const history = JSON.parse(localStorage.getItem(historyKey) || '[]');
      history.push(metadata);
      localStorage.setItem(historyKey, JSON.stringify(history));

      setProgress(100);
      return backup;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creating backup');
      throw err;
    } finally {
      setIsLoading(false);
      setProgress(0);
    }
  }, [state]);

  // Get backup history
  const getBackupHistory = useCallback(async () => {
    try {
      const historyKey = 'backup_history';
      const history = JSON.parse(localStorage.getItem(historyKey) || '[]');
      return history;
    } catch (err) {
      console.error('Error getting backup history:', err);
      return [];
    }
  }, []);

  // Restore from backup
  const restoreBackup = useCallback(async (backupId: string) => {
    setIsLoading(true);
    setError(null);
    setProgress(0);

    try {
      // Get backup from localStorage
      const backupKey = `backup_${backupId}`;
      const backup = JSON.parse(localStorage.getItem(backupKey) || 'null');
      
      if (!backup) {
        throw new Error('Backup not found');
      }

      setProgress(25);

      // Validate backup
      validateBackup(backup.data, backup.metadata);

      setProgress(50);

      // Create restore point of current data
      const restorePoint = {
        clients: state.clients,
        appointments: state.appointments,
        tickets: state.tickets,
        settings: state.settings
      };

      const restorePointKey = `restore_point_${new Date().getTime()}`;
      localStorage.setItem(restorePointKey, JSON.stringify(restorePoint));

      setProgress(75);

      // Perform restore
      // In a real application, this would update the database
      // For now, we'll just update localStorage
      localStorage.setItem('clients', JSON.stringify(backup.data.clients));
      localStorage.setItem('appointments', JSON.stringify(backup.data.appointments));
      localStorage.setItem('tickets', JSON.stringify(backup.data.tickets));
      localStorage.setItem('settings', JSON.stringify(backup.data.settings));

      setProgress(100);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error restoring backup');
      throw err;
    } finally {
      setIsLoading(false);
      setProgress(0);
    }
  }, [state]);

  // Delete a backup
  const deleteBackup = useCallback(async (backupId: string) => {
    try {
      // Remove backup data
      const backupKey = `backup_${backupId}`;
      localStorage.removeItem(backupKey);

      // Update history
      const historyKey = 'backup_history';
      const history = JSON.parse(localStorage.getItem(historyKey) || '[]');
      const updatedHistory = history.filter((item: any) => item.id !== backupId);
      localStorage.setItem(historyKey, JSON.stringify(updatedHistory));

      return true;
    } catch (err) {
      console.error('Error deleting backup:', err);
      throw err;
    }
  }, []);

  return {
    createBackup,
    restoreBackup,
    getBackupHistory,
    deleteBackup,
    isLoading,
    error,
    progress
  };
};